import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import ProjectListPage from './pages/ProjectListPage';
import ProjectWorkspace from './pages/ProjectWorkspace';
import ProjectClassesPage from './pages/ProjectClassesPage';
import ProjectModelsPage from './pages/ProjectModelsPage';
import ProjectSmartLinksPage from './pages/ProjectSmartLinksPage';
import ProjectRegionsPage from './pages/ProjectRegionsPage';
import ProjectDocPropsPage from './pages/ProjectDocPropsPage';
import ProjectSymbolsPage from './pages/ProjectSymbolsPage';
import LoginPage from './pages/LoginPage';
import './App.css';

// Protected route wrapper - redirects to login if not authenticated
function ProtectedRoute({ children }) {
  const isAuthenticated = sessionStorage.getItem('authenticated') === 'true';
  
  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }
  
  return children;
}

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/login" element={<LoginPage />} />
        <Route path="/" element={
          <ProtectedRoute>
            <ProjectListPage />
          </ProtectedRoute>
        } />
        <Route path="/project/:projectId" element={
          <ProtectedRoute>
            <ProjectWorkspace />
          </ProtectedRoute>
        } />
        <Route path="/project/:projectId/classes" element={
          <ProtectedRoute>
            <ProjectClassesPage />
          </ProtectedRoute>
        } />
        <Route path="/project/:projectId/models" element={
          <ProtectedRoute>
            <ProjectModelsPage />
          </ProtectedRoute>
        } />
        <Route path="/project/:projectId/smartlinks" element={
          <ProtectedRoute>
            <ProjectSmartLinksPage />
          </ProtectedRoute>
        } />
        <Route path="/project/:projectId/docprops" element={
          <ProtectedRoute>
            <ProjectDocPropsPage />
          </ProtectedRoute>
        } />
        <Route path="/project/:projectId/regions" element={
          <ProtectedRoute>
            <ProjectRegionsPage />
          </ProtectedRoute>
        } />
        <Route path="/project/:projectId/symbols" element={
          <ProtectedRoute>
            <ProjectSymbolsPage />
          </ProtectedRoute>
        } />
      </Routes>
    </Router>
  );
}

export default App;
