/**
 * SaveSymbolDialog.jsx
 * 
 * Modal dialog for saving selected markups as a reusable symbol.
 * Includes a preview of the markups and name input.
 */

import { useState } from 'react';

/**
 * Generate SVG preview of markups
 */
function generateMarkupPreview(markups, size = 70) {
  if (!markups || markups.length === 0) {
    return <span style={{ color: '#888' }}>?</span>;
  }

  let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
  
  markups.forEach(m => {
    if (m.points) {
      m.points.forEach(p => {
        minX = Math.min(minX, p.x);
        minY = Math.min(minY, p.y);
        maxX = Math.max(maxX, p.x);
        maxY = Math.max(maxY, p.y);
      });
    } else if (m.startX !== undefined) {
      minX = Math.min(minX, m.startX, m.endX);
      minY = Math.min(minY, m.startY, m.endY);
      maxX = Math.max(maxX, m.startX, m.endX);
      maxY = Math.max(maxY, m.startY, m.endY);
    } else if (m.x !== undefined) {
      minX = Math.min(minX, m.x);
      minY = Math.min(minY, m.y);
      maxX = Math.max(maxX, m.x);
      maxY = Math.max(maxY, m.y);
    }
  });

  const w = maxX - minX || 0.01;
  const h = maxY - minY || 0.01;
  const pad = 5;
  const scaleX = (size - pad * 2) / w;
  const scaleY = (size - pad * 2) / h;
  const sc = Math.min(scaleX, scaleY);

  const tx = (x) => pad + (x - minX) * sc;
  const ty = (y) => pad + (y - minY) * sc;

  let svg = '';
  markups.forEach(m => {
    if ((m.type === 'pen' || m.type === 'highlighter') && m.points?.length > 1) {
      const d = m.points.map((p, i) => `${i === 0 ? 'M' : 'L'} ${tx(p.x)} ${ty(p.y)}`).join(' ');
      svg += `<path d="${d}" stroke="${m.color || '#000'}" stroke-width="${Math.max(1, (m.strokeWidth || 2) * 0.4)}" fill="none" opacity="${m.opacity || 1}"/>`;
    } else if (m.type === 'rectangle') {
      svg += `<rect x="${tx(Math.min(m.startX, m.endX))}" y="${ty(Math.min(m.startY, m.endY))}" width="${Math.abs(m.endX - m.startX) * sc}" height="${Math.abs(m.endY - m.startY) * sc}" stroke="${m.color || '#000'}" stroke-width="1.5" fill="${m.fillColor && m.fillColor !== 'none' ? m.fillColor : 'none'}" fill-opacity="0.3"/>`;
    } else if (m.type === 'circle') {
      svg += `<ellipse cx="${tx((m.startX + m.endX) / 2)}" cy="${ty((m.startY + m.endY) / 2)}" rx="${Math.abs(m.endX - m.startX) / 2 * sc}" ry="${Math.abs(m.endY - m.startY) / 2 * sc}" stroke="${m.color || '#000'}" stroke-width="1.5" fill="${m.fillColor && m.fillColor !== 'none' ? m.fillColor : 'none'}" fill-opacity="0.3"/>`;
    } else if (m.type === 'line') {
      svg += `<line x1="${tx(m.startX)}" y1="${ty(m.startY)}" x2="${tx(m.endX)}" y2="${ty(m.endY)}" stroke="${m.color || '#000'}" stroke-width="1.5"/>`;
    } else if (m.type === 'arrow') {
      svg += `<line x1="${tx(m.startX)}" y1="${ty(m.startY)}" x2="${tx(m.endX)}" y2="${ty(m.endY)}" stroke="${m.color || '#000'}" stroke-width="1.5" marker-end="url(#ah)"/>`;
    }
  });

  return (
    <div dangerouslySetInnerHTML={{ 
      __html: `<svg width="${size}" height="${size}" viewBox="0 0 ${size} ${size}"><defs><marker id="ah" markerWidth="6" markerHeight="6" refX="5" refY="3" orient="auto"><path d="M0,0 L6,3 L0,6" fill="none" stroke="#000" stroke-width="1"/></marker></defs>${svg}</svg>` 
    }} />
  );
}

export default function SaveSymbolDialog({
  isOpen,
  onClose,
  selectedMarkups,
  selectedMarkup,
  onSave
}) {
  const [symbolName, setSymbolName] = useState('');

  if (!isOpen) return null;

  const handleClose = () => {
    setSymbolName('');
    onClose();
  };

  const handleSave = () => {
    if (symbolName.trim()) {
      onSave(symbolName.trim());
      setSymbolName('');
    }
  };

  const markupsToPreview = selectedMarkups?.length > 0 ? selectedMarkups : (selectedMarkup ? [selectedMarkup] : []);
  const markupCount = markupsToPreview.length;

  return (
    <div 
      className="modal-overlay" 
      onClick={handleClose}
      style={{ background: 'rgba(0,0,0,0.5)', zIndex: 10000 }}
    >
      <div 
        className="modal save-symbol-modal" 
        onClick={(e) => e.stopPropagation()}
        style={{
          background: '#2a2a2a',
          borderRadius: '8px',
          padding: '20px',
          width: '350px',
          maxWidth: '90vw',
          boxShadow: '0 4px 20px rgba(0,0,0,0.4)',
          color: 'white'
        }}
      >
        <h2 style={{ margin: '0 0 15px 0', fontSize: '18px', display: 'flex', alignItems: 'center', gap: '8px' }}>
          📌 Save as Symbol
        </h2>
        
        {/* Preview of what will be saved */}
        <div style={{ 
          marginBottom: '15px', 
          padding: '12px', 
          background: '#333', 
          borderRadius: '6px',
          display: 'flex',
          alignItems: 'center',
          gap: '12px'
        }}>
          <div style={{
            width: '80px',
            height: '80px',
            background: '#f5f5f5',
            borderRadius: '4px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            flexShrink: 0
          }}>
            {generateMarkupPreview(markupsToPreview)}
          </div>
          <div>
            <div style={{ fontSize: '13px', color: '#ccc', marginBottom: '4px' }}>
              {markupCount} markup{markupCount !== 1 ? 's' : ''}
            </div>
            <div style={{ fontSize: '11px', color: '#888' }}>
              Preview of your symbol
            </div>
          </div>
        </div>
        
        <div style={{ marginBottom: '15px' }}>
          <label style={{ display: 'block', marginBottom: '6px', fontSize: '13px', color: '#888' }}>
            Symbol Name:
          </label>
          <input
            type="text"
            value={symbolName}
            onChange={(e) => setSymbolName(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && symbolName.trim()) {
                handleSave();
              }
            }}
            autoFocus
            style={{
              width: '100%',
              padding: '10px',
              border: '1px solid #444',
              borderRadius: '4px',
              fontSize: '14px',
              background: '#333',
              color: 'white',
              boxSizing: 'border-box'
            }}
            placeholder="Enter symbol name..."
          />
        </div>
        
        <div style={{ display: 'flex', gap: '10px', justifyContent: 'flex-end' }}>
          <button
            onClick={handleClose}
            style={{
              padding: '8px 16px',
              border: '1px solid #555',
              borderRadius: '4px',
              background: 'transparent',
              color: '#ccc',
              cursor: 'pointer',
              fontSize: '14px'
            }}
          >
            Cancel
          </button>
          <button
            onClick={handleSave}
            disabled={!symbolName.trim()}
            style={{
              padding: '8px 16px',
              border: 'none',
              borderRadius: '4px',
              background: symbolName.trim() ? '#9b59b6' : '#555',
              color: 'white',
              cursor: symbolName.trim() ? 'pointer' : 'not-allowed',
              fontSize: '14px'
            }}
          >
            ✓ Save Symbol
          </button>
        </div>
      </div>
    </div>
  );
}
