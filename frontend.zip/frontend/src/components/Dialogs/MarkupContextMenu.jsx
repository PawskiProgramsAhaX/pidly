/**
 * MarkupContextMenu.jsx
 * 
 * Right-click context menu for markup annotations.
 * Provides options to convert markup to region or delete it.
 */

export default function MarkupContextMenu({
  isOpen,
  position,
  markup,
  onClose,
  onConvertToRegion,
  onDelete
}) {
  if (!isOpen || !markup) return null;

  return (
    <div 
      className="markup-context-menu"
      style={{
        position: 'fixed',
        left: position.x,
        top: position.y,
        zIndex: 10000,
        background: 'white',
        border: '1px solid #ddd',
        borderRadius: '8px',
        boxShadow: '0 4px 12px rgba(0,0,0,0.15)',
        overflow: 'hidden',
        minWidth: '180px',
      }}
      onClick={(e) => e.stopPropagation()}
    >
      <button
        style={{
          display: 'flex',
          alignItems: 'center',
          gap: '10px',
          width: '100%',
          padding: '10px 14px',
          border: 'none',
          background: 'white',
          textAlign: 'left',
          cursor: 'pointer',
          fontSize: '13px',
          color: '#333',
          transition: 'background 0.15s',
        }}
        onMouseEnter={(e) => e.target.style.background = '#f5f5f5'}
        onMouseLeave={(e) => e.target.style.background = 'white'}
        onClick={() => {
          onConvertToRegion();
          onClose();
        }}
      >
        <span style={{ fontSize: '16px' }}>🗺️</span>
        Convert to Region
      </button>
      <div style={{ height: '1px', background: '#eee' }} />
      <button
        style={{
          display: 'flex',
          alignItems: 'center',
          gap: '10px',
          width: '100%',
          padding: '10px 14px',
          border: 'none',
          background: 'white',
          textAlign: 'left',
          cursor: 'pointer',
          fontSize: '13px',
          color: '#e74c3c',
          transition: 'background 0.15s',
        }}
        onMouseEnter={(e) => e.target.style.background = '#fef0ef'}
        onMouseLeave={(e) => e.target.style.background = 'white'}
        onClick={() => {
          onDelete();
          onClose();
        }}
      >
        <span style={{ fontSize: '16px' }}>🗑️</span>
        Delete Markup
      </button>
    </div>
  );
}
