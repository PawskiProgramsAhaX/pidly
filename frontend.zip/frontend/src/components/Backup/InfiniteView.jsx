import { useState, useRef, useEffect, useCallback, useMemo } from 'react';
import { getObjectsFromBackend, saveObjectsToBackend } from '../utils/storage';
import './InfiniteView.css';

// Delete annotations from PDF bytes using pdf-lib
async function deleteAnnotationsFromPdf(pdfArrayBuffer, annotationIdsToDelete) {
  if (!annotationIdsToDelete || annotationIdsToDelete.size === 0) {
    return null;
  }
  
  try {
    const { PDFDocument, PDFName, PDFArray, PDFRef } = await import('pdf-lib');
    const pdfDoc = await PDFDocument.load(pdfArrayBuffer, { ignoreEncryption: true });
    
    const pages = pdfDoc.getPages();
    let deletedCount = 0;
    
    // Extract the reference numbers from our annotation IDs (e.g., "pdf_text_145R" -> "145")
    const refNumbersToDelete = new Set();
    for (const id of annotationIdsToDelete) {
      const match = id.match(/_(\d+)R/);
      if (match) {
        refNumbersToDelete.add(parseInt(match[1], 10));
      }
    }
    
    console.log('Deleting annotations with ref numbers:', [...refNumbersToDelete]);
    
    for (let pageIndex = 0; pageIndex < pages.length; pageIndex++) {
      const page = pages[pageIndex];
      const annotsRef = page.node.get(PDFName.of('Annots'));
      
      if (!annotsRef) continue;
      
      let annots = annotsRef;
      if (annotsRef instanceof PDFRef) {
        annots = pdfDoc.context.lookup(annotsRef);
      }
      
      if (!(annots instanceof PDFArray)) continue;
      
      const newAnnots = [];
      for (let i = 0; i < annots.size(); i++) {
        const annotRef = annots.get(i);
        let shouldDelete = false;
        
        if (annotRef instanceof PDFRef) {
          const objNum = annotRef.objectNumber;
          if (refNumbersToDelete.has(objNum)) {
            shouldDelete = true;
            deletedCount++;
            console.log('Deleting annotation with object number:', objNum);
          }
        }
        
        if (!shouldDelete) {
          newAnnots.push(annotRef);
        }
      }
      
      if (newAnnots.length !== annots.size()) {
        if (newAnnots.length === 0) {
          page.node.delete(PDFName.of('Annots'));
        } else {
          const newAnnotsArray = pdfDoc.context.obj(newAnnots);
          page.node.set(PDFName.of('Annots'), newAnnotsArray);
        }
      }
    }
    
    if (deletedCount === 0) {
      console.log('No annotations matched for deletion');
      return null;
    }
    
    console.log(`Deleted ${deletedCount} annotations from PDF`);
    const modifiedPdfBytes = await pdfDoc.save();
    return modifiedPdfBytes;
    
  } catch (error) {
    console.error('Error deleting annotations from PDF:', error);
    return null;
  }
}

// Save annotations to PDF via backend API
async function saveSlotAnnotationsToPdf(slot, annotations, ownedIds, canvasWidth, canvasHeight) {
  try {
    // Log all incoming annotations
    console.log('=== ALL INCOMING ANNOTATIONS ===');
    annotations.forEach(a => {
      console.log({
        id: a.id,
        type: a.type,
        fromPdf: a.fromPdf,
        text: a.text,
        x1: a.x1,
        y1: a.y1,
        x2: a.x2,
        y2: a.y2
      });
    });
    
    // Separate into categories:
    // 1. New annotations (not from PDF) - add these
    // 2. Owned PDF annotations - these were modified, need to be re-added
    const newAnnotations = annotations.filter(a => !a.fromPdf);
    const ownedAnnotations = annotations.filter(a => a.fromPdf && ownedIds.has(a.id));
    
    // IDs of annotations we've taken ownership of (need to be removed from PDF)
    const annotationsToRemove = [...ownedIds].map(id => {
      // Extract the reference number from the ID format: pdf_type_123R
      const match = id.match(/_(\d+)R$/);
      return match ? match[1] : null;
    }).filter(Boolean);
    
    const rawMarkups = [...newAnnotations, ...ownedAnnotations];
    
    if (rawMarkups.length === 0) {
      console.log('No annotations to save');
      return { success: true };
    }
    
    // Convert InfiniteView annotations (pixel coords) to PDFViewerArea format (normalized 0-1 coords)
    const markupsToSave = rawMarkups.map(ann => {
      // Normalize coordinates from pixels to 0-1 range
      const normalizeX = (x) => x / canvasWidth;
      const normalizeY = (y) => y / canvasHeight;
      
      // Base properties common to all types
      const baseMarkup = {
        id: ann.id,
        type: ann.type,
        page: (slot.page || 1) - 1, // Convert to 0-indexed page
        filename: slot.backendFilename,
        color: ann.color || '#ff0000',
        strokeWidth: ann.strokeWidth || 2,
        opacity: ann.opacity || 1,
        strokeOpacity: ann.strokeOpacity || 1,
        fillColor: ann.fillColor || 'none',
        fillOpacity: ann.fillOpacity || 0.3,
        lineStyle: ann.lineStyle || 'solid',
      };
      
      // Handle different annotation types
      if (ann.type === 'pen' || ann.type === 'highlighter') {
        // Pen/highlighter use points array
        const normalizedPoints = (ann.points || []).map(p => ({
          x: normalizeX(p.x),
          y: normalizeY(p.y)
        }));
        return {
          ...baseMarkup,
          points: normalizedPoints,
          // Add bounding box for compatibility
          startX: normalizedPoints.length > 0 ? Math.min(...normalizedPoints.map(p => p.x)) : 0,
          startY: normalizedPoints.length > 0 ? Math.min(...normalizedPoints.map(p => p.y)) : 0,
          endX: normalizedPoints.length > 0 ? Math.max(...normalizedPoints.map(p => p.x)) : 0,
          endY: normalizedPoints.length > 0 ? Math.max(...normalizedPoints.map(p => p.y)) : 0,
        };
      } else if (ann.type === 'polyline' || ann.type === 'polylineArrow' || ann.type === 'cloudPolyline') {
        // Polyline types use points array
        const normalizedPoints = (ann.points || []).map(p => ({
          x: normalizeX(p.x),
          y: normalizeY(p.y)
        }));
        return {
          ...baseMarkup,
          points: normalizedPoints,
          closed: ann.closed || false,
          arrowHeadSize: ann.arrowHeadSize || 12,
          arcSize: ann.arcSize || ann.cloudArcSize || 15,
          inverted: ann.inverted || false,
          // Bounding box
          startX: normalizedPoints.length > 0 ? Math.min(...normalizedPoints.map(p => p.x)) : 0,
          startY: normalizedPoints.length > 0 ? Math.min(...normalizedPoints.map(p => p.y)) : 0,
          endX: normalizedPoints.length > 0 ? Math.max(...normalizedPoints.map(p => p.x)) : 0,
          endY: normalizedPoints.length > 0 ? Math.max(...normalizedPoints.map(p => p.y)) : 0,
        };
      } else if (ann.type === 'arrow' || ann.type === 'line') {
        return {
          ...baseMarkup,
          startX: normalizeX(ann.x1),
          startY: normalizeY(ann.y1),
          endX: normalizeX(ann.x2),
          endY: normalizeY(ann.y2),
          arrowHeadSize: ann.arrowHeadSize || 12,
        };
      } else if (ann.type === 'arc') {
        return {
          ...baseMarkup,
          startX: normalizeX(ann.x1),
          startY: normalizeY(ann.y1),
          endX: normalizeX(ann.x2),
          endY: normalizeY(ann.y2),
          startAngle: ann.startAngle || 0,
          endAngle: ann.endAngle || Math.PI,
        };
      } else if (ann.type === 'text') {
        const textContent = ann.text || '';
        console.log('=== TEXT ANNOTATION DEBUG ===', {
          id: ann.id,
          text: textContent,
          textLength: textContent.length,
          hasContent: textContent.length > 0,
          x1: ann.x1,
          y1: ann.y1,
          x2: ann.x2,
          y2: ann.y2,
          width: Math.abs(ann.x2 - ann.x1),
          height: Math.abs(ann.y2 - ann.y1),
          color: ann.color,
          textColor: ann.textColor,
          borderColor: ann.borderColor,
          fillColor: ann.fillColor,
          fontSize: ann.fontSize,
          textAlign: ann.textAlign,
          canvasWidth,
          canvasHeight
        });
        
        // Skip text boxes with no content (server will fail on empty text)
        if (!textContent) {
          console.log('Skipping text annotation with no content:', ann.id);
          return null;
        }
        
        return {
          ...baseMarkup,
          startX: normalizeX(Math.min(ann.x1, ann.x2)),
          startY: normalizeY(Math.min(ann.y1, ann.y2)),
          endX: normalizeX(Math.max(ann.x1, ann.x2)),
          endY: normalizeY(Math.max(ann.y1, ann.y2)),
          text: textContent,
          fontSize: ann.fontSize || 14,
          fontFamily: ann.fontFamily || 'Arial',
          textAlign: ann.textAlign || 'left',
          textColor: ann.textColor || ann.color || '#000000',
          borderColor: ann.borderColor || ann.color || '#ff0000',
        };
      } else if (ann.type === 'cloud') {
        // Rectangle cloud
        return {
          ...baseMarkup,
          startX: normalizeX(Math.min(ann.x1, ann.x2)),
          startY: normalizeY(Math.min(ann.y1, ann.y2)),
          endX: normalizeX(Math.max(ann.x1, ann.x2)),
          endY: normalizeY(Math.max(ann.y1, ann.y2)),
          arcSize: ann.arcSize || ann.cloudArcSize || 15,
          cloudIntensity: ann.cloudIntensity || 1,
          inverted: ann.inverted || false,
        };
      } else {
        // Rectangle, circle, and other shapes
        return {
          ...baseMarkup,
          startX: normalizeX(Math.min(ann.x1, ann.x2)),
          startY: normalizeY(Math.min(ann.y1, ann.y2)),
          endX: normalizeX(Math.max(ann.x1, ann.x2)),
          endY: normalizeY(Math.max(ann.y1, ann.y2)),
          text: ann.text || '',
          fontSize: ann.fontSize || 14,
          textColor: ann.textColor || '#000000',
          textAlign: ann.textAlign || 'center',
        };
      }
    }).filter(Boolean); // Filter out null values (empty text annotations)
    
    console.log('=== INFINITEVIEW SAVE DEBUG ===');
    console.log('Saving annotations:', {
      filename: slot.backendFilename,
      page: slot.page,
      newCount: newAnnotations.length,
      ownedCount: ownedAnnotations.length,
      annotationsToRemove,
      canvasSize: { width: canvasWidth, height: canvasHeight }
    });
    
    // Log text annotations specifically
    const textMarkups = markupsToSave.filter(m => m.type === 'text');
    if (textMarkups.length > 0) {
      console.log('=== TEXT ANNOTATIONS BEING SAVED ===');
      textMarkups.forEach(m => {
        console.log({
          id: m.id,
          type: m.type,
          text: m.text,
          textLength: m.text?.length,
          startX: m.startX,
          startY: m.startY,
          endX: m.endX,
          endY: m.endY,
          fontSize: m.fontSize,
          textColor: m.textColor,
          color: m.color,
          borderColor: m.borderColor,
          fillColor: m.fillColor
        });
      });
    }
    
    // Also log raw annotations before conversion
    const rawTextAnnotations = rawMarkups.filter(a => a.type === 'text');
    if (rawTextAnnotations.length > 0) {
      console.log('=== RAW TEXT ANNOTATIONS (before conversion) ===');
      rawTextAnnotations.forEach(a => {
        console.log({
          id: a.id,
          type: a.type,
          text: a.text,
          textLength: a.text?.length,
          x1: a.x1,
          y1: a.y1,
          x2: a.x2,
          y2: a.y2,
          color: a.color,
          textColor: a.textColor
        });
      });
    }
    
    console.log('Converted markups:', markupsToSave.map(m => ({
      id: m.id,
      type: m.type,
      text: m.type === 'text' ? m.text : undefined,
      startX: m.startX?.toFixed(3),
      startY: m.startY?.toFixed(3),
      endX: m.endX?.toFixed(3),
      endY: m.endY?.toFixed(3),
      pointsCount: m.points?.length
    })));

    const response = await fetch('http://localhost:3001/api/pdf/save-markups', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        pdfFilename: slot.backendFilename,
        markups: markupsToSave,
        annotationsToRemove,
        flatten: false,
        saveInPlace: true,
        canvasWidth,
        canvasHeight
      })
    });

    const contentType = response.headers.get('content-type');
    
    if (!response.ok) {
      if (contentType && contentType.includes('application/json')) {
        const errorData = await response.json();
        throw new Error(errorData.error || errorData.details || 'Failed to save annotations');
      }
      throw new Error(`Server error: ${response.status}`);
    }

    if (contentType && contentType.includes('application/json')) {
      const result = await response.json();
      if (result.success) {
        console.log('Saved annotations in place:', result);
        return { success: true };
      } else if (result.error) {
        throw new Error(result.error || 'Failed to save');
      }
    }

    return { success: true };
  } catch (error) {
    console.error('Error saving annotations to PDF:', error);
    return { success: false, error: error.message };
  }
}

// Helper to parse color from PDF annotation
const parseColor = (colorArray) => {
  if (!colorArray || !Array.isArray(colorArray)) return null;
  if (colorArray.length === 3) {
    const [r, g, b] = colorArray.map(c => Math.round(c * 255));
    return `#${r.toString(16).padStart(2, '0')}${g.toString(16).padStart(2, '0')}${b.toString(16).padStart(2, '0')}`;
  }
  return null;
};

// Load annotations from a PDF page and convert to canvas pixel coordinates
// scale should match the scale used to render the PDF canvas (1.5)
const loadPdfAnnotations = async (pdfDoc, pageNum, slotId, scale = 1.5) => {
  try {
    const page = await pdfDoc.getPage(pageNum);
    const annotations = await page.getAnnotations();
    // Use the SAME scale as used for canvas rendering
    const viewport = page.getViewport({ scale, rotation: 0 });
    
    console.log('=== loadPdfAnnotations DEBUG ===');
    console.log('Page:', pageNum, 'Total annotations from PDF.js:', annotations.length);
    console.log('All annotation subtypes:', annotations.map(a => ({ subtype: a.subtype, id: a.id, hasContents: !!a.contents })));
    
    const loadedAnnotations = [];
    
    for (const annot of annotations) {
      // Skip non-markup annotations (links, widgets, popups, etc.)
      if (!['Square', 'Circle', 'Line', 'Ink', 'FreeText', 'Polygon', 'PolyLine'].includes(annot.subtype)) {
        continue;
      }
      
      const [x1, y1, x2, y2] = annot.rect;
      // Use viewport.convertToViewportPoint for correct coordinate conversion
      // This handles both scaling and Y-axis flip properly
      const [canvasX1, canvasY1] = viewport.convertToViewportPoint(x1, y2); // top-left
      const [canvasX2, canvasY2] = viewport.convertToViewportPoint(x2, y1); // bottom-right
      
      // Get colors
      const color = parseColor(annot.color) || '#ff0000';
      const fillColor = parseColor(annot.interiorColor) || 'none';
      
      // Get stroke width - also needs to be scaled
      let strokeWidth = 1;
      if (annot.borderStyle?.width !== undefined) {
        strokeWidth = annot.borderStyle.width * scale;
      } else if (annot.border && annot.border[2] !== undefined) {
        strokeWidth = annot.border[2] * scale;
      } else {
        strokeWidth = scale; // default 1pt scaled
      }
      
      // Get opacity
      const opacity = annot.opacity !== undefined ? annot.opacity : 1;
      
      const commonProps = {
        slotId,
        fromPdf: true,
        pdfAnnotId: annot.id,
        opacity,
        strokeOpacity: opacity,
        fillOpacity: opacity,
      };
      
      let markup = null;
      
      // Generate fallback ID using page number and coordinates
      const fallbackId = `${pageNum}_${Math.round(canvasX1)}_${Math.round(canvasY1)}`;
      
      if (annot.subtype === 'Square') {
        markup = {
          id: `pdf_rect_${annot.id || fallbackId}`,
          type: 'rectangle',
          x1: canvasX1,
          y1: canvasY1,
          x2: canvasX2,
          y2: canvasY2,
          color,
          fillColor,
          strokeWidth,
          ...commonProps
        };
      } else if (annot.subtype === 'Circle') {
        markup = {
          id: `pdf_circle_${annot.id || fallbackId}`,
          type: 'circle',
          x1: canvasX1,
          y1: canvasY1,
          x2: canvasX2,
          y2: canvasY2,
          color,
          fillColor,
          strokeWidth,
          ...commonProps
        };
      } else if (annot.subtype === 'Line') {
        const lineCoords = annot.lineCoordinates || [x1, y1, x2, y2];
        const lineEndings = annot.lineEndings || [];
        const hasArrowAtStart = lineEndings[0] && lineEndings[0] !== 'None' && lineEndings[0].includes('Arrow');
        const hasArrowAtEnd = lineEndings[1] && lineEndings[1] !== 'None' && lineEndings[1].includes('Arrow');
        const hasArrow = hasArrowAtStart || hasArrowAtEnd;
        
        // Convert line endpoints using viewport
        const [lineStartX, lineStartY] = viewport.convertToViewportPoint(lineCoords[0], lineCoords[1]);
        const [lineEndX, lineEndY] = viewport.convertToViewportPoint(lineCoords[2], lineCoords[3]);
        
        const lineType = hasArrow ? 'arrow' : 'line';
        markup = {
          id: `pdf_${lineType}_${annot.id || fallbackId}`,
          type: lineType,
          x1: lineStartX,
          y1: lineStartY,
          x2: lineEndX,
          y2: lineEndY,
          color,
          strokeWidth,
          hasArrowAtStart,
          hasArrowAtEnd,
          ...commonProps
        };
      } else if (annot.subtype === 'Ink') {
        const inkLists = annot.inkLists || (annot.vertices ? [annot.vertices] : null);
        if (inkLists) {
          let inkIndex = 0;
          for (const inkList of inkLists) {
            const points = [];
            if (Array.isArray(inkList) && typeof inkList[0] === 'number') {
              for (let i = 0; i < inkList.length; i += 2) {
                const [px, py] = viewport.convertToViewportPoint(inkList[i], inkList[i + 1]);
                points.push({ x: px, y: py });
              }
            } else if (Array.isArray(inkList)) {
              for (const pt of inkList) {
                if (pt && typeof pt.x === 'number') {
                  const [px, py] = viewport.convertToViewportPoint(pt.x, pt.y);
                  points.push({ x: px, y: py });
                }
              }
            }
            if (points.length > 1) {
              const isHighlighter = strokeWidth > 15 * scale || opacity < 1;
              loadedAnnotations.push({
                id: `pdf_ink_${annot.id || pageNum}_${inkIndex}`,
                type: isHighlighter ? 'highlighter' : 'pen',
                points,
                color,
                strokeWidth: isHighlighter ? strokeWidth : Math.min(strokeWidth, 5 * scale),
                opacity: isHighlighter && opacity === 1 ? 0.4 : opacity,
                ...commonProps
              });
              inkIndex++;
            }
          }
          continue;
        }
      } else if (annot.subtype === 'FreeText') {
        const textContent = annot.contents || annot.richText?.str || '';
        const fontSize = (annot.defaultAppearanceData?.fontSize || 12) * scale;
        
        console.log('=== Loading FreeText annotation ===', {
          id: annot.id,
          text: textContent,
          textLength: textContent.length,
          rect: annot.rect,
          canvasCoords: { x1: canvasX1, y1: canvasY1, x2: canvasX2, y2: canvasY2 },
          color,
          fontSize,
          defaultAppearanceData: annot.defaultAppearanceData
        });
        
        // Load text annotation even if text is empty (user may want to edit an empty box)
        markup = {
          id: `pdf_text_${annot.id || fallbackId}`,
          type: 'text',
          x1: canvasX1,
          y1: canvasY1,
          x2: canvasX2,
          y2: canvasY2,
          text: textContent,
          color,
          textColor: color, // Text color same as annotation color
          fontSize,
          fontFamily: 'Arial',
          textAlign: 'left',
          borderColor: color,
          fillColor: fillColor,
          ...commonProps
        };
      } else if (annot.subtype === 'Polygon' || annot.subtype === 'PolyLine') {
        const vertices = annot.vertices;
        if (vertices && vertices.length >= 4) {
          const points = [];
          for (let i = 0; i < vertices.length; i += 2) {
            const [px, py] = viewport.convertToViewportPoint(vertices[i], vertices[i + 1]);
            points.push({ x: px, y: py });
          }
          markup = {
            id: `pdf_poly_${annot.id || fallbackId}`,
            type: 'polyline',
            points,
            color,
            fillColor: annot.subtype === 'Polygon' ? fillColor : 'none',
            strokeWidth,
            closed: annot.subtype === 'Polygon',
            ...commonProps
          };
        }
      }
      
      if (markup) {
        loadedAnnotations.push(markup);
      }
    }
    
    console.log('=== loadPdfAnnotations RESULT ===');
    console.log('Loaded', loadedAnnotations.length, 'annotations');
    console.log('By type:', loadedAnnotations.reduce((acc, a) => {
      acc[a.type] = (acc[a.type] || 0) + 1;
      return acc;
    }, {}));
    console.log('Text annotations:', loadedAnnotations.filter(a => a.type === 'text').map(a => ({
      id: a.id,
      text: a.text,
      x1: a.x1,
      y1: a.y1,
      x2: a.x2,
      y2: a.y2
    })));
    
    return loadedAnnotations;
  } catch (error) {
    console.error('Error loading PDF annotations:', error);
    return [];
  }
};

export default function InfiniteView({
  initialFile,
  initialPage = 1,
  project,
  allFiles,
  onClose,
  onProjectUpdate,
  onRefresh,
  // Checkout system props
  checkedOutDocuments = {}, // { fileId: 'pdfviewer' | 'infiniteview' }
  onDocumentCheckout,       // (fileId, location) => void - called when unlocking
  onDocumentCheckin         // (fileId) => void - called when locking
}) {
  // Canvas state
  const containerRef = useRef(null);
  const [canvasPosition, setCanvasPosition] = useState({ x: 0, y: 0 });
  const [zoom, setZoom] = useState(0.5); // Start at 50% zoom
  const [isPanning, setIsPanning] = useState(false);
  const [panStart, setPanStart] = useState({ x: 0, y: 0 });
  
  // PDF slots - each represents a loaded PDF at a position
  const [slots, setSlots] = useState([]);
  const [loadingSlots, setLoadingSlots] = useState({});
  
  // The "anchor" slot - the main/current PDF
  const [anchorSlotId, setAnchorSlotId] = useState(null);
  
  // Multi-select for moving multiple PDFs together
  const [selectedSlotIds, setSelectedSlotIds] = useState(new Set());
  
  // Track which slot is being dragged
  const [draggingSlotId, setDraggingSlotId] = useState(null);
  
  // Track if initial load has happened
  const hasLoadedInitial = useRef(false);
  
  // Search state
  const [showAddPdfSearch, setShowAddPdfSearch] = useState(true);
  const [addPdfSearchQuery, setAddPdfSearchQuery] = useState('');
  const [documentPanelTab, setDocumentPanelTab] = useState('all'); // 'all' or 'onCanvas'
  const [showObjectSearch, setShowObjectSearch] = useState(true);
  const [objectSearchQuery, setObjectSearchQuery] = useState('');
  const [highlightedObjectId, setHighlightedObjectId] = useState(null);
  
  // Hidden classes state (same as PDFViewerArea)
  const [hiddenClasses, setHiddenClasses] = useState(new Set());
  
  // Show/hide object tags - default is false (hidden)
  const [showObjectTags, setShowObjectTags] = useState(false);
  
  // Selected object for editing
  const [selectedObject, setSelectedObject] = useState(null);
  const [showObjectDialog, setShowObjectDialog] = useState(false);
  const [objectThumbnail, setObjectThumbnail] = useState(null);
  
  // Animation state - when true, canvas has transition
  const [isAnimating, setIsAnimating] = useState(false);
  const canvasRef = useRef(null);
  
  // Delete confirmation for multi-select
  const [showMultiDeleteConfirm, setShowMultiDeleteConfirm] = useState(false);
  
  // Refresh key - increment to force re-render of objects/hotspots
  const [refreshKey, setRefreshKey] = useState(0);
  
  // Detected objects loaded from backend
  const [detectedObjects, setDetectedObjects] = useState([]);
  const hasLoadedObjectsRef = useRef(false);
  
  // View Options sidebar state
  const [showViewOptions, setShowViewOptions] = useState(false);
  
  // Markups toolbar state
  const [showMarkupsToolbar, setShowMarkupsToolbar] = useState(true);
  const [markupMode, setMarkupMode] = useState(null);
  
  // Annotation state - stored per slot
  const [slotAnnotations, setSlotAnnotations] = useState({}); // { slotId: [annotations] }
  const [currentDrawing, setCurrentDrawing] = useState(null); // Active drawing in progress
  const [isDrawingMarkup, setIsDrawingMarkup] = useState(false);
  const [selectedAnnotation, setSelectedAnnotation] = useState(null); // Currently selected annotation
  const [isDraggingAnnotation, setIsDraggingAnnotation] = useState(false);
  const [isResizingAnnotation, setIsResizingAnnotation] = useState(false);
  const [resizeHandle, setResizeHandle] = useState(null);
  const [annotationDragStart, setAnnotationDragStart] = useState(null);
  const [editingTextId, setEditingTextId] = useState(null); // ID of text box being edited
  const [editingTextValue, setEditingTextValue] = useState(''); // Current text being edited
  const drawingStartRef = useRef(null);
  
  // Track which slots are unlocked for markup editing
  const [unlockedSlots, setUnlockedSlots] = useState(new Set());
  
  // Track which PDF annotations we've "taken over" (clicked to edit)
  // Until owned, PDF annotations are rendered by PDF.js, not our SVG
  const [ownedAnnotationIds, setOwnedAnnotationIds] = useState({}); // { slotId: Set<annotationId> }
  
  // Take ownership of a PDF annotation - delete from PDF bytes and reload
  const takeOwnershipOfAnnotation = useCallback(async (slotId, annotationId) => {
    // Check if already owned
    if (ownedAnnotationIds[slotId]?.has(annotationId)) {
      return;
    }
    
    // Find the slot
    const slot = slots.find(s => s.id === slotId);
    if (!slot || !slot.pdfBytes) {
      console.warn('No slot or PDF bytes for ownership transfer');
      // Still mark as owned even without PDF modification
      setOwnedAnnotationIds(prev => {
        const slotOwned = new Set(prev[slotId] || []);
        slotOwned.add(annotationId);
        return { ...prev, [slotId]: slotOwned };
      });
      return;
    }
    
    // Add to owned set immediately for UI responsiveness
    const newOwnedIds = new Set(ownedAnnotationIds[slotId] || []);
    newOwnedIds.add(annotationId);
    setOwnedAnnotationIds(prev => ({ ...prev, [slotId]: newOwnedIds }));
    
    // Delete annotation from PDF
    const modifiedBytes = await deleteAnnotationsFromPdf(slot.pdfBytes, newOwnedIds);
    
    if (modifiedBytes) {
      try {
        // Revoke old URL
        if (slot.blobUrl) {
          URL.revokeObjectURL(slot.blobUrl);
        }
        
        // Create new blob and URL
        const newBlob = new Blob([modifiedBytes], { type: 'application/pdf' });
        const newUrl = URL.createObjectURL(newBlob);
        
        // Load the modified PDF
        const newPdfDoc = await window.pdfjsLib.getDocument({ data: modifiedBytes.slice(0) }).promise;
        
        // Update the slot with new PDF
        setSlots(prev => prev.map(s => {
          if (s.id === slotId) {
            return {
              ...s,
              pdfDoc: newPdfDoc,
              blobUrl: newUrl,
              pdfBytes: modifiedBytes,
              // Increment a render key to force re-render
              renderKey: (s.renderKey || 0) + 1
            };
          }
          return s;
        }));
        
        console.log('PDF reloaded after taking ownership of annotation:', annotationId);
      } catch (error) {
        console.error('Error reloading PDF after annotation deletion:', error);
      }
    }
  }, [slots, ownedAnnotationIds]);
  
  // Markup properties
  const [markupColor, setMarkupColor] = useState('#ff0000');
  const [markupStrokeWidth, setMarkupStrokeWidth] = useState(2);
  const [markupOpacity, setMarkupOpacity] = useState(0.4); // For highlighter
  const [markupFillColor, setMarkupFillColor] = useState('none');
  const [markupFillOpacity, setMarkupFillOpacity] = useState(0.3);
  const [markupStrokeOpacity, setMarkupStrokeOpacity] = useState(1);
  const [markupArrowHeadSize, setMarkupArrowHeadSize] = useState(12);
  const [markupLineStyle, setMarkupLineStyle] = useState('solid');
  
  // Text markup options
  const [markupFontSize, setMarkupFontSize] = useState(14);
  const [markupFontFamily, setMarkupFontFamily] = useState('Arial');
  const [markupTextAlign, setMarkupTextAlign] = useState('left');
  
  // Cloud markup options
  const [markupCloudArcSize, setMarkupCloudArcSize] = useState(15);
  const [markupCloudIntensity, setMarkupCloudIntensity] = useState(1);
  
  // Load tool defaults from localStorage
  const loadToolDefaults = (tool) => {
    try {
      const saved = localStorage.getItem(`infiniteView_${tool}Defaults`);
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  };
  
  // Save tool defaults to localStorage
  const saveToolDefaults = (tool, settings) => {
    try {
      localStorage.setItem(`infiniteView_${tool}Defaults`, JSON.stringify(settings));
    } catch (e) {
      console.warn('Failed to save tool defaults:', e);
    }
  };
  
  // Apply defaults when tool changes
  useEffect(() => {
    if (!markupMode) return;
    
    const defaults = loadToolDefaults(markupMode);
    if (defaults) {
      if (defaults.color !== undefined) setMarkupColor(defaults.color);
      if (defaults.strokeWidth !== undefined) setMarkupStrokeWidth(defaults.strokeWidth);
      if (defaults.opacity !== undefined) setMarkupOpacity(defaults.opacity);
      if (defaults.fillColor !== undefined) setMarkupFillColor(defaults.fillColor);
      if (defaults.fillOpacity !== undefined) setMarkupFillOpacity(defaults.fillOpacity);
      if (defaults.strokeOpacity !== undefined) setMarkupStrokeOpacity(defaults.strokeOpacity);
      if (defaults.lineStyle !== undefined) setMarkupLineStyle(defaults.lineStyle);
      if (defaults.arrowHeadSize !== undefined) setMarkupArrowHeadSize(defaults.arrowHeadSize);
      if (defaults.fontSize !== undefined) setMarkupFontSize(defaults.fontSize);
      if (defaults.fontFamily !== undefined) setMarkupFontFamily(defaults.fontFamily);
      if (defaults.textAlign !== undefined) setMarkupTextAlign(defaults.textAlign);
      if (defaults.cloudArcSize !== undefined) setMarkupCloudArcSize(defaults.cloudArcSize);
      if (defaults.cloudIntensity !== undefined) setMarkupCloudIntensity(defaults.cloudIntensity);
    }
  }, [markupMode]);
  
  // Crop region state - normalized coordinates (0-1)
  const [cropRegion, setCropRegion] = useState(null); // { x, y, width, height }
  const [cropEnabled, setCropEnabled] = useState(false);
  const [isDrawingCrop, setIsDrawingCrop] = useState(false);
  
  // Background style state - persist to localStorage
  const [backgroundStyle, setBackgroundStyle] = useState(() => {
    try {
      return localStorage.getItem('infiniteView_backgroundStyle') || 'grid';
    } catch {
      return 'grid';
    }
  });
  
  // Show/hide borders and shadows on PDFs - persist to localStorage
  const [showShadows, setShowShadows] = useState(() => {
    try {
      const saved = localStorage.getItem('infiniteView_showShadows');
      return saved === 'true'; // default false
    } catch {
      return false;
    }
  });
  
  // Persist background style to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('infiniteView_backgroundStyle', backgroundStyle);
    } catch (e) {
      console.error('Error saving background style:', e);
    }
  }, [backgroundStyle]);
  
  // Persist showShadows to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('infiniteView_showShadows', showShadows.toString());
    } catch (e) {
      console.error('Error saving showShadows:', e);
    }
  }, [showShadows]);
  
  // Keyboard event handler for Delete key
  useEffect(() => {
    const handleKeyDown = (e) => {
      // Don't trigger if typing in an input/textarea
      if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;
      
      if (e.key === 'Delete' || e.key === 'Backspace') {
        if (selectedSlotIds.size > 0) {
          e.preventDefault();
          setShowMultiDeleteConfirm(true);
        }
      }
      // Escape to clear selection, cancel crop drawing, or deselect markup tool
      if (e.key === 'Escape') {
        // First close text editing if active (and save it)
        if (editingTextId) {
          // Text will be saved by the blur handler
          setEditingTextId(null);
          setEditingTextValue('');
          return;
        }
        if (markupMode) {
          setMarkupMode(null);
          setSelectedAnnotation(null);
        } else if (isDrawingCrop) {
          setIsDrawingCrop(false);
          setCurrentTool('select');
        } else if (selectedAnnotation) {
          setSelectedAnnotation(null);
        } else {
          setSelectedSlotIds(new Set());
          setShowMultiDeleteConfirm(false);
        }
      }
      // Tool shortcuts (only when not in text input)
      // V = select, Shift+V = pan, M = move, Z = zoom
      // Use toLowerCase() to handle caps lock
      const key = e.key.toLowerCase();
      
      if (key === 'v' && !e.shiftKey) {
        e.preventDefault();
        setCurrentTool('select');
        setMarkupMode(null);
        setSelectedAnnotation(null);
      }
      if (key === 'v' && e.shiftKey) {
        e.preventDefault();
        setCurrentTool('pan');
        setMarkupMode(null);
      }
      if (key === 'm') {
        e.preventDefault();
        setCurrentTool('move');
        setMarkupMode(null);
      }
      if (key === 'z') {
        e.preventDefault();
        setCurrentTool('zoom');
        setMarkupMode(null);
      }
      // Delete selected annotation
      if ((e.key === 'Delete' || e.key === 'Backspace') && selectedAnnotation) {
        e.preventDefault();
        setSlotAnnotations(prev => ({
          ...prev,
          [selectedAnnotation.slotId]: (prev[selectedAnnotation.slotId] || []).filter(a => a.id !== selectedAnnotation.id)
        }));
        setSelectedAnnotation(null);
      }
      
      // Markup tool shortcuts (only work when at least one slot is unlocked)
      const hasUnlockedSlot = unlockedSlots.size > 0;
      if (hasUnlockedSlot) {
        // H = highlighter
        if (key === 'h') {
          e.preventDefault();
          setMarkupMode(markupMode === 'highlighter' ? null : 'highlighter');
        }
        // P = pen
        if (key === 'p') {
          e.preventDefault();
          setMarkupMode(markupMode === 'pen' ? null : 'pen');
        }
        // a = arrow, Shift+A = polylineArrow
        if (key === 'a' && !e.shiftKey) {
          e.preventDefault();
          setMarkupMode(markupMode === 'arrow' ? null : 'arrow');
        }
        if (key === 'a' && e.shiftKey) {
          e.preventDefault();
          setMarkupMode(markupMode === 'polylineArrow' ? null : 'polylineArrow');
        }
        // l = line, Shift+L = polyline
        if (key === 'l' && !e.shiftKey) {
          e.preventDefault();
          setMarkupMode(markupMode === 'line' ? null : 'line');
        }
        if (key === 'l' && e.shiftKey) {
          e.preventDefault();
          setMarkupMode(markupMode === 'polyline' ? null : 'polyline');
        }
        // r = rectangle, Shift+R = arc
        if (key === 'r' && !e.shiftKey) {
          e.preventDefault();
          setMarkupMode(markupMode === 'rectangle' ? null : 'rectangle');
        }
        if (key === 'r' && e.shiftKey) {
          e.preventDefault();
          setMarkupMode(markupMode === 'arc' ? null : 'arc');
        }
        // E = ellipse (circle)
        if (key === 'e') {
          e.preventDefault();
          setMarkupMode(markupMode === 'circle' ? null : 'circle');
        }
        // c = cloud, Shift+C = cloudPolyline (poly cloud)
        if (key === 'c' && !e.shiftKey) {
          e.preventDefault();
          setMarkupMode(markupMode === 'cloud' ? null : 'cloud');
        }
        if (key === 'c' && e.shiftKey) {
          e.preventDefault();
          setMarkupMode(markupMode === 'cloudPolyline' ? null : 'cloudPolyline');
        }
        // T = text box
        if (key === 't') {
          e.preventDefault();
          setMarkupMode(markupMode === 'text' ? null : 'text');
        }
      }
    };
    
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [selectedSlotIds, isDrawingCrop, markupMode, selectedAnnotation, editingTextId, unlockedSlots]);
  
  // Check if any slots have unsaved changes
  const hasAnyUnsavedChanges = useCallback(() => {
    for (const slot of slots) {
      const annotations = slotAnnotations[slot.id] || [];
      const ownedIds = ownedAnnotationIds[slot.id] || new Set();
      const hasChanges = annotations.some(a => !a.fromPdf) || ownedIds.size > 0;
      if (hasChanges) return true;
    }
    return false;
  }, [slots, slotAnnotations, ownedAnnotationIds]);
  
  // Warn user before leaving if there are unsaved changes
  useEffect(() => {
    const handleBeforeUnload = (e) => {
      if (hasAnyUnsavedChanges()) {
        const message = 'You have unsaved markup changes. Are you sure you want to leave?';
        e.preventDefault();
        e.returnValue = message;
        return message;
      }
    };
    
    window.addEventListener('beforeunload', handleBeforeUnload);
    return () => window.removeEventListener('beforeunload', handleBeforeUnload);
  }, [hasAnyUnsavedChanges]);
  
  // Load initial PDF - center it on the canvas
  useEffect(() => {
    if (initialFile && !hasLoadedInitial.current) {
      hasLoadedInitial.current = true;
      loadPdfAtPosition(initialFile, initialPage, 0, 0, true);
    }
  }, [initialFile]);
  
  // Load a PDF at a specific canvas position
  const loadPdfAtPosition = async (file, page, x, y, isAnchor = false) => {
    const slotId = `${file.id}_page_${page}_${Date.now()}`;
    
    setLoadingSlots(prev => ({ ...prev, [slotId]: true }));
    
    try {
      const response = await fetch(`http://localhost:3001/api/files/${encodeURIComponent(file.backendFilename)}`);
      const blob = await response.blob();
      const arrayBuffer = await blob.arrayBuffer();
      const url = URL.createObjectURL(blob);
      
      if (!window.pdfjsLib) {
        console.error('pdfjsLib not loaded yet');
        return;
      }
      const loadedPdf = await window.pdfjsLib.getDocument({ data: arrayBuffer.slice(0) }).promise;
      
      // Load annotations from the PDF page with the same scale used for canvas rendering (1.5)
      const pdfAnnotations = await loadPdfAnnotations(loadedPdf, page, slotId, 1.5);
      if (pdfAnnotations.length > 0) {
        console.log(`Loaded ${pdfAnnotations.length} annotations from PDF`);
        setSlotAnnotations(prev => ({
          ...prev,
          [slotId]: [...(prev[slotId] || []), ...pdfAnnotations]
        }));
      }
      
      const newSlot = {
        id: slotId,
        fileId: file.id,
        backendFilename: file.backendFilename,
        fileName: file.name,
        page: page,
        pdfDoc: loadedPdf,
        numPages: loadedPdf.numPages,
        blobUrl: url,
        pdfBytes: arrayBuffer, // Store original PDF bytes for annotation deletion
        x: x, // Canvas position X
        y: y, // Canvas position Y
        width: 0, // Will be set after render
        height: 0,
      };
      
      setSlots(prev => [...prev, newSlot]);
      
      if (isAnchor) {
        setAnchorSlotId(slotId);
      }
      
      return newSlot;
    } catch (error) {
      console.error('Error loading PDF:', error);
      return null;
    } finally {
      setLoadingSlots(prev => {
        const newState = { ...prev };
        delete newState[slotId];
        return newState;
      });
    }
  };
  
  // Calculate the bounding box and center of all slots
  const getSlotsBounds = () => {
    if (slots.length === 0) {
      return { centerX: 0, centerY: 0, width: 0, height: 0 };
    }
    
    let minX = Infinity, maxX = -Infinity;
    let minY = Infinity, maxY = -Infinity;
    
    slots.forEach(slot => {
      const slotWidth = slot.width || 800;
      const slotHeight = slot.height || 600;
      const left = slot.x - slotWidth / 2;
      const right = slot.x + slotWidth / 2;
      const top = slot.y - slotHeight / 2;
      const bottom = slot.y + slotHeight / 2;
      
      if (left < minX) minX = left;
      if (right > maxX) maxX = right;
      if (top < minY) minY = top;
      if (bottom > maxY) maxY = bottom;
    });
    
    const centerX = (minX + maxX) / 2;
    const centerY = (minY + maxY) / 2;
    const width = maxX - minX;
    const height = maxY - minY;
    
    return { centerX, centerY, width, height, minX, maxX, minY, maxY };
  };
  
  // Zoom to fit all slots in view
  const zoomToFitAll = () => {
    const bounds = getSlotsBounds();
    if (bounds.width === 0 && bounds.height === 0) {
      setZoom(0.5);
      setCanvasPosition({ x: 0, y: 0 });
      return;
    }
    
    // Get container size
    const container = containerRef.current;
    if (!container) return;
    
    const containerWidth = container.clientWidth;
    const containerHeight = container.clientHeight;
    
    // Calculate zoom to fit with some padding
    const padding = 100;
    const zoomX = (containerWidth - padding * 2) / bounds.width;
    const zoomY = (containerHeight - padding * 2) / bounds.height;
    const newZoom = Math.min(zoomX, zoomY, 1); // Don't zoom in past 100%
    
    setIsAnimating(true);
    setZoom(Math.max(0.05, newZoom)); // Minimum 5% zoom
    setCanvasPosition({
      x: -bounds.centerX * newZoom,
      y: -bounds.centerY * newZoom
    });
    setTimeout(() => setIsAnimating(false), 600);
  };
  
  // Go to center of all slots at default zoom
  const resetToCenter = () => {
    const bounds = getSlotsBounds();
    setIsAnimating(true);
    setZoom(0.5);
    setCanvasPosition({
      x: -bounds.centerX * 0.5,
      y: -bounds.centerY * 0.5
    });
    setTimeout(() => setIsAnimating(false), 600);
  };
  
  // Zoom to a specific slot at specified zoom level
  const zoomToSlot = (slot, targetZoom = 0.8) => {
    setIsAnimating(true);
    setZoom(targetZoom);
    setCanvasPosition({
      x: -slot.x * targetZoom,
      y: -slot.y * targetZoom
    });
    setTimeout(() => setIsAnimating(false), 600);
  };
  
  // Smart positioning - move existing PDFs out of the way, insert new one at target
  const findSmartPosition = (targetX, targetY, newSlotWidth, newSlotHeight, sourceSlot = null) => {
    const gap = 100;
    const rowTolerance = 150;
    const columnTolerance = 200; // How close X values need to be to be considered same column
    const slotHeight = newSlotHeight || 600;
    const slotWidth = newSlotWidth || 800;
    
    // Find slot that's currently at or near the target position
    const blockingSlot = slots.find(s => {
      if (sourceSlot && s.id === sourceSlot.id) return false; // Don't count source as blocking
      const sWidth = s.width || 800;
      const sHeight = s.height || 600;
      const overlapX = Math.abs(s.x - targetX) < (sWidth + slotWidth) / 2;
      const overlapY = Math.abs(s.y - targetY) < (sHeight + slotHeight) / 2;
      return overlapX && overlapY;
    });
    
    // If no blocking slot, just use target position
    if (!blockingSlot) {
      return { x: targetX, y: targetY, slotsToMove: [] };
    }
    
    // There's a PDF in the way - need to move it (and PDFs in same column) up or down
    const getRowY = (y) => Math.round(y / rowTolerance) * rowTolerance;
    const blockingRowY = getRowY(blockingSlot.y);
    
    // Get all slots excluding source slot
    const allSlots = sourceSlot 
      ? slots.filter(s => s.id !== sourceSlot.id)
      : slots;
    
    // Only consider slots in the same column area (similar X position to target)
    const slotsInColumn = allSlots.filter(s => 
      Math.abs(s.x - targetX) < columnTolerance + (s.width || 800) / 2
    );
    
    const rowYValues = [...new Set(slotsInColumn.map(s => getRowY(s.y)))].sort((a, b) => a - b);
    const rowsAbove = rowYValues.filter(y => y < blockingRowY);
    const rowsBelow = rowYValues.filter(y => y > blockingRowY);
    
    // Calculate how much space we need - the new slot height plus gap
    const spaceNeeded = slotHeight + gap;
    
    let slotsToMove = [];
    
    // Default: push blocking row and everything above it UP (only in same column)
    if (rowsAbove.length <= rowsBelow.length) {
      // Find slots in the same column at or above the blocking row
      const slotsToMoveUp = slotsInColumn.filter(s => getRowY(s.y) <= blockingRowY);
      
      slotsToMove = slotsToMoveUp.map(s => ({
        id: s.id,
        newY: s.y - spaceNeeded
      }));
    } else {
      // Push slots in the same column at or below blocking row DOWN
      const slotsToMoveDown = slotsInColumn.filter(s => getRowY(s.y) >= blockingRowY);
      
      slotsToMove = slotsToMoveDown.map(s => ({
        id: s.id,
        newY: s.y + spaceNeeded
      }));
    }
    
    // New PDF goes at the original target position
    return { x: targetX, y: targetY, slotsToMove };
  };
  
  // Apply slot movements
  const applySlotMovements = (slotsToMove) => {
    if (slotsToMove.length === 0) return;
    
    setSlots(prev => prev.map(s => {
      const movement = slotsToMove.find(m => m.id === s.id);
      if (movement) {
        return { ...s, y: movement.newY };
      }
      return s;
    }));
  };
  
  // Animated transition helper
  const animateToPosition = (targetZoom, targetX, targetY, duration = 600) => {
    return new Promise(resolve => {
      setIsAnimating(true);
      setZoom(targetZoom);
      setCanvasPosition({ x: targetX, y: targetY });
      setTimeout(() => {
        setIsAnimating(false);
        resolve();
      }, duration);
    });
  };
  
  // Navigate to an object - always animate to 60% zoom
  const navigateToObject = async (obj) => {
    const targetZoom = 0.8;
    
    // obj.page is 0-indexed, slot.page is 1-indexed
    const targetPage = (obj.page || 0) + 1;
    
    // Find the slot containing this object (same file, any page for now)
    let targetSlot = slots.find(s => s.backendFilename === obj.filename);
    
    if (!targetSlot) {
      // Need to load the PDF
      const file = allFiles.find(f => f.backendFilename === obj.filename);
      if (!file) return;
      
      const lastSlot = slots[slots.length - 1];
      const targetX = lastSlot ? lastSlot.x + (lastSlot.width || 800) + 100 : 0;
      const targetY = lastSlot ? lastSlot.y : 0;
      
      // Use smart positioning
      const { x, y, slotsToMove } = findSmartPosition(targetX, targetY, 800, 600);
      applySlotMovements(slotsToMove);
      
      // Load the PDF
      await loadPdfAtPosition(file, targetPage, x, y);
      
      // Wait for render and get the slot
      await new Promise(r => setTimeout(r, 500));
      
      // Find the newly created slot
      targetSlot = slots.find(s => s.backendFilename === obj.filename);
      if (!targetSlot) {
        // Fallback position
        targetSlot = { x, y, width: 800, height: 600 };
      }
    } else if (targetSlot.page !== targetPage) {
      // Update to correct page
      setSlots(prev => prev.map(s => 
        s.id === targetSlot.id 
          ? { ...s, page: targetPage }
          : s
      ));
    }
    
    // Use slot dimensions or defaults
    const slotWidth = targetSlot.width || 800;
    const slotHeight = targetSlot.height || 600;
    
    // Calculate the object's center position within the PDF
    let objectCenterX = targetSlot.x;
    let objectCenterY = targetSlot.y;
    
    if (obj.bbox) {
      // bbox can be {x, y, width, height} (normalized) or [x1, y1, x2, y2]
      let objCenterNormX, objCenterNormY;
      
      if (Array.isArray(obj.bbox)) {
        // [x1, y1, x2, y2] format
        const [x1, y1, x2, y2] = obj.bbox;
        objCenterNormX = (x1 + x2) / 2;
        objCenterNormY = (y1 + y2) / 2;
      } else {
        // {x, y, width, height} format
        objCenterNormX = obj.bbox.x + obj.bbox.width / 2;
        objCenterNormY = obj.bbox.y + obj.bbox.height / 2;
      }
      
      // Convert to canvas coordinates
      // Slot position is at center, so offset from top-left
      const slotLeft = targetSlot.x - slotWidth / 2;
      const slotTop = targetSlot.y - slotHeight / 2;
      
      objectCenterX = slotLeft + objCenterNormX * slotWidth;
      objectCenterY = slotTop + objCenterNormY * slotHeight;
    }
    
    // Animate to center on the object
    setIsAnimating(true);
    setZoom(targetZoom);
    setCanvasPosition({
      x: -objectCenterX * targetZoom,
      y: -objectCenterY * targetZoom
    });
    setTimeout(() => setIsAnimating(false), 600);
    
    // Highlight the object
    setHighlightedObjectId(obj.id);
    setTimeout(() => setHighlightedObjectId(null), 3000);
    
    // Keep panel open - only close with X button
  };
  
  // Load detected objects from backend
  useEffect(() => {
    const loadObjects = async () => {
      if (!project?.id) return;
      
      // Only skip on initial load if already loaded
      if (hasLoadedObjectsRef.current && refreshKey === 0) return;
      
      try {
        hasLoadedObjectsRef.current = true;
        const objects = await getObjectsFromBackend(project.id);
        
        if (objects.length > 0) {
          console.log(`InfiniteView: Loaded ${objects.length} objects from backend`);
          setDetectedObjects(objects);
        } else if (project?.detectedObjects?.length > 0) {
          // Fallback to project.detectedObjects if no backend data
          console.log(`InfiniteView: Using ${project.detectedObjects.length} objects from project`);
          setDetectedObjects(project.detectedObjects);
        }
      } catch (error) {
        console.error('InfiniteView: Failed to load objects from backend:', error);
        // Fallback to project.detectedObjects
        if (project?.detectedObjects) {
          setDetectedObjects(project.detectedObjects);
        }
      }
    };
    
    loadObjects();
  }, [project?.id, refreshKey]);
  
  // Get all detected objects - use loaded state, fallback to project
  const allDetectedObjects = useMemo(() => {
    if (detectedObjects.length > 0) return detectedObjects;
    if (project?.detectedObjects) return project.detectedObjects;
    return [];
  }, [detectedObjects, project?.detectedObjects]);
  
  // Get all unique classes from detected objects
  const availableClasses = useMemo(() => {
    const classes = new Set();
    allDetectedObjects.forEach(obj => {
      if (obj.label) classes.add(obj.label);
      if (obj.className) classes.add(obj.className);
    });
    return [...classes].sort();
  }, [allDetectedObjects]);
  
  // Filter objects based on search - show all if no query
  const filteredObjects = useMemo(() => {
    if (!objectSearchQuery.trim()) return allDetectedObjects.slice(0, 50);
    const query = objectSearchQuery.toLowerCase();
    return allDetectedObjects.filter(obj => {
      // Search in OCR text
      if (obj.ocr_text?.toLowerCase().includes(query)) return true;
      // Search in label/className
      if (obj.label?.toLowerCase().includes(query)) return true;
      if (obj.className?.toLowerCase().includes(query)) return true;
      if (obj.description?.toLowerCase().includes(query)) return true;
      // Search in subclass values (e.g., Tag, Value, etc.)
      if (obj.subclassValues) {
        for (const val of Object.values(obj.subclassValues)) {
          if (val?.toLowerCase().includes(query)) return true;
        }
      }
      return false;
    }).slice(0, 50);
  }, [objectSearchQuery, allDetectedObjects]);
  
  // Helper to get class colors (fillColor and borderColor) for display
  const getClassColors = useCallback((className) => {
    if (!className) return { fillColor: 'none', borderColor: '#3498db' };
    
    const classes = project?.classes || [];
    
    // Find the class definition
    let cls = classes.find(c => c.name === className && !c.parentId);
    if (!cls) {
      cls = classes.find(c => c.name === className);
    }
    if (!cls && className.includes(' > ')) {
      const parentName = className.split(' > ')[0];
      cls = classes.find(c => c.name === parentName && !c.parentId);
    }
    
    if (cls) {
      return {
        fillColor: cls.fillColor || 'none',
        borderColor: cls.borderColor || cls.color || '#3498db'
      };
    }
    
    // Generate consistent color based on name
    const defaultColors = [
      '#3498db', '#e74c3c', '#2ecc71', '#9b59b6',
      '#1abc9c', '#e91e63', '#9c27b0', '#00bcd4'
    ];
    let hash = 0;
    for (let i = 0; i < className.length; i++) {
      hash = className.charCodeAt(i) + ((hash << 5) - hash);
    }
    const color = defaultColors[Math.abs(hash) % defaultColors.length];
    return { fillColor: 'none', borderColor: color };
  }, [project?.classes]);
  
  // Filter files for add PDF search - show all if no query
  const filteredFiles = useMemo(() => {
    if (!addPdfSearchQuery.trim()) return allFiles.slice(0, 50);
    const query = addPdfSearchQuery.toLowerCase();
    return allFiles.filter(f => 
      f.name.toLowerCase().includes(query)
    ).slice(0, 50);
  }, [addPdfSearchQuery, allFiles]);
  
  // Handle hotspot click - load linked PDF adjacent to current, with smart positioning
  const handleHotspotClick = async (hotspot, sourceSlot) => {
    if (!hotspot.targetFileId) return;
    
    const targetFile = allFiles.find(f => f.id === hotspot.targetFileId);
    if (!targetFile) return;
    
    // Determine target position based on hotspot location
    const isLeftSide = hotspot.x < 0.5;
    const targetPage = hotspot.targetPage || 1;
    
    // Calculate where the PDF should go (next to the source)
    const gap = 100; // Gap between PDFs
    const slotWidth = sourceSlot.width || 800;
    const slotHeight = sourceSlot.height || 600;
    let targetX, targetY;
    
    if (isLeftSide) {
      // Place to the left of source
      targetX = sourceSlot.x - slotWidth - gap;
      targetY = sourceSlot.y;
    } else {
      // Place to the right of source
      targetX = sourceSlot.x + slotWidth + gap;
      targetY = sourceSlot.y;
    }
    
    // Check if already loaded
    const existingSlot = slots.find(s => s.fileId === targetFile.id);
    if (existingSlot) {
      // Check if it's already in the correct position (with some tolerance)
      const tolerance = 50;
      const isInCorrectPosition = 
        Math.abs(existingSlot.x - targetX) < tolerance && 
        Math.abs(existingSlot.y - targetY) < tolerance;
      
      if (!isInCorrectPosition) {
        // Use smart positioning for existing slot
        const { x, y, slotsToMove } = findSmartPosition(targetX, targetY, slotWidth, slotHeight, sourceSlot);
        applySlotMovements(slotsToMove);
        
        // Move the existing slot to the target position
        setSlots(prev => prev.map(s => 
          s.id === existingSlot.id 
            ? { ...s, x, y, page: targetPage }
            : s
        ));
      }
      return;
    }
    
    // Use smart positioning for new slot - pass sourceSlot for context
    const { x, y, slotsToMove } = findSmartPosition(targetX, targetY, slotWidth, slotHeight, sourceSlot);
    applySlotMovements(slotsToMove);
    
    // Load new PDF at smart position
    await loadPdfAtPosition(targetFile, targetPage, x, y);
  };
  
  // Pan handlers - only pan canvas when not dragging a slot
  const handleMouseDown = (e) => {
    // Don't start panning if clicking on a hotspot or delete button
    if (e.target.closest('.infinite-hotspot') || e.target.closest('.slot-delete-btn')) {
      return;
    }
    if (e.button === 0 || e.button === 1) { // Left or middle click
      setIsPanning(true);
      setPanStart({
        x: e.clientX - canvasPosition.x,
        y: e.clientY - canvasPosition.y
      });
    }
  };
  
  const handleMouseMove = (e) => {
    if (isPanning && !draggingSlotId) {
      setCanvasPosition({
        x: e.clientX - panStart.x,
        y: e.clientY - panStart.y
      });
    }
  };
  
  const handleMouseUp = () => {
    setIsPanning(false);
  };
  
  // Update slot dimensions after render
  const updateSlotDimensions = (slotId, width, height) => {
    setSlots(prev => prev.map(s => 
      s.id === slotId ? { ...s, width, height } : s
    ));
  };
  
  // Cleanup blob URLs
  useEffect(() => {
    return () => {
      slots.forEach(slot => {
        if (slot.blobUrl) {
          URL.revokeObjectURL(slot.blobUrl);
        }
      });
    };
  }, []);

  // Attach wheel listener with passive: false to prevent browser zoom
  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const wheelHandler = (e) => {
      e.preventDefault();
      e.stopPropagation();
      
      // Get cursor position relative to container center
      const rect = container.getBoundingClientRect();
      const cursorX = e.clientX - rect.left - rect.width / 2;
      const cursorY = e.clientY - rect.top - rect.height / 2;
      
      // Calculate the point on the canvas under the cursor (before zoom)
      const canvasPointX = (cursorX - canvasPosition.x) / zoom;
      const canvasPointY = (cursorY - canvasPosition.y) / zoom;
      
      // Aggressive multiplicative zoom like Revu
      const factor = 1.4; // Aggressive zoom per scroll tick
      const newZoom = e.deltaY > 0 
        ? Math.max(0.05, zoom / factor)  // Zoom out - allow down to 5%
        : Math.min(10, zoom * factor);    // Zoom in - allow up to 1000%
      
      // Calculate new canvas position to keep the same point under cursor
      const newCanvasX = cursorX - canvasPointX * newZoom;
      const newCanvasY = cursorY - canvasPointY * newZoom;
      
      setZoom(newZoom);
      setCanvasPosition({ x: newCanvasX, y: newCanvasY });
    };

    container.addEventListener('wheel', wheelHandler, { passive: false });
    
    return () => {
      container.removeEventListener('wheel', wheelHandler);
    };
  }, [zoom, canvasPosition]);

  // Current tool mode
  const [currentTool, setCurrentTool] = useState('select'); // 'select', 'pan', 'move', 'zoom', 'crop'
  
  // Get cursor based on tool
  const getCursor = () => {
    if (draggingSlotId) return 'grabbing';
    if (currentTool === 'crop' || isDrawingCrop) return 'crosshair';
    switch (currentTool) {
      case 'select': return 'default';
      case 'pan': return isPanning ? 'grabbing' : 'grab';
      case 'move': return 'default';
      case 'zoom': return 'zoom-in';
      default: return 'default';
    }
  };
  
  // Handle crop region completion
  const handleCropComplete = (region) => {
    setCropRegion(region);
    setCropEnabled(true);
    setIsDrawingCrop(false);
    setCurrentTool('select');
  };
  
  // Clear crop region
  const clearCropRegion = () => {
    setCropRegion(null);
    setCropEnabled(false);
  };

  return (
    <div className="infinite-view">
      {/* Header */}
      <div className="infinite-view-header">
        <div className="header-top-row">
          <button className="back-btn" onClick={() => {
            if (hasAnyUnsavedChanges()) {
              const confirmLeave = window.confirm(
                'You have unsaved markup changes.\n\nAre you sure you want to leave? All unsaved changes will be lost.'
              );
              if (!confirmLeave) return;
            }
            onClose?.();
          }}>
            ← Back to Home
          </button>
          <span className="header-title">
            {project?.name || 'Project'} <span className="header-separator">-</span> Infinite View
          </span>
          <span className="header-brand">pidly</span>
        </div>
        
        {/* Second row - toolbar buttons */}
        <div className="header-toolbar-row">
          <button 
            className={`toolbar-btn ${showAddPdfSearch ? 'active' : ''}`}
            onClick={() => {
              setShowAddPdfSearch(!showAddPdfSearch);
            }}
            title="Browse documents"
          >
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
              <polyline points="14 2 14 8 20 8"/>
            </svg>
            Documents
          </button>
          
          <div className="toolbar-spacer" />
          
          <button 
            className={`toolbar-btn ${showObjectSearch ? 'active' : ''}`}
            onClick={() => {
              setShowObjectSearch(!showObjectSearch);
              setShowViewOptions(false);
            }}
            title="Search for objects"
          >
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <circle cx="11" cy="11" r="8"/>
              <path d="m21 21-4.35-4.35"/>
            </svg>
            Search
          </button>
          
          <button 
            className={`toolbar-btn ${showViewOptions ? 'active' : ''}`}
            onClick={() => {
              setShowViewOptions(!showViewOptions);
              setShowObjectSearch(false);
            }}
            title="View Options"
          >
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <circle cx="12" cy="12" r="3"/>
              <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/>
            </svg>
            Options
          </button>
        </div>
      </div>
      
      {/* Content area - canvas and panels */}
      <div className="infinite-view-content">
        {/* Add PDF Search Panel - LEFT SIDE */}
        {showAddPdfSearch && (
          <div className="smart-links-panel left-panel">
            <div className="panel-header">
              <h3>Documents</h3>
              <button className="close-panel" onClick={() => setShowAddPdfSearch(false)}>×</button>
            </div>
            <div className="panel-content" style={{ gap: 0 }}>
              {/* Tab buttons */}
              <div className="panel-tabs" style={{ marginBottom: '8px' }}>
                <button 
                  className={`panel-tab ${documentPanelTab === 'all' ? 'active' : ''}`}
                  onClick={() => setDocumentPanelTab('all')}
                >
                  All
                </button>
                <button 
                  className={`panel-tab ${documentPanelTab === 'onCanvas' ? 'active' : ''}`}
                  onClick={() => setDocumentPanelTab('onCanvas')}
                >
                  On Canvas
                </button>
              </div>
              <div style={{ margin: 0, padding: 0, marginBottom: '4px' }}>
                <input
                  type="text"
                  placeholder="Filter documents..."
                  value={addPdfSearchQuery}
                  onChange={(e) => setAddPdfSearchQuery(e.target.value)}
                  className="iv-search-input"
                  style={{ margin: 0 }}
                  autoFocus
                />
              </div>
              <div style={{ flex: 1, minHeight: 0, display: 'flex', flexDirection: 'column', margin: 0, padding: 0 }}>
                <div className="iv-doc-list" style={{ flex: 1, overflowY: 'auto', margin: 0, padding: 0 }}>
                {documentPanelTab === 'onCanvas' ? (
                  /* On Canvas tab - show slots with unlock buttons */
                  slots.length === 0 ? (
                    <div className="empty-canvas-message" style={{ padding: '20px', textAlign: 'center', color: '#888', fontSize: '13px' }}>
                      No documents on canvas yet.<br/>
                      <span style={{ fontSize: '11px' }}>Switch to "All" tab to add documents.</span>
                    </div>
                  ) : (
                    <>
                      {/* Unlock All / Lock All button */}
                      <div style={{ 
                        padding: '4px 12px'
                      }}>
                        {(() => {
                          const allUnlocked = slots.every(slot => unlockedSlots.has(slot.id));
                          
                          return (
                            <button
                              onClick={async () => {
                                if (allUnlocked) {
                                  // Force-save any text being edited
                                  if (editingTextId) {
                                    // Find which slot has the editing annotation
                                    for (const slot of slots) {
                                      const editingAnnIndex = (slotAnnotations[slot.id] || []).findIndex(a => a.id === editingTextId);
                                      if (editingAnnIndex >= 0) {
                                        const activeElement = document.activeElement;
                                        const currentText = (activeElement?.tagName === 'TEXTAREA' ? activeElement.value : null) 
                                          || slotAnnotations[slot.id][editingAnnIndex].text || '';
                                        console.log('Lock All: Force-saving text:', { editingTextId, currentText });
                                        setSlotAnnotations(prev => ({
                                          ...prev,
                                          [slot.id]: (prev[slot.id] || []).map(a => 
                                            a.id === editingTextId ? { ...a, text: currentText } : a
                                          )
                                        }));
                                        break;
                                      }
                                    }
                                    setEditingTextId(null);
                                    // Small delay to ensure state update
                                    await new Promise(resolve => setTimeout(resolve, 50));
                                  }
                                  
                                  // Lock all - check for unsaved changes first
                                  const slotsWithChanges = slots.filter(slot => {
                                    if (!unlockedSlots.has(slot.id)) return false;
                                    const annotations = slotAnnotations[slot.id] || [];
                                    const ownedIds = ownedAnnotationIds[slot.id] || new Set();
                                    return annotations.some(a => !a.fromPdf) || ownedIds.size > 0;
                                  });
                                  
                                  if (slotsWithChanges.length > 0) {
                                    // Ask user if they want to save or discard
                                    const saveChanges = window.confirm(
                                      `${slotsWithChanges.length} document${slotsWithChanges.length > 1 ? 's have' : ' has'} unsaved changes:\n\n` +
                                      slotsWithChanges.map(s => `• ${s.fileName}`).join('\n') +
                                      '\n\nDo you want to SAVE all changes?\n\nClick OK to save, or Cancel to discard changes.'
                                    );
                                    
                                    if (saveChanges) {
                                      // Save all changes
                                      let savedCount = 0;
                                      let failedCount = 0;
                                      
                                      for (const slot of slotsWithChanges) {
                                        try {
                                          const slotAnns = slotAnnotations[slot.id] || [];
                                          const ownedIds = ownedAnnotationIds[slot.id] || new Set();
                                          
                                          const result = await saveSlotAnnotationsToPdf(
                                            slot,
                                            slotAnns,
                                            ownedIds,
                                            slot.width || 800,
                                            slot.height || 600
                                          );
                                          
                                          if (result.success) {
                                            savedCount++;
                                            // Clear annotations for this slot
                                            setSlotAnnotations(prev => ({
                                              ...prev,
                                              [slot.id]: []
                                            }));
                                            setOwnedAnnotationIds(prev => ({
                                              ...prev,
                                              [slot.id]: new Set()
                                            }));
                                            
                                            // Reload the PDF
                                            try {
                                              await new Promise(resolve => setTimeout(resolve, 200));
                                              const response = await fetch(`http://localhost:3001/api/files/${encodeURIComponent(slot.backendFilename)}?t=${Date.now()}`);
                                              const blob = await response.blob();
                                              const arrayBuffer = await blob.arrayBuffer();
                                              const newUrl = URL.createObjectURL(blob);
                                              const newPdfDoc = await window.pdfjsLib.getDocument({ data: arrayBuffer.slice(0) }).promise;
                                              
                                              const pdfAnnotations = await loadPdfAnnotations(newPdfDoc, slot.page, slot.id, 1.5);
                                              
                                              setSlots(prev => prev.map(s => s.id === slot.id ? {
                                                ...s,
                                                pdfDoc: newPdfDoc,
                                                blobUrl: newUrl,
                                                pdfBytes: arrayBuffer,
                                                renderKey: (s.renderKey || 0) + 1
                                              } : s));
                                              
                                              setSlotAnnotations(prev => ({
                                                ...prev,
                                                [slot.id]: pdfAnnotations
                                              }));
                                            } catch (reloadErr) {
                                              console.warn('PDF saved but failed to reload:', slot.fileName, reloadErr);
                                            }
                                          } else {
                                            failedCount++;
                                            console.error('Failed to save:', slot.fileName, result.error);
                                          }
                                        } catch (err) {
                                          failedCount++;
                                          console.error('Error saving:', slot.fileName, err);
                                        }
                                      }
                                      
                                      if (failedCount > 0) {
                                        alert(`Saved ${savedCount} document(s), but ${failedCount} failed to save.\n\nPlease check the console for details.`);
                                        return; // Don't lock if some failed
                                      }
                                    } else {
                                      // User clicked Cancel - ask if they want to discard
                                      const discardConfirm = window.confirm(
                                        'Are you sure you want to discard all unsaved changes?\n\nThis cannot be undone.'
                                      );
                                      if (!discardConfirm) return;
                                      
                                      // Discard all changes
                                      slotsWithChanges.forEach(slot => {
                                        setSlotAnnotations(prev => {
                                          const ownedIds = ownedAnnotationIds[slot.id] || new Set();
                                          return {
                                            ...prev,
                                            [slot.id]: (prev[slot.id] || []).filter(a => a.fromPdf && !ownedIds.has(a.id))
                                          };
                                        });
                                        setOwnedAnnotationIds(prev => ({
                                          ...prev,
                                          [slot.id]: new Set()
                                        }));
                                      });
                                    }
                                  }
                                  
                                  // Lock all and check them in
                                  slots.forEach(slot => {
                                    if (unlockedSlots.has(slot.id)) {
                                      onDocumentCheckin?.(slot.fileId);
                                    }
                                  });
                                  setUnlockedSlots(new Set());
                                  setSelectedAnnotation(null);
                                  setMarkupMode(null);
                                } else {
                                  // Unlock all - but skip ones checked out elsewhere
                                  const newUnlocked = new Set(unlockedSlots);
                                  slots.forEach(slot => {
                                    const isCheckedOutElsewhere = checkedOutDocuments[slot.fileId] && checkedOutDocuments[slot.fileId] !== 'infiniteview';
                                    if (!isCheckedOutElsewhere) {
                                      newUnlocked.add(slot.id);
                                      onDocumentCheckout?.(slot.fileId, 'infiniteview');
                                    }
                                  });
                                  setUnlockedSlots(newUnlocked);
                                }
                              }}
                              style={{
                                padding: '1px 4px',
                                fontSize: '9px',
                                background: 'transparent',
                                color: allUnlocked ? '#888' : '#777',
                                border: `1px solid ${allUnlocked ? '#555' : '#555'}`,
                                borderRadius: '2px',
                                cursor: 'pointer',
                                letterSpacing: '0.3px'
                              }}
                            >
                              {allUnlocked ? 'Lock All' : 'Unlock All'}
                            </button>
                          );
                        })()}
                      </div>
                      {slots
                        .filter(slot => {
                          if (!addPdfSearchQuery.trim()) return true;
                          const query = addPdfSearchQuery.toLowerCase();
                          return slot.fileName?.toLowerCase().includes(query);
                        })
                        .map(slot => {
                          const annotations = slotAnnotations[slot.id] || [];
                          const isUnlocked = unlockedSlots.has(slot.id);
                          const annotationCount = annotations.length;
                          const ownedIds = ownedAnnotationIds[slot.id] || new Set();
                          // Has changes if: any user-created annotations OR any owned PDF annotations
                          const hasChanges = annotations.some(ann => !ann.fromPdf) || ownedIds.size > 0;
                        
                          return (
                            <div 
                              key={slot.id}
                              className={`canvas-slot-item ${isUnlocked ? 'unlocked' : ''}`}
                            style={{
                              padding: '10px 12px',
                              borderBottom: '1px solid #333',
                              display: 'flex',
                              flexDirection: 'column',
                              gap: '3px'
                            }}
                          >
                            {/* Document name - clickable to navigate */}
                            <div 
                              style={{ 
                                cursor: 'pointer',
                                overflow: 'hidden',
                                textOverflow: 'ellipsis',
                                whiteSpace: 'nowrap',
                                fontSize: '13px',
                                color: '#fff',
                                display: 'flex',
                                alignItems: 'center',
                                gap: '4px'
                              }}
                              onClick={() => {
                                zoomToSlot(slot, 0.35);
                                setAnchorSlotId(slot.id);
                                setSelectedSlotIds(new Set([slot.id]));
                              }}
                              title={slot.fileName}
                            >
                              {hasChanges && <span style={{ color: '#fff', fontWeight: 'bold' }} title="Unsaved changes">*</span>}
                              <span style={{ overflow: 'hidden', textOverflow: 'ellipsis' }}>{slot.fileName}</span>
                            </div>
                            
                            {/* Page number - second line */}
                            <div style={{ fontSize: '11px', color: '#888' }}>
                              Page {slot.page}/{slot.numPages}
                            </div>
                            
                            {/* Unlock/Lock button - third line */}
                            {(() => {
                              const isCheckedOutElsewhere = checkedOutDocuments[slot.fileId] && checkedOutDocuments[slot.fileId] !== 'infiniteview';
                              return (
                                <button
                                  className={`slot-unlock-btn ${isUnlocked ? 'unlocked' : ''} ${isCheckedOutElsewhere ? 'disabled' : ''}`}
                                  onClick={async (e) => {
                                    e.stopPropagation();
                                    
                                    // Check if document is checked out elsewhere
                                    if (isCheckedOutElsewhere) {
                                      alert(`This document is currently being edited in ${checkedOutDocuments[slot.fileId] === 'pdfviewer' ? 'PDF Viewer' : 'another view'}. Please close it there first.`);
                                      return;
                                    }
                                    
                                    if (isUnlocked) {
                                      // Get current annotations
                                      let slotAnnotations_ = [...(slotAnnotations[slot.id] || [])];
                                      
                                      // Force-save any text being edited in this slot
                                      if (editingTextId) {
                                        const editingAnnIndex = slotAnnotations_.findIndex(a => a.id === editingTextId);
                                        if (editingAnnIndex >= 0) {
                                          // Get current text from the active textarea (if it's focused)
                                          const activeElement = document.activeElement;
                                          const currentText = (activeElement?.tagName === 'TEXTAREA' ? activeElement.value : null) 
                                            || slotAnnotations_[editingAnnIndex].text || '';
                                          console.log('Force-saving text from editing:', { editingTextId, currentText, textLength: currentText.length });
                                          // Update the annotation in our local copy
                                          slotAnnotations_[editingAnnIndex] = { ...slotAnnotations_[editingAnnIndex], text: currentText };
                                          // Also update state
                                          setSlotAnnotations(prev => ({
                                            ...prev,
                                            [slot.id]: slotAnnotations_
                                          }));
                                          setEditingTextId(null);
                                        }
                                      }
                                      
                                      // Locking - check for unsaved changes
                                      const ownedIds = ownedAnnotationIds[slot.id] || new Set();
                                      const newAnnotations = slotAnnotations_.filter(a => !a.fromPdf);
                                      const modifiedAnnotations = slotAnnotations_.filter(a => a.fromPdf && ownedIds.has(a.id));
                                      const hasUnsavedChanges = newAnnotations.length > 0 || modifiedAnnotations.length > 0;
                                      
                                      if (hasUnsavedChanges) {
                                        // Show save/discard dialog
                                        const saveChanges = window.confirm(
                                          `You have unsaved changes (${newAnnotations.length} new, ${modifiedAnnotations.length} modified).\n\nDo you want to save changes?\n\nClick OK to save, or Cancel to discard changes.`
                                        );
                                        
                                        if (saveChanges) {
                                          // Save to the actual file and lock
                                          try {
                                            const result = await saveSlotAnnotationsToPdf(
                                              slot,
                                              slotAnnotations_,
                                              ownedIds,
                                              slot.width || 800,
                                              slot.height || 600
                                            );
                                            
                                            if (!result.success) {
                                              alert('Failed to save changes: ' + (result.error || 'Unknown error'));
                                              return; // Don't lock if save failed
                                            }
                                            
                                            // Clear annotations and reload PDF
                                            setSlotAnnotations(prev => ({
                                              ...prev,
                                              [slot.id]: []
                                            }));
                                            setOwnedAnnotationIds(prev => ({
                                              ...prev,
                                              [slot.id]: new Set()
                                            }));
                                            
                                            // Reload the PDF to show saved annotations
                                            try {
                                              await new Promise(resolve => setTimeout(resolve, 200));
                                              const response = await fetch(`http://localhost:3001/api/files/${encodeURIComponent(slot.backendFilename)}?t=${Date.now()}`);
                                              const blob = await response.blob();
                                              const arrayBuffer = await blob.arrayBuffer();
                                              const newUrl = URL.createObjectURL(blob);
                                              const newPdfDoc = await window.pdfjsLib.getDocument({ data: arrayBuffer.slice(0) }).promise;
                                              
                                              // Load fresh annotations from the saved PDF
                                              const pdfAnnotations = await loadPdfAnnotations(newPdfDoc, slot.page, slot.id, 1.5);
                                              
                                              setSlots(prev => prev.map(s => s.id === slot.id ? {
                                                ...s,
                                                pdfDoc: newPdfDoc,
                                                blobUrl: newUrl,
                                                pdfBytes: arrayBuffer,
                                                renderKey: (s.renderKey || 0) + 1
                                              } : s));
                                              
                                              setSlotAnnotations(prev => ({
                                                ...prev,
                                                [slot.id]: pdfAnnotations
                                              }));
                                            } catch (reloadErr) {
                                              console.warn('PDF saved but failed to reload:', reloadErr);
                                              alert('Changes saved successfully!\n\nNote: Please close and reopen the document to see the saved annotations.');
                                            }
                                            
                                            // Lock the slot
                                            setUnlockedSlots(prev => {
                                              const next = new Set(prev);
                                              next.delete(slot.id);
                                              return next;
                                            });
                                            if (selectedAnnotation?.slotId === slot.id) {
                                              setSelectedAnnotation(null);
                                            }
                                            setMarkupMode(null);
                                            onDocumentCheckin?.(slot.fileId);
                                          } catch (err) {
                                            console.error('Failed to save:', err);
                                            alert('Failed to save changes: ' + err.message);
                                            return;
                                          }
                                        } else {
                                          // Discard changes - ask for confirmation
                                          const discardConfirm = window.confirm(
                                            'Are you sure you want to discard all unsaved changes?\n\nThis cannot be undone.'
                                          );
                                          if (discardConfirm) {
                                            // Remove user-created annotations, keep only original PDF ones
                                            setSlotAnnotations(prev => ({
                                              ...prev,
                                              [slot.id]: (prev[slot.id] || []).filter(a => a.fromPdf && !ownedIds.has(a.id))
                                            }));
                                            
                                            // Clear owned IDs
                                            setOwnedAnnotationIds(prev => ({
                                              ...prev,
                                              [slot.id]: new Set()
                                            }));
                                            
                                            // Reload PDF to restore original state
                                            try {
                                              const response = await fetch(`http://localhost:3001/api/files/${encodeURIComponent(slot.backendFilename)}?t=${Date.now()}`);
                                              const blob = await response.blob();
                                              const arrayBuffer = await blob.arrayBuffer();
                                              const newUrl = URL.createObjectURL(blob);
                                              const newPdfDoc = await window.pdfjsLib.getDocument({ data: arrayBuffer.slice(0) }).promise;
                                              
                                              // Load fresh annotations from PDF
                                              const pdfAnnotations = await loadPdfAnnotations(newPdfDoc, slot.page, slot.id, 1.5);
                                              
                                              setSlots(prev => prev.map(s => s.id === slot.id ? {
                                                ...s,
                                                pdfDoc: newPdfDoc,
                                                blobUrl: newUrl,
                                                pdfBytes: arrayBuffer,
                                                renderKey: (s.renderKey || 0) + 1
                                              } : s));
                                              
                                              setSlotAnnotations(prev => ({
                                                ...prev,
                                                [slot.id]: pdfAnnotations
                                              }));
                                            } catch (reloadErr) {
                                              console.warn('Failed to reload PDF:', reloadErr);
                                            }
                                            
                                            // Lock the slot
                                            setUnlockedSlots(prev => {
                                              const next = new Set(prev);
                                              next.delete(slot.id);
                                              return next;
                                            });
                                            if (selectedAnnotation?.slotId === slot.id) {
                                              setSelectedAnnotation(null);
                                            }
                                            setMarkupMode(null);
                                            onDocumentCheckin?.(slot.fileId);
                                          }
                                          // If user cancels discard, stay in edit mode
                                        }
                                      } else {
                                        // No unsaved changes - just lock
                                        setUnlockedSlots(prev => {
                                          const next = new Set(prev);
                                          next.delete(slot.id);
                                          return next;
                                        });
                                        if (selectedAnnotation?.slotId === slot.id) {
                                          setSelectedAnnotation(null);
                                        }
                                        setMarkupMode(null);
                                        onDocumentCheckin?.(slot.fileId);
                                      }
                                    } else {
                                      // Unlocking - check out the document
                                      setUnlockedSlots(prev => {
                                        const next = new Set(prev);
                                        next.add(slot.id);
                                        return next;
                                      });
                                      onDocumentCheckout?.(slot.fileId, 'infiniteview');
                                    }
                                  }}
                                  disabled={isCheckedOutElsewhere}
                                  title={isCheckedOutElsewhere ? 'Document is being edited elsewhere' : (isUnlocked ? 'Lock document (save or discard changes)' : 'Unlock for editing')}
                                  style={{
                                    padding: '1px 4px',
                                    fontSize: '9px',
                                    background: 'transparent',
                                    color: isCheckedOutElsewhere ? '#666' : (isUnlocked ? '#27ae60' : '#777'),
                                    border: `1px solid ${isCheckedOutElsewhere ? '#444' : (isUnlocked ? '#27ae60' : '#555')}`,
                                    borderRadius: '2px',
                                    cursor: isCheckedOutElsewhere ? 'not-allowed' : 'pointer',
                                    whiteSpace: 'nowrap',
                                    opacity: isCheckedOutElsewhere ? 0.5 : 1,
                                    alignSelf: 'flex-start',
                                    letterSpacing: '0.3px',
                                    marginTop: '2px'
                                  }}
                                >
                                  {isUnlocked ? '✓ Editing' : 'Unlock'}
                                </button>
                              );
                            })()}
                            
                            {/* Expanded annotation list when unlocked */}
                            {isUnlocked && annotations.length > 0 && (
                              <div className="slot-annotations-list" style={{ 
                                marginTop: '4px',
                                maxHeight: '150px',
                                overflowY: 'auto',
                                background: '#111',
                                borderRadius: '4px',
                                padding: '4px'
                              }}>
                                {annotations.map((ann, idx) => {
                                  const isSelected = selectedAnnotation?.id === ann.id;
                                  return (
                                    <div
                                      key={ann.id}
                                      className={`annotation-list-item ${isSelected ? 'selected' : ''}`}
                                      style={{
                                        padding: '6px 8px',
                                        fontSize: '11px',
                                        color: isSelected ? '#fff' : '#ccc',
                                        background: isSelected ? '#333' : 'transparent',
                                        borderRadius: '3px',
                                        cursor: 'pointer',
                                        display: 'flex',
                                        alignItems: 'center',
                                        gap: '8px'
                                      }}
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        setSelectedAnnotation({ ...ann, slotId: slot.id });
                                        // Navigate to the slot
                                        zoomToSlot(slot, 0.5);
                                      }}
                                    >
                                      {/* Type label */}
                                      <span style={{ textTransform: 'capitalize' }}>
                                        {ann.type === 'polylineArrow' ? 'Polyline Arrow' : 
                                         ann.type === 'cloudPolyline' ? 'Cloud Polyline' : 
                                         ann.type}
                                      </span>
                                      {/* Delete button */}
                                      <button
                                        onClick={(e) => {
                                          e.stopPropagation();
                                          setSlotAnnotations(prev => ({
                                            ...prev,
                                            [slot.id]: (prev[slot.id] || []).filter(a => a.id !== ann.id)
                                          }));
                                          if (selectedAnnotation?.id === ann.id) {
                                            setSelectedAnnotation(null);
                                          }
                                        }}
                                        style={{
                                          marginLeft: 'auto',
                                          padding: '2px 6px',
                                          fontSize: '10px',
                                          background: 'rgba(231, 76, 60, 0.8)',
                                          color: '#fff',
                                          border: 'none',
                                          borderRadius: '3px',
                                          cursor: 'pointer'
                                        }}
                                        title="Delete markup"
                                      >
                                        ×
                                      </button>
                                    </div>
                                  );
                                })}
                              </div>
                            )}
                          </div>
                        );
                      })}
                    </>
                  )
                ) : (
                  /* All tab - show all files */
                  filteredFiles.map(file => {
                    const loadedSlot = slots.find(s => s.fileId === file.id);
                    const isLoaded = !!loadedSlot;
                    // Check for changes if loaded
                    let hasChanges = false;
                    if (isLoaded) {
                      const annotations = slotAnnotations[loadedSlot.id] || [];
                      const ownedIds = ownedAnnotationIds[loadedSlot.id] || new Set();
                      hasChanges = annotations.some(ann => !ann.fromPdf) || ownedIds.size > 0;
                    }
                    return (
                      <div 
                        key={file.id}
                        className={`iv-doc-item ${isLoaded ? 'iv-loaded' : ''}`}
                        onClick={() => {
                          if (isLoaded) {
                            // Navigate to the loaded PDF at 35% zoom
                            zoomToSlot(loadedSlot, 0.35);
                            setAnchorSlotId(loadedSlot.id);
                            setSelectedSlotIds(new Set([loadedSlot.id]));
                          } else {
                            // Add next to the active/anchor slot, or last slot, or at origin
                            const anchorSlot = slots.find(s => s.id === anchorSlotId);
                            const referenceSlot = anchorSlot || slots[slots.length - 1];
                            
                            if (referenceSlot) {
                              // Use actual slot dimensions like Smart Links does
                              const slotWidth = referenceSlot.width || 800;
                              const slotHeight = referenceSlot.height || 600;
                              const gap = 100;
                              
                              // Add to the right of the reference slot
                              const targetX = referenceSlot.x + slotWidth + gap;
                              const targetY = referenceSlot.y;
                              
                              // Use smart positioning - pass reference slot so it doesn't get moved
                              const { x, y, slotsToMove } = findSmartPosition(targetX, targetY, slotWidth, slotHeight, referenceSlot);
                              applySlotMovements(slotsToMove);
                              
                              loadPdfAtPosition(file, 1, x, y);
                            } else {
                              loadPdfAtPosition(file, 1, 0, 0);
                            }
                          }
                          // Keep panel open - only close with X button
                        }}
                      >
                        {/* Document name with asterisk if has changes */}
                        <div className="iv-doc-name">
                          {hasChanges && <span className="iv-unsaved">*</span>}
                          <span style={{ overflow: 'hidden', textOverflow: 'ellipsis' }}>{file.name}</span>
                        </div>
                        {/* Page info - shown when loaded */}
                        {isLoaded && (
                          <div className="iv-doc-page">
                            Page {loadedSlot.page}/{loadedSlot.numPages}
                          </div>
                        )}
                        {/* On Canvas tag */}
                        {isLoaded && <span className="iv-on-canvas">On Canvas</span>}
                      </div>
                    );
                  })
                )}
              </div>
            </div>
          </div>
        </div>
      )}
      
      {/* Object Search Panel */}
      {showObjectSearch && (
        <div className="smart-links-panel right-panel">
          <div className="panel-header">
            <h3>Search</h3>
            <button className="close-panel" onClick={() => setShowObjectSearch(false)}>×</button>
          </div>
          <div className="panel-content">
            <div className="panel-section" style={{ background: '#000', marginBottom: '8px' }}>
              <input
                type="text"
                placeholder="Search by tag, class, or description..."
                value={objectSearchQuery}
                onChange={(e) => setObjectSearchQuery(e.target.value)}
                className="iv-search-input"
                style={{ background: '#000', boxShadow: 'none' }}
                autoFocus
              />
            </div>
            
            {/* Class filters */}
            <div className="panel-section iv-filter-section">
              <h4>Filter By Class</h4>
              <div className="iv-filter-actions">
                <button onClick={() => setHiddenClasses(new Set())}>Show All</button>
                <button onClick={() => {
                  const allClasses = new Set(allDetectedObjects.map(o => o.label || o.className).filter(Boolean));
                  setHiddenClasses(allClasses);
                }}>Hide All</button>
              </div>
              <div className="iv-class-filters">
                {[...new Set(allDetectedObjects.map(o => o.label || o.className))].filter(Boolean).map(className => (
                  <label key={className} className="iv-class-filter-item">
                    <input
                      type="checkbox"
                      checked={!hiddenClasses.has(className)}
                      onChange={(e) => {
                        const newHidden = new Set(hiddenClasses);
                        if (e.target.checked) {
                          newHidden.delete(className);
                        } else {
                          newHidden.add(className);
                        }
                        setHiddenClasses(newHidden);
                      }}
                    />
                    <span>{className}</span>
                  </label>
                ))}
              </div>
            </div>
            
            <div className="panel-section search-results-section">
              <h4>Results</h4>
              <div className="iv-search-results">
                {filteredObjects.length > 0 ? (
                  filteredObjects.map((obj, idx) => {
                    const className = obj.label || obj.className;
                    if (hiddenClasses.has(className)) return null;
                    return (
                      <div 
                        key={obj.id || idx}
                        className="iv-result-item"
                        onClick={() => navigateToObject(obj)}
                      >
                        <div className="iv-result-line">{obj.ocr_text || 'No tag'}</div>
                        <div className="iv-result-line">{className || 'Unknown'}</div>
                        <div className="iv-result-line iv-result-doc">{obj.filename?.replace('.pdf', '')} - Page {(obj.page || 0) + 1}</div>
                      </div>
                    );
                  })
                ) : (
                  <p className="iv-no-results">No objects found</p>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
      
      {/* View Options Sidebar */}
      {showViewOptions && (
        <div className="view-options-sidebar">
          <div className="panel-header">
            <h3>Options</h3>
            <button className="close-panel" onClick={() => setShowViewOptions(false)}>×</button>
          </div>
          <div className="panel-content">
            {/* Crop Region Section */}
            <div className="panel-section">
              <h4>Crop Region</h4>
              <p className="section-description">
                Select a region of the PDF to display. Useful for hiding headers, footers, or revision borders.
              </p>
              
              <div className="crop-controls">
                {!cropRegion ? (
                  <>
                    <button 
                      className={`crop-action-btn ${isDrawingCrop ? 'active' : ''}`}
                      onClick={() => {
                        setIsDrawingCrop(true);
                        setCurrentTool('crop');
                      }}
                    >
                      {isDrawingCrop ? 'Click and drag on a PDF...' : 'Draw Crop Region'}
                    </button>
                    {isDrawingCrop && (
                      <p className="crop-hint">
                        Click and drag on any PDF to select the region you want to show. Press Escape to cancel.
                      </p>
                    )}
                  </>
                ) : (
                  <>
                    <div className="crop-preview">
                      <div className="crop-preview-label">Current Crop:</div>
                      <div className="crop-preview-values">
                        X: {(cropRegion.x * 100).toFixed(1)}% | 
                        Y: {(cropRegion.y * 100).toFixed(1)}%<br/>
                        W: {(cropRegion.width * 100).toFixed(1)}% | 
                        H: {(cropRegion.height * 100).toFixed(1)}%
                      </div>
                    </div>
                    
                    <label className="crop-toggle">
                      <input
                        type="checkbox"
                        checked={cropEnabled}
                        onChange={(e) => setCropEnabled(e.target.checked)}
                      />
                      <span>Apply crop to all PDFs</span>
                    </label>
                    
                    <div className="crop-actions">
                      <button 
                        className="crop-action-btn secondary"
                        onClick={() => {
                          setIsDrawingCrop(true);
                          setCurrentTool('crop');
                        }}
                      >
                        Redraw
                      </button>
                      <button 
                        className="crop-action-btn danger"
                        onClick={clearCropRegion}
                      >
                        🗑️ Clear
                      </button>
                    </div>
                  </>
                )}
              </div>
            </div>
            
            <div className="panel-divider" />
            
            {/* Markups Options */}
            <div className="panel-section">
              <h4>Markups</h4>
              <label className="view-option-toggle">
                <input
                  type="checkbox"
                  checked={showMarkupsToolbar}
                  onChange={(e) => setShowMarkupsToolbar(e.target.checked)}
                />
                <span>Show markups toolbar</span>
              </label>
            </div>
            
            <div className="panel-divider" />
            
            {/* Display Options */}
            <div className="panel-section">
              <h4>Display</h4>
              <label className="view-option-toggle">
                <input
                  type="checkbox"
                  checked={showObjectTags}
                  onChange={(e) => setShowObjectTags(e.target.checked)}
                />
                <span>Show object tags</span>
              </label>
              <label className="view-option-toggle">
                <input
                  type="checkbox"
                  checked={showShadows}
                  onChange={(e) => setShowShadows(e.target.checked)}
                />
                <span>Show borders & shadows</span>
              </label>
            </div>
            
            <div className="panel-divider" />
            
            {/* Background Options */}
            <div className="panel-section">
              <h4>Background</h4>
              <div className="background-options">
                <button 
                  className={`bg-option ${backgroundStyle === 'grid' ? 'active' : ''}`}
                  onClick={() => setBackgroundStyle('grid')}
                  title="Grid Pattern"
                >
                  <div className="bg-preview bg-grid"></div>
                  <span>Grid</span>
                </button>
                <button 
                  className={`bg-option ${backgroundStyle === 'stars' ? 'active' : ''}`}
                  onClick={() => setBackgroundStyle('stars')}
                  title="Star Field"
                >
                  <div className="bg-preview bg-stars"></div>
                  <span>Stars</span>
                </button>
                <button 
                  className={`bg-option ${backgroundStyle === 'solid-dark' ? 'active' : ''}`}
                  onClick={() => setBackgroundStyle('solid-dark')}
                  title="Dark"
                >
                  <div className="bg-preview bg-solid-dark"></div>
                  <span>Dark</span>
                </button>
                <button 
                  className={`bg-option ${backgroundStyle === 'solid-light' ? 'active' : ''}`}
                  onClick={() => setBackgroundStyle('solid-light')}
                  title="Light"
                >
                  <div className="bg-preview bg-solid-light"></div>
                  <span>Light</span>
                </button>
                <button 
                  className={`bg-option ${backgroundStyle === 'solid-white' ? 'active' : ''}`}
                  onClick={() => setBackgroundStyle('solid-white')}
                  title="White"
                >
                  <div className="bg-preview bg-solid-white"></div>
                  <span>White</span>
                </button>
                <button 
                  className={`bg-option ${backgroundStyle === 'solid-blue' ? 'active' : ''}`}
                  onClick={() => setBackgroundStyle('solid-blue')}
                  title="Blue"
                >
                  <div className="bg-preview bg-solid-blue"></div>
                  <span>Blue</span>
                </button>
                <button 
                  className={`bg-option ${backgroundStyle === 'solid-green' ? 'active' : ''}`}
                  onClick={() => setBackgroundStyle('solid-green')}
                  title="Green"
                >
                  <div className="bg-preview bg-solid-green"></div>
                  <span>Green</span>
                </button>
                <button 
                  className={`bg-option ${backgroundStyle === 'solid-purple' ? 'active' : ''}`}
                  onClick={() => setBackgroundStyle('solid-purple')}
                  title="Purple"
                >
                  <div className="bg-preview bg-solid-purple"></div>
                  <span>Purple</span>
                </button>
                <button 
                  className={`bg-option ${backgroundStyle === 'none' ? 'active' : ''}`}
                  onClick={() => setBackgroundStyle('none')}
                  title="None"
                >
                  <div className="bg-preview bg-none"></div>
                  <span>None</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
      
      {/* Canvas Area */}
      <div 
        className={`infinite-canvas-container bg-${backgroundStyle}`}
        ref={containerRef}
        onMouseDown={(e) => {
          // Don't clear selection if Ctrl/Cmd is held (user is multi-selecting)
          if (e.ctrlKey || e.metaKey) {
            return;
          }
          
          // Clear selection when clicking empty canvas (not on a slot)
          if (!e.target.closest('.infinite-slot')) {
            setSelectedSlotIds(new Set());
          }
          
          // Always handle pan in pan mode
          if (currentTool === 'pan') {
            handleMouseDown(e);
          } else if (currentTool === 'zoom' && !e.target.closest('.infinite-slot')) {
            // Click to zoom in only if not clicking on slot (multiplicative zoom)
            setZoom(prev => Math.min(10, prev * 1.4));
          }
        }}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
        style={{ cursor: getCursor() }}
      >
        <div 
          className="infinite-canvas"
          ref={canvasRef}
          style={{
            transform: `translate(calc(-50% + ${canvasPosition.x}px), calc(-50% + ${canvasPosition.y}px)) scale(${zoom})`,
            transformOrigin: 'center center',
            transition: isAnimating ? 'transform 0.5s ease-out' : 'none'
          }}
        >
          {slots.map(slot => (
            <InfiniteSlot
              key={slot.id}
              slot={slot}
              project={project}
              allFiles={allFiles}
              detectedObjects={allDetectedObjects}
              onHotspotClick={(hotspot) => handleHotspotClick(hotspot, slot)}
              onDimensionsUpdate={(w, h) => updateSlotDimensions(slot.id, w, h)}
              onPositionUpdate={(x, y) => {
                setSlots(prev => prev.map(s => 
                  s.id === slot.id ? { ...s, x, y } : s
                ));
              }}
              onDoubleClick={() => zoomToSlot(slot)}
              onDelete={() => {
                // Check for unsaved changes
                const annotations = slotAnnotations[slot.id] || [];
                const ownedIds = ownedAnnotationIds[slot.id] || new Set();
                const hasChanges = annotations.some(a => !a.fromPdf) || ownedIds.size > 0;
                
                if (hasChanges) {
                  const confirmDelete = window.confirm(
                    'This document has unsaved changes.\n\nAre you sure you want to close it? All unsaved changes will be lost.'
                  );
                  if (!confirmDelete) return;
                }
                
                // Remove slot and revoke blob URL
                if (slot.blobUrl) {
                  URL.revokeObjectURL(slot.blobUrl);
                }
                // Clear annotations for this slot
                setSlotAnnotations(prev => {
                  const next = { ...prev };
                  delete next[slot.id];
                  return next;
                });
                setOwnedAnnotationIds(prev => {
                  const next = { ...prev };
                  delete next[slot.id];
                  return next;
                });
                // Check in the document if it was checked out
                if (unlockedSlots.has(slot.id)) {
                  onDocumentCheckin?.(slot.fileId);
                }
                setUnlockedSlots(prev => {
                  const next = new Set(prev);
                  next.delete(slot.id);
                  return next;
                });
                setSlots(prev => prev.filter(s => s.id !== slot.id));
                setSelectedSlotIds(prev => {
                  const next = new Set(prev);
                  next.delete(slot.id);
                  return next;
                });
                // If deleted the anchor, set new anchor
                if (slot.id === anchorSlotId) {
                  const remaining = slots.filter(s => s.id !== slot.id);
                  setAnchorSlotId(remaining.length > 0 ? remaining[0].id : null);
                }
              }}
              slotFileName={slot.fileName}
              onSlotClick={(e) => {
                const isCtrlClick = e && (e.ctrlKey || e.metaKey);
                if (isCtrlClick) {
                  // Ctrl+click to add/remove from selection
                  setSelectedSlotIds(prev => {
                    const next = new Set(prev);
                    if (next.has(slot.id)) {
                      next.delete(slot.id);
                    } else {
                      next.add(slot.id);
                    }
                    return next;
                  });
                  setAnchorSlotId(slot.id);
                } else if (selectedSlotIds.has(slot.id)) {
                  // Clicking on already selected PDF - don't change selection, just set anchor
                  setAnchorSlotId(slot.id);
                } else {
                  // Normal click on unselected PDF - select only this one
                  setSelectedSlotIds(new Set([slot.id]));
                  setAnchorSlotId(slot.id);
                }
              }}
              isAnchor={slot.id === anchorSlotId}
              isSelected={selectedSlotIds.has(slot.id)}
              selectedSlotIds={selectedSlotIds}
              isDragging={draggingSlotId === slot.id}
              onDragStart={() => setDraggingSlotId(slot.id)}
              onDragEnd={() => setDraggingSlotId(null)}
              onMultiDrag={(deltaX, deltaY) => {
                // Move all selected slots together
                const idsToMove = selectedSlotIds.has(slot.id) 
                  ? selectedSlotIds 
                  : new Set([slot.id]);
                setSlots(prev => prev.map(s => 
                  idsToMove.has(s.id) 
                    ? { ...s, x: s.x + deltaX, y: s.y + deltaY }
                    : s
                ));
              }}
              zoom={zoom}
              showLabel={zoom < 0.25}
              highlightedObjectId={highlightedObjectId}
              hiddenClasses={hiddenClasses}
              refreshKey={refreshKey}
              onObjectClick={async (obj) => {
                setSelectedObject({ ...obj });
                setShowObjectDialog(true);
                setHighlightedObjectId(obj.id);
                setObjectThumbnail(null);
                setTimeout(() => setHighlightedObjectId(null), 3000);
                
                // Fetch thumbnail
                try {
                  const response = await fetch('http://localhost:3001/api/thumbnail', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                      filename: obj.filename,
                      bbox: obj.bbox,
                      page: obj.page || 0,
                      expand: 0.935
                    })
                  });
                  if (response.ok) {
                    const data = await response.json();
                    setObjectThumbnail(data.thumbnail);
                  }
                } catch (error) {
                  console.error('Error fetching thumbnail:', error);
                }
              }}
              canDrag={currentTool === 'move'}
              currentTool={currentTool}
              showObjectTags={showObjectTags}
              showShadows={showShadows}
              cropRegion={cropEnabled ? cropRegion : null}
              isDrawingCrop={isDrawingCrop}
              onCropComplete={handleCropComplete}
              // Markup props
              markupMode={unlockedSlots.has(slot.id) ? markupMode : null}
              isSlotUnlocked={unlockedSlots.has(slot.id)}
              annotations={slotAnnotations[slot.id] || []}
              ownedAnnotationIds={ownedAnnotationIds[slot.id] || new Set()}
              onTakeOwnership={takeOwnershipOfAnnotation}
              onAnnotationAdd={(slotId, annotation) => {
                setSlotAnnotations(prev => ({
                  ...prev,
                  [slotId]: [...(prev[slotId] || []), annotation]
                }));
              }}
              onAnnotationUpdate={(slotId, annotationId, updates) => {
                setSlotAnnotations(prev => ({
                  ...prev,
                  [slotId]: (prev[slotId] || []).map(a => 
                    a.id === annotationId ? { ...a, ...updates } : a
                  )
                }));
                // Keep selectedAnnotation in sync
                if (selectedAnnotation?.id === annotationId) {
                  setSelectedAnnotation(prev => prev ? { ...prev, ...updates } : null);
                }
              }}
              onAnnotationDelete={(slotId, annotationId) => {
                setSlotAnnotations(prev => ({
                  ...prev,
                  [slotId]: (prev[slotId] || []).filter(a => a.id !== annotationId)
                }));
                if (selectedAnnotation?.id === annotationId) {
                  setSelectedAnnotation(null);
                }
              }}
              selectedAnnotation={selectedAnnotation}
              onAnnotationSelect={(annotation) => {
                setSelectedAnnotation(annotation ? { ...annotation, slotId: slot.id } : null);
              }}
              currentDrawing={currentDrawing}
              onDrawingStart={(drawing) => setCurrentDrawing(drawing)}
              onDrawingUpdate={(drawing) => setCurrentDrawing(drawing)}
              onDrawingEnd={() => setCurrentDrawing(null)}
              markupColor={markupColor}
              markupStrokeWidth={markupStrokeWidth}
              markupOpacity={markupOpacity}
              markupFillColor={markupFillColor}
              markupFillOpacity={markupFillOpacity}
              markupStrokeOpacity={markupStrokeOpacity}
              markupArrowHeadSize={markupArrowHeadSize}
              markupLineStyle={markupLineStyle}
              editingTextId={editingTextId}
              editingTextValue={editingTextValue}
              setEditingTextId={setEditingTextId}
              setEditingTextValue={setEditingTextValue}
            />
          ))}
        </div>
        
        {/* Bottom Toolbar */}
        <div className="infinite-toolbar-bottom">
          <div className="toolbar-group">
            <button 
              onClick={() => setCurrentTool('select')}
              className={currentTool === 'select' ? 'active' : ''}
              title="Select (V)"
            >
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M3 3l7.07 16.97 2.51-7.39 7.39-2.51L3 3z"/>
                <path d="M13 13l6 6"/>
              </svg>
            </button>
            <button 
              onClick={() => setCurrentTool('pan')}
              className={currentTool === 'pan' ? 'active' : ''}
              title="Pan View (Shift+V)"
            >
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M18 11V6a2 2 0 0 0-2-2v0a2 2 0 0 0-2 2v0"/>
                <path d="M14 10V4a2 2 0 0 0-2-2v0a2 2 0 0 0-2 2v2"/>
                <path d="M10 10.5V6a2 2 0 0 0-2-2v0a2 2 0 0 0-2 2v8"/>
                <path d="M18 8a2 2 0 1 1 4 0v6a8 8 0 0 1-8 8h-2c-2.8 0-4.5-.86-5.99-2.34l-3.6-3.6a2 2 0 0 1 2.83-2.82L7 15"/>
              </svg>
            </button>
            <button 
              onClick={() => setCurrentTool('move')}
              className={currentTool === 'move' ? 'active' : ''}
              title="Move Pages (M)"
            >
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <polyline points="5 9 2 12 5 15"/>
                <polyline points="9 5 12 2 15 5"/>
                <polyline points="15 19 12 22 9 19"/>
                <polyline points="19 9 22 12 19 15"/>
                <line x1="2" y1="12" x2="22" y2="12"/>
                <line x1="12" y1="2" x2="12" y2="22"/>
              </svg>
            </button>
            <button 
              onClick={() => setCurrentTool('zoom')}
              className={currentTool === 'zoom' ? 'active' : ''}
              title="Zoom Tool (Z)"
            >
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <circle cx="11" cy="11" r="8"/>
                <line x1="21" y1="21" x2="16.65" y2="16.65"/>
                <line x1="11" y1="8" x2="11" y2="14"/>
                <line x1="8" y1="11" x2="14" y2="11"/>
              </svg>
            </button>
          </div>
          
          <div className="toolbar-divider" />
          
          <div className="toolbar-group">
            <button onClick={() => setZoom(prev => Math.max(0.05, prev / 1.4))} title="Zoom out">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <line x1="5" y1="12" x2="19" y2="12"/>
              </svg>
            </button>
            <span className="zoom-value">{Math.round(zoom * 100)}%</span>
            <button onClick={() => setZoom(prev => Math.min(10, prev * 1.4))} title="Zoom in">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <line x1="12" y1="5" x2="12" y2="19"/>
                <line x1="5" y1="12" x2="19" y2="12"/>
              </svg>
            </button>
          </div>
          
          <div className="toolbar-divider" />
          
          <div className="toolbar-group">
            <button onClick={zoomToFitAll} title="Fit all documents">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M15 3h6v6"/>
                <path d="M9 21H3v-6"/>
                <path d="M21 3l-7 7"/>
                <path d="M3 21l7-7"/>
              </svg>
            </button>
          </div>
          
          <div className="toolbar-divider" />
          
          <div className="toolbar-group">
            <button 
              onClick={async () => {
                if (onRefresh) {
                  await onRefresh();
                }
                setRefreshKey(prev => prev + 1);
              }} 
              title="Refresh"
            >
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <polyline points="23 4 23 10 17 10"/>
                <polyline points="1 20 1 14 7 14"/>
                <path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/>
              </svg>
            </button>
          </div>
        </div>
        
        {/* Floating Markup Toolbar */}
        {showMarkupsToolbar && (
          <div className="infinite-markup-toolbar">
            <div className="markup-toolbar-tools" style={{ opacity: unlockedSlots.size === 0 ? 0.5 : 1 }}>
              <button 
                className={`markup-tb-btn ${markupMode === 'pen' ? 'active' : ''}`}
                onClick={() => unlockedSlots.size > 0 && setMarkupMode(markupMode === 'pen' ? null : 'pen')}
                title={unlockedSlots.size === 0 ? "Unlock a drawing first" : "Pen (P)"}
                disabled={unlockedSlots.size === 0}
              >
                <svg width="18" height="18" viewBox="0 0 16 16" fill="none">
                  <path d="M11.5 1.5L14.5 4.5L5 14H2V11L11.5 1.5Z" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                  <path d="M9 4L12 7" stroke="white" strokeWidth="1.5"/>
                </svg>
              </button>
              <button 
                className={`markup-tb-btn ${markupMode === 'highlighter' ? 'active' : ''}`}
                onClick={() => unlockedSlots.size > 0 && setMarkupMode(markupMode === 'highlighter' ? null : 'highlighter')}
                title={unlockedSlots.size === 0 ? "Unlock a drawing first" : "Highlighter (H)"}
                disabled={unlockedSlots.size === 0}
              >
                <svg width="18" height="18" viewBox="0 0 16 16" fill="none">
                  <rect x="4" y="2" width="8" height="10" rx="1" stroke="white" strokeWidth="1.5"/>
                  <path d="M6 12V14H10V12" stroke="white" strokeWidth="1.5" strokeLinecap="round"/>
                  <line x1="6" y1="5" x2="10" y2="5" stroke="white" strokeWidth="1.5" strokeLinecap="round"/>
                </svg>
              </button>
              <button 
                className={`markup-tb-btn ${markupMode === 'arrow' ? 'active' : ''}`}
                onClick={() => unlockedSlots.size > 0 && setMarkupMode(markupMode === 'arrow' ? null : 'arrow')}
                title={unlockedSlots.size === 0 ? "Unlock a drawing first" : "Arrow (A)"}
                disabled={unlockedSlots.size === 0}
              >
                <svg width="18" height="18" viewBox="0 0 16 16" fill="none">
                  <line x1="2" y1="14" x2="12" y2="4" stroke="white" strokeWidth="1.5" strokeLinecap="round"/>
                  <path d="M12 4L12 9M12 4L7 4" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </button>
              <button 
                className={`markup-tb-btn ${markupMode === 'line' ? 'active' : ''}`}
                onClick={() => unlockedSlots.size > 0 && setMarkupMode(markupMode === 'line' ? null : 'line')}
                title={unlockedSlots.size === 0 ? "Unlock a drawing first" : "Line (L)"}
                disabled={unlockedSlots.size === 0}
              >
                <svg width="18" height="18" viewBox="0 0 16 16" fill="none">
                  <line x1="2" y1="14" x2="14" y2="2" stroke="white" strokeWidth="1.5" strokeLinecap="round"/>
                </svg>
              </button>
              <button 
                className={`markup-tb-btn ${markupMode === 'rectangle' ? 'active' : ''}`}
                onClick={() => unlockedSlots.size > 0 && setMarkupMode(markupMode === 'rectangle' ? null : 'rectangle')}
                title={unlockedSlots.size === 0 ? "Unlock a drawing first" : "Rectangle (R)"}
                disabled={unlockedSlots.size === 0}
              >
                <svg width="18" height="18" viewBox="0 0 16 16" fill="none">
                  <rect x="2" y="3" width="12" height="10" rx="1" stroke="white" strokeWidth="1.5"/>
                </svg>
              </button>
              <button 
                className={`markup-tb-btn ${markupMode === 'circle' ? 'active' : ''}`}
                onClick={() => unlockedSlots.size > 0 && setMarkupMode(markupMode === 'circle' ? null : 'circle')}
                title={unlockedSlots.size === 0 ? "Unlock a drawing first" : "Ellipse (E)"}
                disabled={unlockedSlots.size === 0}
              >
                <svg width="18" height="18" viewBox="0 0 16 16" fill="none">
                  <ellipse cx="8" cy="8" rx="6" ry="5" stroke="white" strokeWidth="1.5"/>
                </svg>
              </button>
              <button 
                className={`markup-tb-btn ${markupMode === 'arc' ? 'active' : ''}`}
                onClick={() => unlockedSlots.size > 0 && setMarkupMode(markupMode === 'arc' ? null : 'arc')}
                title={unlockedSlots.size === 0 ? "Unlock a drawing first" : "Arc (Shift+R)"}
                disabled={unlockedSlots.size === 0}
              >
                <svg width="18" height="18" viewBox="0 0 16 16" fill="none">
                  <path d="M3 12C3 12 5 4 13 4" stroke="white" strokeWidth="1.5" strokeLinecap="round" fill="none"/>
                </svg>
              </button>
              <button 
                className={`markup-tb-btn ${markupMode === 'cloud' ? 'active' : ''}`}
                onClick={() => unlockedSlots.size > 0 && setMarkupMode(markupMode === 'cloud' ? null : 'cloud')}
                title={unlockedSlots.size === 0 ? "Unlock a drawing first" : "Cloud (C)"}
                disabled={unlockedSlots.size === 0}
              >
                <svg width="18" height="18" viewBox="0 0 16 16" fill="none">
                  <path d="M4 11C2.5 11 2 9.5 3 8.5C2 7.5 3 6 4.5 6C4.5 4 6 3 8 3C10 3 11.5 4 11.5 6C13 6 14 7.5 13 8.5C14 9.5 13.5 11 12 11" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                  <path d="M4 11C5 12 7 12 8 12C9 12 11 12 12 11" stroke="white" strokeWidth="1.5" strokeLinecap="round"/>
                </svg>
              </button>
              <button 
                className={`markup-tb-btn ${markupMode === 'polyline' ? 'active' : ''}`}
                onClick={() => unlockedSlots.size > 0 && setMarkupMode(markupMode === 'polyline' ? null : 'polyline')}
                title={unlockedSlots.size === 0 ? "Unlock a drawing first" : "Polyline (Shift+L)"}
                disabled={unlockedSlots.size === 0}
              >
                <svg width="18" height="18" viewBox="0 0 16 16" fill="none">
                  <polyline points="2,12 5,5 9,10 14,3" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" fill="none"/>
                </svg>
              </button>
              <button 
                className={`markup-tb-btn ${markupMode === 'polylineArrow' ? 'active' : ''}`}
                onClick={() => unlockedSlots.size > 0 && setMarkupMode(markupMode === 'polylineArrow' ? null : 'polylineArrow')}
                title={unlockedSlots.size === 0 ? "Unlock a drawing first" : "Polyline Arrow (Shift+A)"}
                disabled={unlockedSlots.size === 0}
              >
                <svg width="18" height="18" viewBox="0 0 16 16" fill="none">
                  <polyline points="2,12 5,5 9,10 13,4" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" fill="none"/>
                  <path d="M13 4L13 7.5M13 4L9.5 4" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </button>
              <button 
                className={`markup-tb-btn ${markupMode === 'cloudPolyline' ? 'active' : ''}`}
                onClick={() => unlockedSlots.size > 0 && setMarkupMode(markupMode === 'cloudPolyline' ? null : 'cloudPolyline')}
                title={unlockedSlots.size === 0 ? "Unlock a drawing first" : "Cloud Polyline (Shift+C)"}
                disabled={unlockedSlots.size === 0}
              >
                <svg width="18" height="18" viewBox="0 0 16 16" fill="none">
                  <path d="M2 12 Q3.5 10 5 12 Q6.5 14 8 12 Q9.5 10 11 12 Q12.5 14 14 12" stroke="white" strokeWidth="1.5" strokeLinecap="round" fill="none"/>
                  <path d="M2 7 Q3.5 5 5 7 Q6.5 9 8 7 Q9.5 5 11 7 Q12.5 9 14 7" stroke="white" strokeWidth="1.5" strokeLinecap="round" fill="none"/>
                </svg>
              </button>
              
              <span className="markup-tb-divider"></span>
              
              <button 
                className={`markup-tb-btn ${markupMode === 'text' ? 'active' : ''}`}
                onClick={() => unlockedSlots.size > 0 && setMarkupMode(markupMode === 'text' ? null : 'text')}
                title={unlockedSlots.size === 0 ? "Unlock a drawing first" : "Text Box (T)"}
                disabled={unlockedSlots.size === 0}
              >
                <svg width="18" height="18" viewBox="0 0 16 16" fill="none">
                  <text x="4" y="12" fill="white" fontSize="12" fontWeight="bold" fontFamily="Arial">T</text>
                </svg>
              </button>
              <button 
                className={`markup-tb-btn ${markupMode === 'callout' ? 'active' : ''}`}
                onClick={() => unlockedSlots.size > 0 && setMarkupMode(markupMode === 'callout' ? null : 'callout')}
                title={unlockedSlots.size === 0 ? "Unlock a drawing first" : "Callout"}
                disabled={unlockedSlots.size === 0}
              >
                <svg width="18" height="18" viewBox="0 0 16 16" fill="none">
                  <path d="M2 3H14V10H6L3 13V10H2V3Z" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </button>
              <button 
                className={`markup-tb-btn ${markupMode === 'note' ? 'active' : ''}`}
                onClick={() => unlockedSlots.size > 0 && setMarkupMode(markupMode === 'note' ? null : 'note')}
                title={unlockedSlots.size === 0 ? "Unlock a drawing first" : "Sticky Note"}
                disabled={unlockedSlots.size === 0}
              >
                <svg width="18" height="18" viewBox="0 0 16 16" fill="none">
                  <rect x="2" y="2" width="12" height="12" rx="1" stroke="white" strokeWidth="1.5"/>
                  <path d="M10 2V6H14" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                  <line x1="4" y1="7" x2="8" y2="7" stroke="white" strokeWidth="1.5" strokeLinecap="round"/>
                  <line x1="4" y1="10" x2="10" y2="10" stroke="white" strokeWidth="1.5" strokeLinecap="round"/>
                </svg>
              </button>
              
              <span className="markup-tb-divider"></span>
              
              <button 
                className={`markup-tb-btn ${markupMode === 'eraser' ? 'active' : ''}`}
                onClick={() => unlockedSlots.size > 0 && setMarkupMode(markupMode === 'eraser' ? null : 'eraser')}
                title={unlockedSlots.size === 0 ? "Unlock a drawing first" : "Eraser"}
                disabled={unlockedSlots.size === 0}
              >
                <svg width="18" height="18" viewBox="0 0 16 16" fill="none">
                  <path d="M6 14H14" stroke="white" strokeWidth="1.5" strokeLinecap="round"/>
                  <path d="M2 10L6 14L14 6L10 2L2 10Z" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                  <path d="M6 6L10 10" stroke="white" strokeWidth="1.5"/>
                </svg>
              </button>
              
              <span className="markup-tb-divider"></span>
              
              <button 
                className="markup-tb-btn"
                onClick={() => {
                  const allAnnotations = Object.entries(slotAnnotations).flatMap(([slotId, anns]) => 
                    anns.map(a => ({ ...a, slotId }))
                  );
                  if (allAnnotations.length > 0) {
                    const lastAnn = allAnnotations[allAnnotations.length - 1];
                    setSlotAnnotations(prev => ({
                      ...prev,
                      [lastAnn.slotId]: (prev[lastAnn.slotId] || []).slice(0, -1)
                    }));
                  }
                }}
                title="Undo"
              >
                <svg width="18" height="18" viewBox="0 0 16 16" fill="none">
                  <path d="M4 6H11C12.5 6 14 7.5 14 9C14 10.5 12.5 12 11 12H8" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                  <path d="M6 3L3 6L6 9" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </button>
              <button 
                className="markup-tb-btn"
                onClick={() => {/* Redo - future */}}
                title="Redo"
              >
                <svg width="18" height="18" viewBox="0 0 16 16" fill="none">
                  <path d="M12 6H5C3.5 6 2 7.5 2 9C2 10.5 3.5 12 5 12H8" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                  <path d="M10 3L13 6L10 9" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </button>
            </div>
            
            {/* Tool Options Row - shows when a tool is selected OR when an annotation is selected */}
            {(markupMode || selectedAnnotation) && (
              <div className="tool-options-row">
                {/* Selected Annotation Options - match tool options by type */}
                {!markupMode && selectedAnnotation && (
                  <>
                    {/* Pen/Highlighter selected */}
                    {(selectedAnnotation.type === 'pen' || selectedAnnotation.type === 'highlighter') && (
                      <>
                        <div className="tool-option">
                          <label>Color:</label>
                          <input 
                            type="color" 
                            value={selectedAnnotation.color || '#ff0000'} 
                            onChange={(e) => {
                              setSlotAnnotations(prev => ({
                                ...prev,
                                [selectedAnnotation.slotId]: (prev[selectedAnnotation.slotId] || []).map(a => 
                                  a.id === selectedAnnotation.id ? { ...a, color: e.target.value } : a
                                )
                              }));
                              setSelectedAnnotation(prev => prev ? { ...prev, color: e.target.value } : null);
                            }}
                          />
                        </div>
                        <div className="tool-option">
                          <label>Size:</label>
                          <input 
                            type="range" 
                            min="1" 
                            max={selectedAnnotation.type === 'highlighter' ? '30' : '10'}
                            value={selectedAnnotation.strokeWidth || 2} 
                            onChange={(e) => {
                              const newWidth = parseInt(e.target.value);
                              setSlotAnnotations(prev => ({
                                ...prev,
                                [selectedAnnotation.slotId]: (prev[selectedAnnotation.slotId] || []).map(a => 
                                  a.id === selectedAnnotation.id ? { ...a, strokeWidth: newWidth } : a
                                )
                              }));
                              setSelectedAnnotation(prev => prev ? { ...prev, strokeWidth: newWidth } : null);
                            }}
                          />
                          <span>{selectedAnnotation.strokeWidth || 2}px</span>
                        </div>
                        {selectedAnnotation.type === 'highlighter' && (
                          <div className="tool-option">
                            <label>Opacity:</label>
                            <input 
                              type="range" 
                              min="0.1" 
                              max="0.8" 
                              step="0.1"
                              value={selectedAnnotation.opacity || 0.4} 
                              onChange={(e) => {
                                const newOpacity = parseFloat(e.target.value);
                                setSlotAnnotations(prev => ({
                                  ...prev,
                                  [selectedAnnotation.slotId]: (prev[selectedAnnotation.slotId] || []).map(a => 
                                    a.id === selectedAnnotation.id ? { ...a, opacity: newOpacity } : a
                                  )
                                }));
                                setSelectedAnnotation(prev => prev ? { ...prev, opacity: newOpacity } : null);
                              }}
                            />
                            <span>{Math.round((selectedAnnotation.opacity || 0.4) * 100)}%</span>
                          </div>
                        )}
                      </>
                    )}

                    {/* Arrow selected */}
                    {selectedAnnotation.type === 'arrow' && (
                      <>
                        <div className="tool-option">
                          <label>Color:</label>
                          <input 
                            type="color" 
                            value={selectedAnnotation.color || '#ff0000'} 
                            onChange={(e) => {
                              setSlotAnnotations(prev => ({
                                ...prev,
                                [selectedAnnotation.slotId]: (prev[selectedAnnotation.slotId] || []).map(a => 
                                  a.id === selectedAnnotation.id ? { ...a, color: e.target.value } : a
                                )
                              }));
                              setSelectedAnnotation(prev => prev ? { ...prev, color: e.target.value } : null);
                            }}
                          />
                        </div>
                        <div className="tool-option">
                          <label>Size:</label>
                          <input 
                            type="range" 
                            min="1" 
                            max="8" 
                            value={selectedAnnotation.strokeWidth || 2} 
                            onChange={(e) => {
                              const newWidth = parseInt(e.target.value);
                              setSlotAnnotations(prev => ({
                                ...prev,
                                [selectedAnnotation.slotId]: (prev[selectedAnnotation.slotId] || []).map(a => 
                                  a.id === selectedAnnotation.id ? { ...a, strokeWidth: newWidth } : a
                                )
                              }));
                              setSelectedAnnotation(prev => prev ? { ...prev, strokeWidth: newWidth } : null);
                            }}
                          />
                          <span>{selectedAnnotation.strokeWidth || 2}px</span>
                        </div>
                        <div className="tool-option">
                          <label>Head:</label>
                          <input 
                            type="range" 
                            min="6" 
                            max="30" 
                            value={selectedAnnotation.arrowHeadSize || 12} 
                            onChange={(e) => {
                              const newSize = parseInt(e.target.value);
                              setSlotAnnotations(prev => ({
                                ...prev,
                                [selectedAnnotation.slotId]: (prev[selectedAnnotation.slotId] || []).map(a => 
                                  a.id === selectedAnnotation.id ? { ...a, arrowHeadSize: newSize } : a
                                )
                              }));
                              setSelectedAnnotation(prev => prev ? { ...prev, arrowHeadSize: newSize } : null);
                            }}
                          />
                          <span>{selectedAnnotation.arrowHeadSize || 12}px</span>
                        </div>
                        <div className="tool-option">
                          <label>Style:</label>
                          <select 
                            value={selectedAnnotation.lineStyle || 'solid'} 
                            onChange={(e) => {
                              setSlotAnnotations(prev => ({
                                ...prev,
                                [selectedAnnotation.slotId]: (prev[selectedAnnotation.slotId] || []).map(a => 
                                  a.id === selectedAnnotation.id ? { ...a, lineStyle: e.target.value } : a
                                )
                              }));
                              setSelectedAnnotation(prev => prev ? { ...prev, lineStyle: e.target.value } : null);
                            }}
                          >
                            <option value="solid">━━━ Solid</option>
                            <option value="dashed">┅┅┅ Dashed</option>
                            <option value="dotted">┈┈┈ Dotted</option>
                          </select>
                        </div>
                      </>
                    )}

                    {/* Line selected */}
                    {selectedAnnotation.type === 'line' && (
                      <>
                        <div className="tool-option">
                          <label>Color:</label>
                          <input 
                            type="color" 
                            value={selectedAnnotation.color || '#ff0000'} 
                            onChange={(e) => {
                              setSlotAnnotations(prev => ({
                                ...prev,
                                [selectedAnnotation.slotId]: (prev[selectedAnnotation.slotId] || []).map(a => 
                                  a.id === selectedAnnotation.id ? { ...a, color: e.target.value } : a
                                )
                              }));
                              setSelectedAnnotation(prev => prev ? { ...prev, color: e.target.value } : null);
                            }}
                          />
                        </div>
                        <div className="tool-option">
                          <label>Size:</label>
                          <input 
                            type="range" 
                            min="1" 
                            max="8" 
                            value={selectedAnnotation.strokeWidth || 2} 
                            onChange={(e) => {
                              const newWidth = parseInt(e.target.value);
                              setSlotAnnotations(prev => ({
                                ...prev,
                                [selectedAnnotation.slotId]: (prev[selectedAnnotation.slotId] || []).map(a => 
                                  a.id === selectedAnnotation.id ? { ...a, strokeWidth: newWidth } : a
                                )
                              }));
                              setSelectedAnnotation(prev => prev ? { ...prev, strokeWidth: newWidth } : null);
                            }}
                          />
                          <span>{selectedAnnotation.strokeWidth || 2}px</span>
                        </div>
                        <div className="tool-option">
                          <label>Style:</label>
                          <select 
                            value={selectedAnnotation.lineStyle || 'solid'} 
                            onChange={(e) => {
                              setSlotAnnotations(prev => ({
                                ...prev,
                                [selectedAnnotation.slotId]: (prev[selectedAnnotation.slotId] || []).map(a => 
                                  a.id === selectedAnnotation.id ? { ...a, lineStyle: e.target.value } : a
                                )
                              }));
                              setSelectedAnnotation(prev => prev ? { ...prev, lineStyle: e.target.value } : null);
                            }}
                          >
                            <option value="solid">━━━ Solid</option>
                            <option value="dashed">┅┅┅ Dashed</option>
                            <option value="dotted">┈┈┈ Dotted</option>
                          </select>
                        </div>
                      </>
                    )}

                    {/* Rectangle/Circle selected */}
                    {(selectedAnnotation.type === 'rectangle' || selectedAnnotation.type === 'circle') && (
                      <>
                        <div className="tool-option">
                          <label>Stroke:</label>
                          <input 
                            type="color" 
                            value={selectedAnnotation.color || '#ff0000'} 
                            onChange={(e) => {
                              setSlotAnnotations(prev => ({
                                ...prev,
                                [selectedAnnotation.slotId]: (prev[selectedAnnotation.slotId] || []).map(a => 
                                  a.id === selectedAnnotation.id ? { ...a, color: e.target.value } : a
                                )
                              }));
                              setSelectedAnnotation(prev => prev ? { ...prev, color: e.target.value } : null);
                            }}
                          />
                        </div>
                        <div className="tool-option">
                          <label>Fill:</label>
                          <button 
                            title="No fill" 
                            className={`fill-toggle ${selectedAnnotation.fillColor === 'none' ? 'active' : ''}`}
                            onClick={() => {
                              setSlotAnnotations(prev => ({
                                ...prev,
                                [selectedAnnotation.slotId]: (prev[selectedAnnotation.slotId] || []).map(a => 
                                  a.id === selectedAnnotation.id ? { ...a, fillColor: 'none' } : a
                                )
                              }));
                              setSelectedAnnotation(prev => prev ? { ...prev, fillColor: 'none' } : null);
                            }}
                          >
                            ∅
                          </button>
                          <input 
                            type="color" 
                            value={selectedAnnotation.fillColor === 'none' ? '#ffffff' : (selectedAnnotation.fillColor || '#ffffff')} 
                            onChange={(e) => {
                              setSlotAnnotations(prev => ({
                                ...prev,
                                [selectedAnnotation.slotId]: (prev[selectedAnnotation.slotId] || []).map(a => 
                                  a.id === selectedAnnotation.id ? { ...a, fillColor: e.target.value } : a
                                )
                              }));
                              setSelectedAnnotation(prev => prev ? { ...prev, fillColor: e.target.value } : null);
                            }}
                            style={{ opacity: selectedAnnotation.fillColor === 'none' ? 0.5 : 1 }}
                          />
                        </div>
                        <div className="tool-option">
                          <label>Fill α:</label>
                          <input 
                            type="range" 
                            min="0.1" 
                            max="1" 
                            step="0.1"
                            value={selectedAnnotation.fillOpacity || 0.3} 
                            onChange={(e) => {
                              const newOpacity = parseFloat(e.target.value);
                              setSlotAnnotations(prev => ({
                                ...prev,
                                [selectedAnnotation.slotId]: (prev[selectedAnnotation.slotId] || []).map(a => 
                                  a.id === selectedAnnotation.id ? { ...a, fillOpacity: newOpacity } : a
                                )
                              }));
                              setSelectedAnnotation(prev => prev ? { ...prev, fillOpacity: newOpacity } : null);
                            }}
                            disabled={selectedAnnotation.fillColor === 'none'}
                            style={{ opacity: selectedAnnotation.fillColor === 'none' ? 0.5 : 1 }}
                          />
                          <span>{Math.round((selectedAnnotation.fillOpacity || 0.3) * 100)}%</span>
                        </div>
                        <div className="tool-option">
                          <label>Width:</label>
                          <input 
                            type="range" 
                            min="1" 
                            max="8" 
                            value={selectedAnnotation.strokeWidth || 2} 
                            onChange={(e) => {
                              const newWidth = parseInt(e.target.value);
                              setSlotAnnotations(prev => ({
                                ...prev,
                                [selectedAnnotation.slotId]: (prev[selectedAnnotation.slotId] || []).map(a => 
                                  a.id === selectedAnnotation.id ? { ...a, strokeWidth: newWidth } : a
                                )
                              }));
                              setSelectedAnnotation(prev => prev ? { ...prev, strokeWidth: newWidth } : null);
                            }}
                          />
                          <span>{selectedAnnotation.strokeWidth || 2}px</span>
                        </div>
                        <div className="tool-option">
                          <label>Style:</label>
                          <select 
                            value={selectedAnnotation.lineStyle || 'solid'} 
                            onChange={(e) => {
                              setSlotAnnotations(prev => ({
                                ...prev,
                                [selectedAnnotation.slotId]: (prev[selectedAnnotation.slotId] || []).map(a => 
                                  a.id === selectedAnnotation.id ? { ...a, lineStyle: e.target.value } : a
                                )
                              }));
                              setSelectedAnnotation(prev => prev ? { ...prev, lineStyle: e.target.value } : null);
                            }}
                          >
                            <option value="solid">━━━ Solid</option>
                            <option value="dashed">┅┅┅ Dashed</option>
                            <option value="dotted">┈┈┈ Dotted</option>
                          </select>
                        </div>
                        <div className="tool-option">
                          <label>Stroke α:</label>
                          <input 
                            type="range" 
                            min="0.1" 
                            max="1" 
                            step="0.1"
                            value={selectedAnnotation.strokeOpacity || 1} 
                            onChange={(e) => {
                              const newOpacity = parseFloat(e.target.value);
                              setSlotAnnotations(prev => ({
                                ...prev,
                                [selectedAnnotation.slotId]: (prev[selectedAnnotation.slotId] || []).map(a => 
                                  a.id === selectedAnnotation.id ? { ...a, strokeOpacity: newOpacity } : a
                                )
                              }));
                              setSelectedAnnotation(prev => prev ? { ...prev, strokeOpacity: newOpacity } : null);
                            }}
                          />
                          <span>{Math.round((selectedAnnotation.strokeOpacity || 1) * 100)}%</span>
                        </div>
                      </>
                    )}

                    {/* Cloud selected */}
                    {selectedAnnotation.type === 'cloud' && (
                      <>
                        <div className="tool-option">
                          <label>Stroke:</label>
                          <input 
                            type="color" 
                            value={selectedAnnotation.color || '#ff0000'} 
                            onChange={(e) => {
                              setSlotAnnotations(prev => ({
                                ...prev,
                                [selectedAnnotation.slotId]: (prev[selectedAnnotation.slotId] || []).map(a => 
                                  a.id === selectedAnnotation.id ? { ...a, color: e.target.value } : a
                                )
                              }));
                              setSelectedAnnotation(prev => prev ? { ...prev, color: e.target.value } : null);
                            }}
                          />
                        </div>
                        <div className="tool-option">
                          <label>Fill:</label>
                          <button 
                            title="No fill" 
                            className={`fill-toggle ${selectedAnnotation.fillColor === 'none' ? 'active' : ''}`}
                            onClick={() => {
                              setSlotAnnotations(prev => ({
                                ...prev,
                                [selectedAnnotation.slotId]: (prev[selectedAnnotation.slotId] || []).map(a => 
                                  a.id === selectedAnnotation.id ? { ...a, fillColor: 'none' } : a
                                )
                              }));
                              setSelectedAnnotation(prev => prev ? { ...prev, fillColor: 'none' } : null);
                            }}
                          >
                            ∅
                          </button>
                          <input 
                            type="color" 
                            value={selectedAnnotation.fillColor === 'none' ? '#ffffff' : (selectedAnnotation.fillColor || '#ffffff')} 
                            onChange={(e) => {
                              setSlotAnnotations(prev => ({
                                ...prev,
                                [selectedAnnotation.slotId]: (prev[selectedAnnotation.slotId] || []).map(a => 
                                  a.id === selectedAnnotation.id ? { ...a, fillColor: e.target.value } : a
                                )
                              }));
                              setSelectedAnnotation(prev => prev ? { ...prev, fillColor: e.target.value } : null);
                            }}
                            style={{ opacity: selectedAnnotation.fillColor === 'none' ? 0.5 : 1 }}
                          />
                        </div>
                        <div className="tool-option">
                          <label>Fill α:</label>
                          <input 
                            type="range" 
                            min="0.1" 
                            max="1" 
                            step="0.1"
                            value={selectedAnnotation.fillOpacity || 0.3} 
                            onChange={(e) => {
                              const newOpacity = parseFloat(e.target.value);
                              setSlotAnnotations(prev => ({
                                ...prev,
                                [selectedAnnotation.slotId]: (prev[selectedAnnotation.slotId] || []).map(a => 
                                  a.id === selectedAnnotation.id ? { ...a, fillOpacity: newOpacity } : a
                                )
                              }));
                              setSelectedAnnotation(prev => prev ? { ...prev, fillOpacity: newOpacity } : null);
                            }}
                            disabled={selectedAnnotation.fillColor === 'none'}
                            style={{ opacity: selectedAnnotation.fillColor === 'none' ? 0.5 : 1 }}
                          />
                          <span>{Math.round((selectedAnnotation.fillOpacity || 0.3) * 100)}%</span>
                        </div>
                        <div className="tool-option">
                          <label>Width:</label>
                          <input 
                            type="range" 
                            min="1" 
                            max="8" 
                            value={selectedAnnotation.strokeWidth || 2} 
                            onChange={(e) => {
                              const newWidth = parseInt(e.target.value);
                              setSlotAnnotations(prev => ({
                                ...prev,
                                [selectedAnnotation.slotId]: (prev[selectedAnnotation.slotId] || []).map(a => 
                                  a.id === selectedAnnotation.id ? { ...a, strokeWidth: newWidth } : a
                                )
                              }));
                              setSelectedAnnotation(prev => prev ? { ...prev, strokeWidth: newWidth } : null);
                            }}
                          />
                          <span>{selectedAnnotation.strokeWidth || 2}px</span>
                        </div>
                        <div className="tool-option">
                          <label>Arc Size:</label>
                          <input 
                            type="range" 
                            min="5" 
                            max="40" 
                            value={selectedAnnotation.cloudArcSize || 15} 
                            onChange={(e) => {
                              const newSize = parseInt(e.target.value);
                              setSlotAnnotations(prev => ({
                                ...prev,
                                [selectedAnnotation.slotId]: (prev[selectedAnnotation.slotId] || []).map(a => 
                                  a.id === selectedAnnotation.id ? { ...a, cloudArcSize: newSize } : a
                                )
                              }));
                              setSelectedAnnotation(prev => prev ? { ...prev, cloudArcSize: newSize } : null);
                            }}
                          />
                          <span>{selectedAnnotation.cloudArcSize || 15}px</span>
                        </div>
                        <div className="tool-option">
                          <label>Intensity:</label>
                          <input 
                            type="range" 
                            min="0.5" 
                            max="2" 
                            step="0.1"
                            value={selectedAnnotation.cloudIntensity || 1} 
                            onChange={(e) => {
                              const newIntensity = parseFloat(e.target.value);
                              setSlotAnnotations(prev => ({
                                ...prev,
                                [selectedAnnotation.slotId]: (prev[selectedAnnotation.slotId] || []).map(a => 
                                  a.id === selectedAnnotation.id ? { ...a, cloudIntensity: newIntensity } : a
                                )
                              }));
                              setSelectedAnnotation(prev => prev ? { ...prev, cloudIntensity: newIntensity } : null);
                            }}
                          />
                          <span>{(selectedAnnotation.cloudIntensity || 1).toFixed(1)}x</span>
                        </div>
                      </>
                    )}

                    {/* Text selected */}
                    {selectedAnnotation.type === 'text' && (
                      <>
                        <div className="tool-option">
                          <label>Color:</label>
                          <input 
                            type="color" 
                            value={selectedAnnotation.color || '#ff0000'} 
                            onChange={(e) => {
                              setSlotAnnotations(prev => ({
                                ...prev,
                                [selectedAnnotation.slotId]: (prev[selectedAnnotation.slotId] || []).map(a => 
                                  a.id === selectedAnnotation.id ? { ...a, color: e.target.value } : a
                                )
                              }));
                              setSelectedAnnotation(prev => prev ? { ...prev, color: e.target.value } : null);
                            }}
                          />
                        </div>
                        <div className="tool-option">
                          <label>Font:</label>
                          <select 
                            value={selectedAnnotation.fontFamily || 'Arial'} 
                            onChange={(e) => {
                              setSlotAnnotations(prev => ({
                                ...prev,
                                [selectedAnnotation.slotId]: (prev[selectedAnnotation.slotId] || []).map(a => 
                                  a.id === selectedAnnotation.id ? { ...a, fontFamily: e.target.value } : a
                                )
                              }));
                              setSelectedAnnotation(prev => prev ? { ...prev, fontFamily: e.target.value } : null);
                            }}
                          >
                            <option value="Arial">Arial</option>
                            <option value="Helvetica">Helvetica</option>
                            <option value="Times New Roman">Times New Roman</option>
                            <option value="Georgia">Georgia</option>
                            <option value="Courier New">Courier New</option>
                            <option value="Verdana">Verdana</option>
                            <option value="Tahoma">Tahoma</option>
                          </select>
                        </div>
                        <div className="tool-option">
                          <label>Size:</label>
                          <input 
                            type="range" 
                            min="8" 
                            max="48" 
                            value={selectedAnnotation.fontSize || 14} 
                            onChange={(e) => {
                              const newSize = parseInt(e.target.value);
                              setSlotAnnotations(prev => ({
                                ...prev,
                                [selectedAnnotation.slotId]: (prev[selectedAnnotation.slotId] || []).map(a => 
                                  a.id === selectedAnnotation.id ? { ...a, fontSize: newSize } : a
                                )
                              }));
                              setSelectedAnnotation(prev => prev ? { ...prev, fontSize: newSize } : null);
                            }}
                          />
                          <span>{selectedAnnotation.fontSize || 14}px</span>
                        </div>
                        <div className="tool-option">
                          <label>Align:</label>
                          <div className="align-buttons">
                            <button 
                              className={`align-btn ${(selectedAnnotation.textAlign || 'left') === 'left' ? 'active' : ''}`}
                              onClick={() => {
                                setSlotAnnotations(prev => ({
                                  ...prev,
                                  [selectedAnnotation.slotId]: (prev[selectedAnnotation.slotId] || []).map(a => 
                                    a.id === selectedAnnotation.id ? { ...a, textAlign: 'left' } : a
                                  )
                                }));
                                setSelectedAnnotation(prev => prev ? { ...prev, textAlign: 'left' } : null);
                              }}
                              title="Align left"
                            >
                              ⫷
                            </button>
                            <button 
                              className={`align-btn ${selectedAnnotation.textAlign === 'center' ? 'active' : ''}`}
                              onClick={() => {
                                setSlotAnnotations(prev => ({
                                  ...prev,
                                  [selectedAnnotation.slotId]: (prev[selectedAnnotation.slotId] || []).map(a => 
                                    a.id === selectedAnnotation.id ? { ...a, textAlign: 'center' } : a
                                  )
                                }));
                                setSelectedAnnotation(prev => prev ? { ...prev, textAlign: 'center' } : null);
                              }}
                              title="Align center"
                            >
                              ⫶
                            </button>
                            <button 
                              className={`align-btn ${selectedAnnotation.textAlign === 'right' ? 'active' : ''}`}
                              onClick={() => {
                                setSlotAnnotations(prev => ({
                                  ...prev,
                                  [selectedAnnotation.slotId]: (prev[selectedAnnotation.slotId] || []).map(a => 
                                    a.id === selectedAnnotation.id ? { ...a, textAlign: 'right' } : a
                                  )
                                }));
                                setSelectedAnnotation(prev => prev ? { ...prev, textAlign: 'right' } : null);
                              }}
                              title="Align right"
                            >
                              ⫸
                            </button>
                          </div>
                        </div>
                      </>
                    )}

                    {/* Polyline selected */}
                    {(selectedAnnotation.type === 'polyline' || selectedAnnotation.type === 'polylineArrow' || selectedAnnotation.type === 'cloudPolyline') && (
                      <>
                        <div className="tool-option">
                          <label>Color:</label>
                          <input 
                            type="color" 
                            value={selectedAnnotation.color || '#ff0000'} 
                            onChange={(e) => {
                              setSlotAnnotations(prev => ({
                                ...prev,
                                [selectedAnnotation.slotId]: (prev[selectedAnnotation.slotId] || []).map(a => 
                                  a.id === selectedAnnotation.id ? { ...a, color: e.target.value } : a
                                )
                              }));
                              setSelectedAnnotation(prev => prev ? { ...prev, color: e.target.value } : null);
                            }}
                          />
                        </div>
                        <div className="tool-option">
                          <label>Size:</label>
                          <input 
                            type="range" 
                            min="1" 
                            max="8" 
                            value={selectedAnnotation.strokeWidth || 2} 
                            onChange={(e) => {
                              const newWidth = parseInt(e.target.value);
                              setSlotAnnotations(prev => ({
                                ...prev,
                                [selectedAnnotation.slotId]: (prev[selectedAnnotation.slotId] || []).map(a => 
                                  a.id === selectedAnnotation.id ? { ...a, strokeWidth: newWidth } : a
                                )
                              }));
                              setSelectedAnnotation(prev => prev ? { ...prev, strokeWidth: newWidth } : null);
                            }}
                          />
                          <span>{selectedAnnotation.strokeWidth || 2}px</span>
                        </div>
                        {selectedAnnotation.points && selectedAnnotation.points.length >= 3 && (
                          <div className="tool-option">
                            <button 
                              className={`close-toggle ${selectedAnnotation.closed ? 'active' : ''}`}
                              onClick={() => {
                                const newClosed = !selectedAnnotation.closed;
                                setSlotAnnotations(prev => ({
                                  ...prev,
                                  [selectedAnnotation.slotId]: (prev[selectedAnnotation.slotId] || []).map(a => 
                                    a.id === selectedAnnotation.id ? { ...a, closed: newClosed } : a
                                  )
                                }));
                                setSelectedAnnotation(prev => prev ? { ...prev, closed: newClosed } : null);
                              }}
                              title={selectedAnnotation.closed ? "Open shape" : "Close shape"}
                            >
                              {selectedAnnotation.closed ? '◯ Open' : '● Close'}
                            </button>
                          </div>
                        )}
                        <div className="tool-option">
                          <label>Fill:</label>
                          <button 
                            title="No fill" 
                            className={`fill-toggle ${selectedAnnotation.fillColor === 'none' || !selectedAnnotation.fillColor ? 'active' : ''}`}
                            onClick={() => {
                              setSlotAnnotations(prev => ({
                                ...prev,
                                [selectedAnnotation.slotId]: (prev[selectedAnnotation.slotId] || []).map(a => 
                                  a.id === selectedAnnotation.id ? { ...a, fillColor: 'none' } : a
                                )
                              }));
                              setSelectedAnnotation(prev => prev ? { ...prev, fillColor: 'none' } : null);
                            }}
                          >
                            ∅
                          </button>
                          <input 
                            type="color" 
                            value={selectedAnnotation.fillColor === 'none' || !selectedAnnotation.fillColor ? '#ffffff' : selectedAnnotation.fillColor} 
                            onChange={(e) => {
                              setSlotAnnotations(prev => ({
                                ...prev,
                                [selectedAnnotation.slotId]: (prev[selectedAnnotation.slotId] || []).map(a => 
                                  a.id === selectedAnnotation.id ? { ...a, fillColor: e.target.value } : a
                                )
                              }));
                              setSelectedAnnotation(prev => prev ? { ...prev, fillColor: e.target.value } : null);
                            }}
                            style={{ opacity: selectedAnnotation.fillColor === 'none' || !selectedAnnotation.fillColor ? 0.5 : 1 }}
                          />
                        </div>
                        <div className="tool-option">
                          <label>Fill α:</label>
                          <input 
                            type="range" 
                            min="0.1" 
                            max="1" 
                            step="0.1"
                            value={selectedAnnotation.fillOpacity || 0.3} 
                            onChange={(e) => {
                              const newOpacity = parseFloat(e.target.value);
                              setSlotAnnotations(prev => ({
                                ...prev,
                                [selectedAnnotation.slotId]: (prev[selectedAnnotation.slotId] || []).map(a => 
                                  a.id === selectedAnnotation.id ? { ...a, fillOpacity: newOpacity } : a
                                )
                              }));
                              setSelectedAnnotation(prev => prev ? { ...prev, fillOpacity: newOpacity } : null);
                            }}
                            disabled={selectedAnnotation.fillColor === 'none' || !selectedAnnotation.fillColor}
                            style={{ opacity: selectedAnnotation.fillColor === 'none' || !selectedAnnotation.fillColor ? 0.5 : 1 }}
                          />
                          <span>{Math.round((selectedAnnotation.fillOpacity || 0.3) * 100)}%</span>
                        </div>
                      </>
                    )}

                    {/* Arc selected */}
                    {selectedAnnotation.type === 'arc' && (
                      <>
                        <div className="tool-option">
                          <label>Color:</label>
                          <input 
                            type="color" 
                            value={selectedAnnotation.color || '#ff0000'} 
                            onChange={(e) => {
                              setSlotAnnotations(prev => ({
                                ...prev,
                                [selectedAnnotation.slotId]: (prev[selectedAnnotation.slotId] || []).map(a => 
                                  a.id === selectedAnnotation.id ? { ...a, color: e.target.value } : a
                                )
                              }));
                              setSelectedAnnotation(prev => prev ? { ...prev, color: e.target.value } : null);
                            }}
                          />
                        </div>
                        <div className="tool-option">
                          <label>Size:</label>
                          <input 
                            type="range" 
                            min="1" 
                            max="8" 
                            value={selectedAnnotation.strokeWidth || 2} 
                            onChange={(e) => {
                              const newWidth = parseInt(e.target.value);
                              setSlotAnnotations(prev => ({
                                ...prev,
                                [selectedAnnotation.slotId]: (prev[selectedAnnotation.slotId] || []).map(a => 
                                  a.id === selectedAnnotation.id ? { ...a, strokeWidth: newWidth } : a
                                )
                              }));
                              setSelectedAnnotation(prev => prev ? { ...prev, strokeWidth: newWidth } : null);
                            }}
                          />
                          <span>{selectedAnnotation.strokeWidth || 2}px</span>
                        </div>
                      </>
                    )}

                    {/* Delete button for all selected annotations */}
                    <button 
                      className="delete-selected-btn"
                      onClick={() => {
                        setSlotAnnotations(prev => ({
                          ...prev,
                          [selectedAnnotation.slotId]: (prev[selectedAnnotation.slotId] || []).filter(a => a.id !== selectedAnnotation.id)
                        }));
                        setSelectedAnnotation(null);
                      }}
                      title="Delete (Del)"
                    >
                      Delete
                    </button>
                  </>
                )}
                
                {/* Pen Options */}
                {markupMode === 'pen' && (
                  <>
                    <div className="tool-option">
                      <label>Color:</label>
                      <input 
                        type="color" 
                        value={markupColor} 
                        onChange={(e) => setMarkupColor(e.target.value)}
                      />
                    </div>
                    <div className="tool-option">
                      <label>Size:</label>
                      <input 
                        type="range" 
                        min="1" 
                        max="10" 
                        value={markupStrokeWidth} 
                        onChange={(e) => setMarkupStrokeWidth(parseInt(e.target.value))}
                      />
                      <span>{markupStrokeWidth}px</span>
                    </div>
                    <button 
                      className="set-default-btn"
                      onClick={() => saveToolDefaults('pen', { color: markupColor, strokeWidth: markupStrokeWidth })}
                      title="Save current settings as default"
                    >
                      Set Default
                    </button>
                    <span className="snap-hint" style={{ marginLeft: '12px', color: '#888', fontSize: '12px' }}>
                      ⇧ Hold Shift for straight line
                    </span>
                  </>
                )}
                
                {/* Highlighter Options */}
                {markupMode === 'highlighter' && (
                  <>
                    <div className="tool-option">
                      <label>Color:</label>
                      <input 
                        type="color" 
                        value={markupColor} 
                        onChange={(e) => setMarkupColor(e.target.value)}
                      />
                    </div>
                    <div className="tool-option">
                      <label>Size:</label>
                      <input 
                        type="range" 
                        min="5" 
                        max="30" 
                        value={markupStrokeWidth * 3} 
                        onChange={(e) => setMarkupStrokeWidth(Math.round(parseInt(e.target.value) / 3))}
                      />
                      <span>{markupStrokeWidth * 3}px</span>
                    </div>
                    <div className="tool-option">
                      <label>Opacity:</label>
                      <input 
                        type="range" 
                        min="0.1" 
                        max="0.8" 
                        step="0.1"
                        value={markupOpacity} 
                        onChange={(e) => setMarkupOpacity(parseFloat(e.target.value))}
                      />
                      <span>{Math.round(markupOpacity * 100)}%</span>
                    </div>
                    <button 
                      className="set-default-btn"
                      onClick={() => saveToolDefaults('highlighter', { color: markupColor, strokeWidth: markupStrokeWidth, opacity: markupOpacity })}
                      title="Save current settings as default"
                    >
                      Set Default
                    </button>
                    <span className="snap-hint" style={{ marginLeft: '12px', color: '#888', fontSize: '12px' }}>
                      ⇧ Hold Shift for straight line
                    </span>
                  </>
                )}
                
                {/* Arrow Options */}
                {markupMode === 'arrow' && (
                  <>
                    <div className="tool-option">
                      <label>Color:</label>
                      <input 
                        type="color" 
                        value={markupColor} 
                        onChange={(e) => setMarkupColor(e.target.value)}
                      />
                    </div>
                    <div className="tool-option">
                      <label>Size:</label>
                      <input 
                        type="range" 
                        min="1" 
                        max="8" 
                        value={markupStrokeWidth} 
                        onChange={(e) => setMarkupStrokeWidth(parseInt(e.target.value))}
                      />
                      <span>{markupStrokeWidth}px</span>
                    </div>
                    <div className="tool-option">
                      <label>Head:</label>
                      <input 
                        type="range" 
                        min="6" 
                        max="30" 
                        value={markupArrowHeadSize} 
                        onChange={(e) => setMarkupArrowHeadSize(parseInt(e.target.value))}
                      />
                      <span>{markupArrowHeadSize}px</span>
                    </div>
                    <div className="tool-option">
                      <label>Style:</label>
                      <select 
                        value={markupLineStyle} 
                        onChange={(e) => setMarkupLineStyle(e.target.value)}
                      >
                        <option value="solid">━━━ Solid</option>
                        <option value="dashed">┅┅┅ Dashed</option>
                        <option value="dotted">┈┈┈ Dotted</option>
                      </select>
                    </div>
                    <button 
                      className="set-default-btn"
                      onClick={() => saveToolDefaults('arrow', { color: markupColor, strokeWidth: markupStrokeWidth, arrowHeadSize: markupArrowHeadSize, lineStyle: markupLineStyle })}
                      title="Save current settings as default"
                    >
                      Set Default
                    </button>
                    <span className="snap-hint" style={{ marginLeft: '12px', color: '#888', fontSize: '12px' }}>
                      ⇧ Hold Shift to snap
                    </span>
                  </>
                )}
                
                {/* Line Options */}
                {markupMode === 'line' && (
                  <>
                    <div className="tool-option">
                      <label>Color:</label>
                      <input 
                        type="color" 
                        value={markupColor} 
                        onChange={(e) => setMarkupColor(e.target.value)}
                      />
                    </div>
                    <div className="tool-option">
                      <label>Size:</label>
                      <input 
                        type="range" 
                        min="1" 
                        max="8" 
                        value={markupStrokeWidth} 
                        onChange={(e) => setMarkupStrokeWidth(parseInt(e.target.value))}
                      />
                      <span>{markupStrokeWidth}px</span>
                    </div>
                    <div className="tool-option">
                      <label>Style:</label>
                      <select 
                        value={markupLineStyle} 
                        onChange={(e) => setMarkupLineStyle(e.target.value)}
                      >
                        <option value="solid">━━━ Solid</option>
                        <option value="dashed">┅┅┅ Dashed</option>
                        <option value="dotted">┈┈┈ Dotted</option>
                      </select>
                    </div>
                    <button 
                      className="set-default-btn"
                      onClick={() => saveToolDefaults('line', { color: markupColor, strokeWidth: markupStrokeWidth, lineStyle: markupLineStyle })}
                      title="Save current settings as default"
                    >
                      Set Default
                    </button>
                    <span className="snap-hint" style={{ marginLeft: '12px', color: '#888', fontSize: '12px' }}>
                      ⇧ Hold Shift to snap
                    </span>
                  </>
                )}
                
                {/* Rectangle Options */}
                {markupMode === 'rectangle' && (
                  <>
                    <div className="tool-option">
                      <label>Stroke:</label>
                      <input 
                        type="color" 
                        value={markupColor} 
                        onChange={(e) => setMarkupColor(e.target.value)}
                      />
                    </div>
                    <div className="tool-option">
                      <label>Fill:</label>
                      <button 
                        title="No fill" 
                        className={`fill-toggle ${markupFillColor === 'none' ? 'active' : ''}`}
                        onClick={() => setMarkupFillColor('none')}
                      >
                        ∅
                      </button>
                      <input 
                        type="color" 
                        value={markupFillColor === 'none' ? '#ffffff' : markupFillColor} 
                        onChange={(e) => setMarkupFillColor(e.target.value)}
                        style={{ opacity: markupFillColor === 'none' ? 0.5 : 1 }}
                      />
                    </div>
                    <div className="tool-option">
                      <label>Fill α:</label>
                      <input 
                        type="range" 
                        min="0.1" 
                        max="1" 
                        step="0.1"
                        value={markupFillOpacity} 
                        onChange={(e) => setMarkupFillOpacity(parseFloat(e.target.value))}
                        disabled={markupFillColor === 'none'}
                        style={{ opacity: markupFillColor === 'none' ? 0.5 : 1 }}
                      />
                      <span>{Math.round(markupFillOpacity * 100)}%</span>
                    </div>
                    <div className="tool-option">
                      <label>Width:</label>
                      <input 
                        type="range" 
                        min="1" 
                        max="8" 
                        value={markupStrokeWidth} 
                        onChange={(e) => setMarkupStrokeWidth(parseInt(e.target.value))}
                      />
                      <span>{markupStrokeWidth}px</span>
                    </div>
                    <div className="tool-option">
                      <label>Style:</label>
                      <select 
                        value={markupLineStyle} 
                        onChange={(e) => setMarkupLineStyle(e.target.value)}
                      >
                        <option value="solid">━━━ Solid</option>
                        <option value="dashed">┅┅┅ Dashed</option>
                        <option value="dotted">┈┈┈ Dotted</option>
                      </select>
                    </div>
                    <div className="tool-option">
                      <label>Stroke α:</label>
                      <input 
                        type="range" 
                        min="0.1" 
                        max="1" 
                        step="0.1"
                        value={markupStrokeOpacity} 
                        onChange={(e) => setMarkupStrokeOpacity(parseFloat(e.target.value))}
                      />
                      <span>{Math.round(markupStrokeOpacity * 100)}%</span>
                    </div>
                    <button 
                      className="set-default-btn"
                      onClick={() => saveToolDefaults('rectangle', { 
                        color: markupColor, 
                        strokeWidth: markupStrokeWidth, 
                        fillColor: markupFillColor,
                        fillOpacity: markupFillOpacity,
                        lineStyle: markupLineStyle,
                        strokeOpacity: markupStrokeOpacity
                      })}
                      title="Save current settings as default"
                    >
                      Set Default
                    </button>
                  </>
                )}
                
                {/* Circle Options */}
                {markupMode === 'circle' && (
                  <>
                    <div className="tool-option">
                      <label>Stroke:</label>
                      <input 
                        type="color" 
                        value={markupColor} 
                        onChange={(e) => setMarkupColor(e.target.value)}
                      />
                    </div>
                    <div className="tool-option">
                      <label>Fill:</label>
                      <button 
                        title="No fill" 
                        className={`fill-toggle ${markupFillColor === 'none' ? 'active' : ''}`}
                        onClick={() => setMarkupFillColor('none')}
                      >
                        ∅
                      </button>
                      <input 
                        type="color" 
                        value={markupFillColor === 'none' ? '#ffffff' : markupFillColor} 
                        onChange={(e) => setMarkupFillColor(e.target.value)}
                        style={{ opacity: markupFillColor === 'none' ? 0.5 : 1 }}
                      />
                    </div>
                    <div className="tool-option">
                      <label>Fill α:</label>
                      <input 
                        type="range" 
                        min="0.1" 
                        max="1" 
                        step="0.1"
                        value={markupFillOpacity} 
                        onChange={(e) => setMarkupFillOpacity(parseFloat(e.target.value))}
                        disabled={markupFillColor === 'none'}
                        style={{ opacity: markupFillColor === 'none' ? 0.5 : 1 }}
                      />
                      <span>{Math.round(markupFillOpacity * 100)}%</span>
                    </div>
                    <div className="tool-option">
                      <label>Width:</label>
                      <input 
                        type="range" 
                        min="1" 
                        max="8" 
                        value={markupStrokeWidth} 
                        onChange={(e) => setMarkupStrokeWidth(parseInt(e.target.value))}
                      />
                      <span>{markupStrokeWidth}px</span>
                    </div>
                    <div className="tool-option">
                      <label>Style:</label>
                      <select 
                        value={markupLineStyle} 
                        onChange={(e) => setMarkupLineStyle(e.target.value)}
                      >
                        <option value="solid">━━━ Solid</option>
                        <option value="dashed">┅┅┅ Dashed</option>
                        <option value="dotted">┈┈┈ Dotted</option>
                      </select>
                    </div>
                    <div className="tool-option">
                      <label>Stroke α:</label>
                      <input 
                        type="range" 
                        min="0.1" 
                        max="1" 
                        step="0.1"
                        value={markupStrokeOpacity} 
                        onChange={(e) => setMarkupStrokeOpacity(parseFloat(e.target.value))}
                      />
                      <span>{Math.round(markupStrokeOpacity * 100)}%</span>
                    </div>
                    <button 
                      className="set-default-btn"
                      onClick={() => saveToolDefaults('circle', { 
                        color: markupColor, 
                        strokeWidth: markupStrokeWidth, 
                        fillColor: markupFillColor,
                        fillOpacity: markupFillOpacity,
                        lineStyle: markupLineStyle,
                        strokeOpacity: markupStrokeOpacity
                      })}
                      title="Save current settings as default"
                    >
                      Set Default
                    </button>
                  </>
                )}
                
                {/* Arc Options */}
                {markupMode === 'arc' && (
                  <>
                    <div className="tool-option">
                      <label>Color:</label>
                      <input 
                        type="color" 
                        value={markupColor} 
                        onChange={(e) => setMarkupColor(e.target.value)}
                      />
                    </div>
                    <div className="tool-option">
                      <label>Size:</label>
                      <input 
                        type="range" 
                        min="1" 
                        max="8" 
                        value={markupStrokeWidth} 
                        onChange={(e) => setMarkupStrokeWidth(parseInt(e.target.value))}
                      />
                      <span>{markupStrokeWidth}px</span>
                    </div>
                  </>
                )}
                
                {/* Cloud Options */}
                {markupMode === 'cloud' && (
                  <>
                    <div className="tool-option">
                      <label>Stroke:</label>
                      <input 
                        type="color" 
                        value={markupColor} 
                        onChange={(e) => setMarkupColor(e.target.value)}
                      />
                    </div>
                    <div className="tool-option">
                      <label>Fill:</label>
                      <button 
                        title="No fill" 
                        className={`fill-toggle ${markupFillColor === 'none' ? 'active' : ''}`}
                        onClick={() => setMarkupFillColor('none')}
                      >
                        ∅
                      </button>
                      <input 
                        type="color" 
                        value={markupFillColor === 'none' ? '#ffffff' : markupFillColor} 
                        onChange={(e) => setMarkupFillColor(e.target.value)}
                        style={{ opacity: markupFillColor === 'none' ? 0.5 : 1 }}
                      />
                    </div>
                    <div className="tool-option">
                      <label>Fill α:</label>
                      <input 
                        type="range" 
                        min="0.1" 
                        max="1" 
                        step="0.1"
                        value={markupFillOpacity} 
                        onChange={(e) => setMarkupFillOpacity(parseFloat(e.target.value))}
                        disabled={markupFillColor === 'none'}
                        style={{ opacity: markupFillColor === 'none' ? 0.5 : 1 }}
                      />
                      <span>{Math.round(markupFillOpacity * 100)}%</span>
                    </div>
                    <div className="tool-option">
                      <label>Width:</label>
                      <input 
                        type="range" 
                        min="1" 
                        max="8" 
                        value={markupStrokeWidth} 
                        onChange={(e) => setMarkupStrokeWidth(parseInt(e.target.value))}
                      />
                      <span>{markupStrokeWidth}px</span>
                    </div>
                    <div className="tool-option">
                      <label>Arc Size:</label>
                      <input 
                        type="range" 
                        min="5" 
                        max="40" 
                        value={markupCloudArcSize} 
                        onChange={(e) => setMarkupCloudArcSize(parseInt(e.target.value))}
                      />
                      <span>{markupCloudArcSize}px</span>
                    </div>
                    <div className="tool-option">
                      <label>Intensity:</label>
                      <input 
                        type="range" 
                        min="0.5" 
                        max="2" 
                        step="0.1"
                        value={markupCloudIntensity} 
                        onChange={(e) => setMarkupCloudIntensity(parseFloat(e.target.value))}
                      />
                      <span>{markupCloudIntensity.toFixed(1)}x</span>
                    </div>
                    <button 
                      className="set-default-btn"
                      onClick={() => saveToolDefaults('cloud', { 
                        color: markupColor, 
                        strokeWidth: markupStrokeWidth, 
                        fillColor: markupFillColor,
                        fillOpacity: markupFillOpacity,
                        cloudArcSize: markupCloudArcSize,
                        cloudIntensity: markupCloudIntensity
                      })}
                      title="Save current settings as default"
                    >
                      Set Default
                    </button>
                  </>
                )}
                
                {/* Polyline Options */}
                {(markupMode === 'polyline' || markupMode === 'polylineArrow' || markupMode === 'cloudPolyline') && (
                  <>
                    <div className="tool-option">
                      <label>Color:</label>
                      <input 
                        type="color" 
                        value={markupColor} 
                        onChange={(e) => setMarkupColor(e.target.value)}
                      />
                    </div>
                    <div className="tool-option">
                      <label>Size:</label>
                      <input 
                        type="range" 
                        min="1" 
                        max="8" 
                        value={markupStrokeWidth} 
                        onChange={(e) => setMarkupStrokeWidth(parseInt(e.target.value))}
                      />
                      <span>{markupStrokeWidth}px</span>
                    </div>
                    <div className="tool-option">
                      <label>Fill:</label>
                      <button 
                        title="No fill" 
                        className={`fill-toggle ${markupFillColor === 'none' ? 'active' : ''}`}
                        onClick={() => setMarkupFillColor('none')}
                      >
                        ∅
                      </button>
                      <input 
                        type="color" 
                        value={markupFillColor === 'none' ? '#ffffff' : markupFillColor} 
                        onChange={(e) => setMarkupFillColor(e.target.value)}
                        style={{ opacity: markupFillColor === 'none' ? 0.5 : 1 }}
                      />
                    </div>
                    <div className="tool-option">
                      <label>Fill α:</label>
                      <input 
                        type="range" 
                        min="0.1" 
                        max="1" 
                        step="0.1"
                        value={markupFillOpacity} 
                        onChange={(e) => setMarkupFillOpacity(parseFloat(e.target.value))}
                        disabled={markupFillColor === 'none'}
                        style={{ opacity: markupFillColor === 'none' ? 0.5 : 1 }}
                      />
                      <span>{Math.round(markupFillOpacity * 100)}%</span>
                    </div>
                    <button 
                      className="set-default-btn"
                      onClick={() => saveToolDefaults(markupMode, { 
                        color: markupColor, 
                        strokeWidth: markupStrokeWidth,
                        fillColor: markupFillColor,
                        fillOpacity: markupFillOpacity
                      })}
                      title="Save current settings as default"
                    >
                      Set Default
                    </button>
                    <span className="tool-hint">Click to add points, dbl-click or click start to close</span>
                    <span className="snap-hint" style={{ marginLeft: '12px', color: '#888', fontSize: '12px' }}>
                      ⇧ Shift to snap
                    </span>
                  </>
                )}
                
                {/* Text Options */}
                {markupMode === 'text' && (
                  <>
                    <div className="tool-option">
                      <label>Color:</label>
                      <input 
                        type="color" 
                        value={markupColor} 
                        onChange={(e) => setMarkupColor(e.target.value)}
                      />
                    </div>
                    <div className="tool-option">
                      <label>Font:</label>
                      <select 
                        value={markupFontFamily} 
                        onChange={(e) => setMarkupFontFamily(e.target.value)}
                      >
                        <option value="Arial">Arial</option>
                        <option value="Helvetica">Helvetica</option>
                        <option value="Times New Roman">Times New Roman</option>
                        <option value="Georgia">Georgia</option>
                        <option value="Courier New">Courier New</option>
                        <option value="Verdana">Verdana</option>
                        <option value="Tahoma">Tahoma</option>
                      </select>
                    </div>
                    <div className="tool-option">
                      <label>Size:</label>
                      <input 
                        type="range" 
                        min="8" 
                        max="48" 
                        value={markupFontSize} 
                        onChange={(e) => setMarkupFontSize(parseInt(e.target.value))}
                      />
                      <span>{markupFontSize}px</span>
                    </div>
                    <div className="tool-option">
                      <label>Align:</label>
                      <div className="align-buttons">
                        <button 
                          className={`align-btn ${markupTextAlign === 'left' ? 'active' : ''}`}
                          onClick={() => setMarkupTextAlign('left')}
                          title="Align left"
                        >
                          ⫷
                        </button>
                        <button 
                          className={`align-btn ${markupTextAlign === 'center' ? 'active' : ''}`}
                          onClick={() => setMarkupTextAlign('center')}
                          title="Align center"
                        >
                          ⫶
                        </button>
                        <button 
                          className={`align-btn ${markupTextAlign === 'right' ? 'active' : ''}`}
                          onClick={() => setMarkupTextAlign('right')}
                          title="Align right"
                        >
                          ⫸
                        </button>
                      </div>
                    </div>
                    <button 
                      className="set-default-btn"
                      onClick={() => saveToolDefaults('text', { 
                        color: markupColor, 
                        fontSize: markupFontSize,
                        fontFamily: markupFontFamily,
                        textAlign: markupTextAlign
                      })}
                      title="Save current settings as default"
                    >
                      Set Default
                    </button>
                    <span className="tool-hint">Click to place text box</span>
                  </>
                )}
                
                {/* Callout Options */}
                {markupMode === 'callout' && (
                  <>
                    <div className="tool-option">
                      <label>Color:</label>
                      <input 
                        type="color" 
                        value={markupColor} 
                        onChange={(e) => setMarkupColor(e.target.value)}
                      />
                    </div>
                    <span className="tool-hint">Click to place callout</span>
                  </>
                )}
                
                {/* Note Options */}
                {markupMode === 'note' && (
                  <>
                    <div className="tool-option">
                      <label>Color:</label>
                      <input 
                        type="color" 
                        value={markupColor} 
                        onChange={(e) => setMarkupColor(e.target.value)}
                      />
                    </div>
                    <span className="tool-hint">Click to place note</span>
                  </>
                )}
                
                {/* Eraser hint */}
                {markupMode === 'eraser' && (
                  <span className="tool-hint">Click on annotations to delete</span>
                )}
              </div>
            )}
          </div>
        )}
      </div>
      </div>
      {/* End of content wrapper */}
      
      {/* Object Detail Dialog */}
      {showObjectDialog && selectedObject && (
        <div className="object-dialog-overlay" onClick={() => {
          setShowObjectDialog(false);
          setObjectThumbnail(null);
        }}>
          <div className="object-dialog" onClick={(e) => e.stopPropagation()}>
            <div className="object-dialog-header">
              <h3>Edit Object</h3>
              <button className="close-btn" onClick={() => {
                setShowObjectDialog(false);
                setObjectThumbnail(null);
              }}>×</button>
            </div>
            <div className="object-dialog-content">
              {/* Thumbnail */}
              <div className="object-thumbnail-container">
                {objectThumbnail ? (
                  <img src={objectThumbnail} alt="Object thumbnail" className="object-thumbnail" />
                ) : (
                  <div className="object-thumbnail-placeholder">Loading...</div>
                )}
              </div>
              
              {/* Class selector - only show parent classes */}
              <div className="object-detail-row">
                <label>Class:</label>
                <select
                  value={selectedObject.label || selectedObject.className || ''}
                  onChange={(e) => setSelectedObject(prev => ({ ...prev, label: e.target.value }))}
                >
                  <option value="">Select class...</option>
                  {(project?.classes || []).filter(c => !c.parentId).map(cls => (
                    <option key={cls.id || cls.name} value={cls.name}>{cls.name}</option>
                  ))}
                  {/* Keep current class if not in list */}
                  {selectedObject.label && !(project?.classes || []).find(c => c.name === selectedObject.label && !c.parentId) && (
                    <option value={selectedObject.label}>{selectedObject.label}</option>
                  )}
                </select>
              </div>
              
              {/* Show different fields based on whether class has subclasses */}
              {(() => {
                const className = selectedObject.label || selectedObject.className;
                const parentClass = (project?.classes || []).find(c => c.name === className && !c.parentId);
                const subclasses = parentClass ? (project?.classes || []).filter(c => c.parentId === parentClass.id) : [];
                const hasSubclasses = subclasses.length > 0 || (selectedObject.subclassValues && Object.keys(selectedObject.subclassValues).length > 0);
                
                if (hasSubclasses) {
                  // Get all subclass names from class definition and from object's subclassValues
                  const subclassNames = new Set(subclasses.map(s => s.name));
                  if (selectedObject.subclassValues) {
                    Object.keys(selectedObject.subclassValues).forEach(k => subclassNames.add(k));
                  }
                  
                  return (
                    <>
                      <div className="subclass-fields-divider">Subclass Fields</div>
                      {Array.from(subclassNames).map(subName => (
                        <div className="object-detail-row" key={subName}>
                          <label>{subName}:</label>
                          <input
                            type="text"
                            value={selectedObject.subclassValues?.[subName] || ''}
                            onChange={(e) => setSelectedObject(prev => ({ 
                              ...prev, 
                              subclassValues: {
                                ...(prev.subclassValues || {}),
                                [subName]: e.target.value
                              }
                            }))}
                            placeholder={`Enter ${subName}...`}
                          />
                        </div>
                      ))}
                    </>
                  );
                } else {
                  // No subclasses - show just Tag field
                  return (
                    <div className="object-detail-row">
                      <label>Tag:</label>
                      <input
                        type="text"
                        value={selectedObject.ocr_text || ''}
                        onChange={(e) => setSelectedObject(prev => ({ ...prev, ocr_text: e.target.value }))}
                        placeholder="Enter tag..."
                      />
                    </div>
                  );
                }
              })()}
              
              {/* Custom columns from project - per class */}
              {(() => {
                const className = selectedObject.label || selectedObject.className;
                const classColumns = project?.classColumns?.[className] || [];
                if (classColumns.length === 0) return null;
                return (
                  <>
                    <div className="subclass-fields-divider">Custom Fields</div>
                    {classColumns.map(col => (
                      <div className="object-detail-row" key={col.id}>
                        <label>{col.name}:</label>
                        <input
                          type="text"
                          value={selectedObject[col.id] || ''}
                          onChange={(e) => setSelectedObject(prev => ({ ...prev, [col.id]: e.target.value }))}
                          placeholder={`Enter ${col.name}...`}
                        />
                      </div>
                    ))}
                  </>
                );
              })()}
              
              <div className="object-detail-row">
                <label>File:</label>
                <span>{selectedObject.filename}</span>
              </div>
              <div className="object-detail-row">
                <label>Page:</label>
                <span>{(selectedObject.page || 0) + 1}</span>
              </div>
              <div className="object-detail-row">
                <label>Confidence:</label>
                <span>{selectedObject.confidence ? `${(selectedObject.confidence * 100).toFixed(1)}%` : 'N/A'}</span>
              </div>
              
              {/* Save button */}
              <div className="object-dialog-actions">
                <button 
                  className="save-btn"
                  onClick={async () => {
                    // Update the object in local state
                    const updatedObjects = detectedObjects.map(obj =>
                      obj.id === selectedObject.id ? selectedObject : obj
                    );
                    setDetectedObjects(updatedObjects);
                    
                    // Save to backend
                    if (project?.id) {
                      try {
                        await saveObjectsToBackend(project.id, updatedObjects);
                      } catch (error) {
                        console.error('Failed to save objects to backend:', error);
                      }
                    }
                    
                    // Also update project for backwards compatibility
                    if (onProjectUpdate) {
                      onProjectUpdate({
                        ...project,
                        detectedObjects: updatedObjects
                      });
                    }
                    setShowObjectDialog(false);
                    if (objectThumbnail) URL.revokeObjectURL(objectThumbnail);
                    setObjectThumbnail(null);
                  }}
                >
                  Save Changes
                </button>
                <button 
                  className="cancel-btn"
                  onClick={() => {
                    setShowObjectDialog(false);
                    if (objectThumbnail) URL.revokeObjectURL(objectThumbnail);
                    setObjectThumbnail(null);
                  }}
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
      
      {/* Multi-Delete Confirmation Dialog */}
      {showMultiDeleteConfirm && selectedSlotIds.size > 0 && (
        <div className="object-dialog-overlay" onClick={() => setShowMultiDeleteConfirm(false)}>
          <div className="multi-delete-dialog" onClick={(e) => e.stopPropagation()}>
            <div className="object-dialog-header">
              <h3>Remove {selectedSlotIds.size} PDF{selectedSlotIds.size > 1 ? 's' : ''} from Canvas?</h3>
              <button className="close-btn" onClick={() => setShowMultiDeleteConfirm(false)}>×</button>
            </div>
            <div className="multi-delete-content">
              {(() => {
                // Check which selected slots have unsaved changes
                const slotsWithChanges = [...selectedSlotIds].filter(id => {
                  const annotations = slotAnnotations[id] || [];
                  const ownedIds = ownedAnnotationIds[id] || new Set();
                  return annotations.some(a => !a.fromPdf) || ownedIds.size > 0;
                });
                
                return (
                  <>
                    <p>The following PDFs will be removed from the canvas:</p>
                    <ul className="delete-list">
                      {[...selectedSlotIds].map(id => {
                        const slot = slots.find(s => s.id === id);
                        const hasChanges = slotsWithChanges.includes(id);
                        return slot ? (
                          <li key={id}>
                            {hasChanges && <span style={{ color: '#e74c3c', fontWeight: 'bold', marginRight: '4px' }}>*</span>}
                            {slot.fileName}
                            {hasChanges && <span style={{ color: '#e74c3c', fontSize: '11px', marginLeft: '8px' }}>(unsaved changes)</span>}
                          </li>
                        ) : null;
                      })}
                    </ul>
                    {slotsWithChanges.length > 0 && (
                      <p style={{ color: '#e74c3c', marginTop: '12px', fontSize: '13px' }}>
                        ⚠️ {slotsWithChanges.length} document{slotsWithChanges.length > 1 ? 's have' : ' has'} unsaved changes that will be lost.
                      </p>
                    )}
                  </>
                );
              })()}
            </div>
            <div className="multi-delete-actions">
              <button 
                className="cancel-btn"
                onClick={() => setShowMultiDeleteConfirm(false)}
              >
                Cancel
              </button>
              <button 
                className="delete-btn"
                onClick={() => {
                  // Check in any unlocked documents
                  slots.forEach(s => {
                    if (selectedSlotIds.has(s.id) && unlockedSlots.has(s.id)) {
                      onDocumentCheckin?.(s.fileId);
                    }
                  });
                  // Clear annotations for deleted slots
                  setSlotAnnotations(prev => {
                    const next = { ...prev };
                    selectedSlotIds.forEach(id => delete next[id]);
                    return next;
                  });
                  setOwnedAnnotationIds(prev => {
                    const next = { ...prev };
                    selectedSlotIds.forEach(id => delete next[id]);
                    return next;
                  });
                  // Clear unlocked state for deleted slots
                  setUnlockedSlots(prev => {
                    const next = new Set(prev);
                    selectedSlotIds.forEach(id => next.delete(id));
                    return next;
                  });
                  // Delete all selected slots
                  setSlots(prev => prev.filter(s => !selectedSlotIds.has(s.id)));
                  // Revoke blob URLs
                  slots.forEach(s => {
                    if (selectedSlotIds.has(s.id) && s.blobUrl) {
                      URL.revokeObjectURL(s.blobUrl);
                    }
                  });
                  // Clear selection
                  setSelectedSlotIds(new Set());
                  setShowMultiDeleteConfirm(false);
                  // Reset anchor if deleted
                  if (selectedSlotIds.has(anchorSlotId)) {
                    const remaining = slots.filter(s => !selectedSlotIds.has(s.id));
                    setAnchorSlotId(remaining.length > 0 ? remaining[0].id : null);
                  }
                }}
              >
                Remove {selectedSlotIds.size} PDF{selectedSlotIds.size > 1 ? 's' : ''}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// Component for rendering a single PDF slot on the infinite canvas
function InfiniteSlot({ 
  slot, 
  project, 
  allFiles,
  detectedObjects: allDetectedObjects,
  onHotspotClick, 
  onDimensionsUpdate,
  onPositionUpdate,
  onDoubleClick,
  onDelete,
  onSlotClick,
  slotFileName,
  isAnchor,
  isSelected,
  selectedSlotIds,
  isDragging: isSlotDragging,
  onDragStart,
  onDragEnd,
  onMultiDrag,
  zoom,
  showLabel,
  canDrag,
  currentTool,
  highlightedObjectId,
  hiddenClasses,
  refreshKey,
  onObjectClick,
  showObjectTags,
  showShadows,
  cropRegion,
  isDrawingCrop,
  onCropComplete,
  // Markup props
  markupMode,
  isSlotUnlocked,
  annotations,
  ownedAnnotationIds,
  onTakeOwnership,
  onAnnotationAdd,
  onAnnotationUpdate,
  onAnnotationDelete,
  selectedAnnotation,
  onAnnotationSelect,
  currentDrawing,
  onDrawingStart,
  onDrawingUpdate,
  onDrawingEnd,
  markupColor,
  markupStrokeWidth,
  markupOpacity,
  markupFillColor,
  markupFillOpacity,
  markupStrokeOpacity,
  markupArrowHeadSize,
  markupLineStyle,
  editingTextId,
  editingTextValue,
  setEditingTextId,
  setEditingTextValue
}) {
  const canvasRef = useRef(null);
  const [canvasSize, setCanvasSize] = useState({ width: 0, height: 0 });
  const [isRendered, setIsRendered] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });
  const [lastDragPos, setLastDragPos] = useState({ x: 0, y: 0 });
  const [isHovered, setIsHovered] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  
  // Crop drawing state
  const [cropStart, setCropStart] = useState(null);
  const [tempCropRegion, setTempCropRegion] = useState(null);
  
  // Local markup drawing state
  const [localDrawStart, setLocalDrawStart] = useState(null);
  const [penPoints, setPenPoints] = useState([]);
  const [polylinePoints, setPolylinePoints] = useState([]); // For polyline/cloudPolyline/polylineArrow
  const [polylineMousePos, setPolylineMousePos] = useState(null); // Preview line to cursor
  const textInputRef = useRef(null);
  const svgRef = useRef(null);
  const [isShiftPressed, setIsShiftPressed] = useState(false); // For snap functionality
  
  // Focus textarea when editing starts
  useEffect(() => {
    if (editingTextId && textInputRef.current) {
      // Small delay to ensure the textarea is rendered
      setTimeout(() => {
        if (textInputRef.current) {
          textInputRef.current.focus();
          // Put cursor at end of text
          const len = textInputRef.current.value?.length || 0;
          textInputRef.current.setSelectionRange(len, len);
        }
      }, 50);
    }
  }, [editingTextId]);
  
  // Manual double-click detection using click timing (native dblclick blocked by mousedown preventDefault)
  const lastClickRef = useRef({ time: 0, annId: null });
  
  const handleSvgClick = (e) => {
    // This only fires when clicking on empty space (not on annotations)
    // because annotations have stopPropagation in their onClick
    // Reset click tracking when clicking empty space
    lastClickRef.current = { time: 0, annId: null };
  };
  
  // Track shift key for snap functionality
  useEffect(() => {
    const handleKeyDown = (e) => {
      // Don't capture events when typing in input/textarea
      if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;
      if (e.key === 'Shift') setIsShiftPressed(true);
      if (e.key === 'Escape' && polylinePoints.length > 0) {
        setPolylinePoints([]);
        setPolylineMousePos(null);
      }
    };
    const handleKeyUp = (e) => {
      if (e.key === 'Shift') setIsShiftPressed(false);
    };
    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [polylinePoints]);
  
  // Clear polyline state when markup mode changes
  useEffect(() => {
    if (markupMode !== 'polyline' && markupMode !== 'polylineArrow' && markupMode !== 'cloudPolyline') {
      setPolylinePoints([]);
      setPolylineMousePos(null);
    }
  }, [markupMode]);
  
  // Annotation dragging/resizing state
  const [isMovingAnnotation, setIsMovingAnnotation] = useState(false);
  const [isResizingAnnotation, setIsResizingAnnotation] = useState(false);
  const [activeResizeHandle, setActiveResizeHandle] = useState(null);
  const [annotationMoveStart, setAnnotationMoveStart] = useState(null);
  const [draggingPolylinePoint, setDraggingPolylinePoint] = useState(null); // Index of point being dragged
  const [hoveredVertexIndex, setHoveredVertexIndex] = useState(null); // Index of vertex being hovered
  const [hoveredLineHandle, setHoveredLineHandle] = useState(null); // 'start' or 'end' for line handles
  const [hoveredRectHandle, setHoveredRectHandle] = useState(null); // 'nw', 'ne', etc for rect handles
  
  // Refs to track moving/resizing synchronously (avoid render delay)
  const isMovingRef = useRef(false);
  const isResizingRef = useRef(false);
  
  // Sync refs with state
  useEffect(() => {
    isMovingRef.current = isMovingAnnotation;
  }, [isMovingAnnotation]);
  
  useEffect(() => {
    isResizingRef.current = isResizingAnnotation;
  }, [isResizingAnnotation]);
  
  // Get bounds of an annotation for selection handles
  const getAnnotationBounds = (ann) => {
    if (!ann) return null;
    
    if (ann.type === 'pen' || ann.type === 'highlighter' || 
        ann.type === 'polyline' || ann.type === 'polylineArrow' || ann.type === 'cloudPolyline') {
      if (!ann.points || ann.points.length === 0) return null;
      let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
      ann.points.forEach(p => {
        minX = Math.min(minX, p.x);
        minY = Math.min(minY, p.y);
        maxX = Math.max(maxX, p.x);
        maxY = Math.max(maxY, p.y);
      });
      return { x: minX, y: minY, width: maxX - minX, height: maxY - minY };
    }
    
    const x = Math.min(ann.x1, ann.x2);
    const y = Math.min(ann.y1, ann.y2);
    const width = Math.abs(ann.x2 - ann.x1);
    const height = Math.abs(ann.y2 - ann.y1);
    return { x, y, width, height };
  };
  
  // Check if point is near a resize handle
  const getResizeHandleAtPoint = (x, y, bounds, annotation = null) => {
    if (!bounds) return null;
    // Larger hit area for easier grabbing (especially when zoomed out)
    const handleHitSize = 18;
    
    // For line/arrow/arc, check endpoint handles
    if (annotation && (annotation.type === 'line' || annotation.type === 'arrow' || annotation.type === 'arc')) {
      // Check start point
      if (Math.abs(x - annotation.x1) < handleHitSize && Math.abs(y - annotation.y1) < handleHitSize) {
        return 'start';
      }
      // Check end point
      if (Math.abs(x - annotation.x2) < handleHitSize && Math.abs(y - annotation.y2) < handleHitSize) {
        return 'end';
      }
      return null;
    }
    
    // For other shapes, check rectangle handles
    const handles = {
      nw: { x: bounds.x, y: bounds.y },
      ne: { x: bounds.x + bounds.width, y: bounds.y },
      sw: { x: bounds.x, y: bounds.y + bounds.height },
      se: { x: bounds.x + bounds.width, y: bounds.y + bounds.height },
      n: { x: bounds.x + bounds.width / 2, y: bounds.y },
      s: { x: bounds.x + bounds.width / 2, y: bounds.y + bounds.height },
      w: { x: bounds.x, y: bounds.y + bounds.height / 2 },
      e: { x: bounds.x + bounds.width, y: bounds.y + bounds.height / 2 }
    };
    
    for (const [name, pos] of Object.entries(handles)) {
      if (Math.abs(x - pos.x) < handleHitSize && Math.abs(y - pos.y) < handleHitSize) {
        return name;
      }
    }
    return null;
  };
  
  // Check if point is inside annotation bounds
  const isPointInBounds = (x, y, bounds) => {
    if (!bounds) return false;
    return x >= bounds.x && x <= bounds.x + bounds.width &&
           y >= bounds.y && y <= bounds.y + bounds.height;
  };
  
  // Hover state for annotations
  const [hoveredAnnotationId, setHoveredAnnotationId] = useState(null);
  
  // Helper to render annotation as SVG element
  // readOnly: if true, annotation is rendered but not interactive (for unowned PDF annotations)
  const renderAnnotation = (ann, isPreview = false, readOnly = false) => {
    const opacity = isPreview ? 0.6 : (ann.opacity || 1);
    const stroke = ann.color || markupColor;
    const strokeWidth = ann.strokeWidth || markupStrokeWidth;
    const fill = ann.fillColor === 'none' ? 'none' : (ann.fillColor || 'none');
    const fillOpacity = ann.fillOpacity || 0.3;
    const strokeOpacity = ann.strokeOpacity || 1;
    const lineStyle = ann.lineStyle || 'solid';
    const arrowHeadSize = ann.arrowHeadSize || 12;
    
    // Check if this annotation is hovered or selected
    // Disable hover effect during move/resize and when selected to prevent blue flash
    const isSelected = selectedAnnotation?.id === ann.id;
    const isHovered = hoveredAnnotationId === ann.id && !isPreview && !isMovingAnnotation && !isResizingAnnotation && !isSelected && !readOnly;
    
    // Get stroke dasharray based on line style
    const getStrokeDasharray = (style) => {
      switch (style) {
        case 'dashed': return '8,4';
        case 'dotted': return '2,4';
        case 'dashdot': return '8,4,2,4';
        case 'longdash': return '16,8';
        default: return 'none';
      }
    };
    
    const dasharray = getStrokeDasharray(lineStyle);
    
    // Common props for hover effect - disable during move/resize, when slot is locked, or when readOnly
    const hoverProps = (!isPreview && !readOnly) ? {
      'data-annotation-id': ann.id,
      onMouseEnter: () => isSlotUnlocked && !markupMode && !isMovingAnnotation && !isResizingAnnotation && !isSelected && setHoveredAnnotationId(ann.id),
      onMouseLeave: () => setHoveredAnnotationId(null),
      onMouseDown: (e) => {
        // Only allow interaction when slot is unlocked
        if (!isSlotUnlocked) return;
        
        // Double-click detection for text editing (use mousedown timing since click targets change due to re-renders)
        const now = Date.now();
        const timeDiff = now - lastClickRef.current.time;
        const sameAnnotation = lastClickRef.current.annId === ann.id;
        
        if (sameAnnotation && timeDiff < 500 && (ann.type === 'text' || ann.type === 'rectangle' || ann.type === 'circle' || ann.type === 'cloud')) {
          e.stopPropagation();
          e.preventDefault();
          setIsMovingAnnotation(false);
          setIsResizingAnnotation(false);
          setAnnotationMoveStart(null);
          setEditingTextId(ann.id);
          setEditingTextValue(ann.text || '');
          onAnnotationSelect?.(ann);
          lastClickRef.current = { time: 0, annId: null };
          return;
        }
        
        // Record this click for double-click detection
        lastClickRef.current = { time: now, annId: ann.id };
        
        // Don't start move/resize if already moving/resizing or if editing this annotation
        if (isMovingAnnotation || isResizingAnnotation) return;
        if (editingTextId === ann.id) return; // Don't interfere with editing
        
        // Close text editing if clicking on a different annotation
        if (editingTextId && editingTextId !== ann.id) {
          const currentText = textInputRef.current?.value ?? '';
          onAnnotationUpdate?.(slot.id, editingTextId, { text: currentText });
          setEditingTextId(null);
          setEditingTextValue('');
        }
        
        // Clear hover immediately when clicking
        setHoveredAnnotationId(null);
        
        // Handle click on annotation
        if (!markupMode || markupMode === 'select') {
          e.stopPropagation();
          e.preventDefault();
          
          if (!isSelected) {
            // Not selected - select it
            onAnnotationSelect?.(ann);
          } else {
            // Already selected - check for resize handle
            const svg = e.target.ownerSVGElement || e.currentTarget.ownerSVGElement;
            if (svg) {
              const point = svg.createSVGPoint();
              point.x = e.clientX;
              point.y = e.clientY;
              const ctm = svg.getScreenCTM();
              if (ctm) {
                const svgPoint = point.matrixTransform(ctm.inverse());
                const x = svgPoint.x;
                const y = svgPoint.y;
                const bounds = getAnnotationBounds(ann);
                const handle = getResizeHandleAtPoint(x, y, bounds, ann);
                if (handle) {
                  // Start resizing immediately
                  setIsResizingAnnotation(true);
                  setActiveResizeHandle(handle);
                  setAnnotationMoveStart({ x, y, annotation: { ...ann, slotId: slot.id } });
                } else {
                  // For text-editable shapes, prepare for move but don't start yet
                  // This allows double-click to work
                  // The move will start on mousemove if user drags
                  setAnnotationMoveStart({ x, y, annotation: { ...ann, slotId: slot.id }, pending: true });
                }
              }
            }
          }
        }
      },
      onClick: (e) => {
        // Just stop propagation - actual logic is in onMouseDown now
        if (isSlotUnlocked) {
          e.stopPropagation();
        }
      },
      style: { 
        cursor: !markupMode ? 'pointer' : 'crosshair',
        pointerEvents: 'auto'  // Allow clicking on annotations even when SVG has pointer-events: none
      }
    } : { style: { pointerEvents: readOnly ? 'none' : 'auto' } };
    
    switch (ann.type) {
      case 'pen':
      case 'highlighter': {
        if (!ann.points || ann.points.length < 2) return null;
        const pathData = ann.points.map((p, i) => 
          `${i === 0 ? 'M' : 'L'} ${p.x} ${p.y}`
        ).join(' ');
        return (
          <path
            key={ann.id}
            d={pathData}
            stroke={stroke}
            strokeWidth={ann.type === 'highlighter' ? strokeWidth * 4 : strokeWidth}
            fill="none"
            opacity={(ann.type === 'highlighter' ? (ann.opacity || 0.4) : opacity)}
            strokeLinecap="round"
            strokeLinejoin="round"
            {...hoverProps}
          />
        );
      }
      case 'line': {
        return (
          <line
            key={ann.id}
            x1={ann.x1}
            y1={ann.y1}
            x2={ann.x2}
            y2={ann.y2}
            stroke={stroke}
            strokeWidth={strokeWidth}
            opacity={strokeOpacity}
            strokeDasharray={dasharray !== 'none' ? dasharray : undefined}
            {...hoverProps}
          />
        );
      }
      case 'arrow': {
        const angle = Math.atan2(ann.y2 - ann.y1, ann.x2 - ann.x1);
        const headLength = arrowHeadSize;
        const headAngle = Math.PI / 6;
        const ax1 = ann.x2 - headLength * Math.cos(angle - headAngle);
        const ay1 = ann.y2 - headLength * Math.sin(angle - headAngle);
        const ax2 = ann.x2 - headLength * Math.cos(angle + headAngle);
        const ay2 = ann.y2 - headLength * Math.sin(angle + headAngle);
        const hoverStroke = stroke;
        return (
          <g key={ann.id} opacity={strokeOpacity} {...hoverProps}>
            <line
              x1={ann.x1}
              y1={ann.y1}
              x2={ann.x2}
              y2={ann.y2}
              stroke={hoverStroke}
              strokeWidth={strokeWidth}
              strokeDasharray={dasharray !== 'none' ? dasharray : undefined}
            />
            <polygon
              points={`${ann.x2},${ann.y2} ${ax1},${ay1} ${ax2},${ay2}`}
              fill={hoverStroke}
            />
          </g>
        );
      }
      case 'rectangle': {
        const x = Math.min(ann.x1, ann.x2);
        const y = Math.min(ann.y1, ann.y2);
        const w = Math.abs(ann.x2 - ann.x1);
        const h = Math.abs(ann.y2 - ann.y1);
        const isEditing = editingTextId === ann.id;
        const fontSize = ann.fontSize || 14;
        const fontFamily = ann.fontFamily || 'Arial';
        const textColor = ann.textColor || stroke;
        const textAlign = ann.textAlign || 'center';
        
        return (
          <g key={ann.id} {...hoverProps} style={{ ...hoverProps.style, pointerEvents: 'auto' }}>
            <rect
              x={x}
              y={y}
              width={w}
              height={h}
              stroke={stroke}
              strokeWidth={strokeWidth}
              strokeOpacity={strokeOpacity}
              fill={fill}
              fillOpacity={fill !== 'none' ? fillOpacity : 0}
              strokeDasharray={dasharray !== 'none' ? dasharray : undefined}
              style={{ cursor: 'pointer', pointerEvents: 'auto' }}
            />
            {/* Text content - only show when not editing (editing uses separate overlay) */}
            {!isEditing && (ann.text || isSelected) && (
              <foreignObject x={x} y={y} width={w} height={h} style={{ pointerEvents: 'none' }}>
                <div
                  xmlns="http://www.w3.org/1999/xhtml"
                  style={{
                    width: '100%',
                    height: '100%',
                    padding: '4px',
                    fontSize: `${fontSize}px`,
                    fontFamily: fontFamily + ', sans-serif',
                    color: textColor,
                    overflow: 'hidden',
                    wordWrap: 'break-word',
                    whiteSpace: 'pre-wrap',
                    lineHeight: 1.2,
                    boxSizing: 'border-box',
                    textAlign: textAlign,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: textAlign === 'left' ? 'flex-start' : textAlign === 'right' ? 'flex-end' : 'center',
                    userSelect: 'none',
                    pointerEvents: 'none'
                    }}
                  >
                    <span style={{ display: 'block' }}>{ann.text || (isSelected ? 'Double-click to edit' : '')}</span>
                  </div>
              </foreignObject>
            )}
          </g>
        );
      }
      case 'circle': {
        const cx = (ann.x1 + ann.x2) / 2;
        const cy = (ann.y1 + ann.y2) / 2;
        const rx = Math.abs(ann.x2 - ann.x1) / 2;
        const ry = Math.abs(ann.y2 - ann.y1) / 2;
        const x = Math.min(ann.x1, ann.x2);
        const y = Math.min(ann.y1, ann.y2);
        const w = Math.abs(ann.x2 - ann.x1);
        const h = Math.abs(ann.y2 - ann.y1);
        const isEditing = editingTextId === ann.id;
        const fontSize = ann.fontSize || 14;
        const fontFamily = ann.fontFamily || 'Arial';
        const textColor = ann.textColor || stroke;
        const textAlign = ann.textAlign || 'center';
        
        return (
          <g key={ann.id} {...hoverProps}>
            <ellipse
              cx={cx}
              cy={cy}
              rx={rx}
              ry={ry}
              stroke={stroke}
              strokeWidth={strokeWidth}
              strokeOpacity={strokeOpacity}
              fill={fill}
              fillOpacity={fill !== 'none' ? fillOpacity : 0}
              style={{ cursor: 'pointer', pointerEvents: 'all' }}
            />
            {/* Text content - only show when not editing */}
            {!isEditing && (ann.text || isSelected) && (
              <foreignObject x={x} y={y} width={w} height={h} style={{ pointerEvents: 'none' }}>
                <div
                  xmlns="http://www.w3.org/1999/xhtml"
                  style={{
                    width: '100%',
                    height: '100%',
                    padding: '4px',
                    fontSize: `${fontSize}px`,
                    fontFamily: fontFamily + ', sans-serif',
                    color: textColor,
                    overflow: 'hidden',
                    wordWrap: 'break-word',
                    whiteSpace: 'pre-wrap',
                    lineHeight: 1.2,
                    boxSizing: 'border-box',
                    textAlign: textAlign,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: textAlign === 'left' ? 'flex-start' : textAlign === 'right' ? 'flex-end' : 'center',
                    userSelect: 'none',
                    pointerEvents: 'none'
                  }}
                >
                  <span style={{ display: 'block' }}>{ann.text || (isSelected ? 'Double-click to edit' : '')}</span>
                </div>
              </foreignObject>
            )}
          </g>
        );
      }
      case 'cloud': {
        // Cloud shape with bumpy edges
        const x = Math.min(ann.x1, ann.x2);
        const y = Math.min(ann.y1, ann.y2);
        const w = Math.abs(ann.x2 - ann.x1);
        const h = Math.abs(ann.y2 - ann.y1);
        
        if (w < 5 || h < 5) return null;
        
        const arcSize = ann.arcSize || 15;
        const inverted = ann.inverted || false;
        const numArcsX = Math.max(1, Math.round(w / arcSize));
        const numArcsY = Math.max(1, Math.round(h / arcSize));
        const arcDiameterX = w / numArcsX;
        const arcDiameterY = h / numArcsY;
        const arcRadius = (arcDiameterX + arcDiameterY) / 4;
        const sweepOut = inverted ? 0 : 1;
        
        let cloudPath = `M ${x} ${y}`;
        // Top edge
        for (let i = 0; i < numArcsX; i++) {
          const endX = x + (i + 1) * arcDiameterX;
          cloudPath += ` A ${arcRadius} ${arcRadius} 0 0 ${sweepOut} ${endX} ${y}`;
        }
        // Right edge
        for (let i = 0; i < numArcsY; i++) {
          const endY = y + (i + 1) * arcDiameterY;
          cloudPath += ` A ${arcRadius} ${arcRadius} 0 0 ${sweepOut} ${x + w} ${endY}`;
        }
        // Bottom edge
        for (let i = numArcsX - 1; i >= 0; i--) {
          const endX = x + i * arcDiameterX;
          cloudPath += ` A ${arcRadius} ${arcRadius} 0 0 ${sweepOut} ${endX} ${y + h}`;
        }
        // Left edge
        for (let i = numArcsY - 1; i >= 0; i--) {
          const endY = y + i * arcDiameterY;
          cloudPath += ` A ${arcRadius} ${arcRadius} 0 0 ${sweepOut} ${x} ${endY}`;
        }
        cloudPath += ' Z';
        
        return (
          <path
            key={ann.id}
            d={cloudPath}
            stroke={stroke}
            strokeWidth={strokeWidth}
            strokeOpacity={strokeOpacity}
            fill={fill}
            fillOpacity={fill !== 'none' ? fillOpacity : 0}
            {...hoverProps}
          />
        );
      }
      case 'arc': {
        // Simple arc from point1 to point2 with bulge
        const bulge = ann.bulge || 0.3;
        const x1 = ann.x1;
        const y1 = ann.y1;
        const x2 = ann.x2;
        const y2 = ann.y2;
        
        // Calculate control point for quadratic bezier
        const midX = (x1 + x2) / 2;
        const midY = (y1 + y2) / 2;
        const dx = x2 - x1;
        const dy = y2 - y1;
        const dist = Math.sqrt(dx * dx + dy * dy);
        
        // Perpendicular offset for arc bulge
        const perpX = -dy / dist * dist * bulge;
        const perpY = dx / dist * dist * bulge;
        const ctrlX = midX + perpX;
        const ctrlY = midY + perpY;
        
        return (
          <path
            key={ann.id}
            d={`M ${x1} ${y1} Q ${ctrlX} ${ctrlY} ${x2} ${y2}`}
            stroke={stroke}
            strokeWidth={strokeWidth}
            strokeOpacity={strokeOpacity}
            fill="none"
            strokeDasharray={dasharray !== 'none' ? dasharray : undefined}
            {...hoverProps}
          />
        );
      }
      case 'polyline':
      case 'polylineArrow': {
        if (!ann.points || ann.points.length < 2) return null;
        const pathData = ann.points.map((p, i) => 
          `${i === 0 ? 'M' : 'L'} ${p.x} ${p.y}`
        ).join(' ') + (ann.closed ? ' Z' : '');
        
        const hoverStroke = stroke;
        
        // Arrow head for polylineArrow
        let arrowHead = null;
        if (ann.type === 'polylineArrow' && ann.points.length >= 2 && !ann.closed) {
          const lastIdx = ann.points.length - 1;
          const p1 = ann.points[lastIdx - 1];
          const p2 = ann.points[lastIdx];
          const angle = Math.atan2(p2.y - p1.y, p2.x - p1.x);
          const headLength = arrowHeadSize;
          const headAngle = Math.PI / 6;
          const ax1 = p2.x - headLength * Math.cos(angle - headAngle);
          const ay1 = p2.y - headLength * Math.sin(angle - headAngle);
          const ax2 = p2.x - headLength * Math.cos(angle + headAngle);
          const ay2 = p2.y - headLength * Math.sin(angle + headAngle);
          arrowHead = (
            <polygon
              points={`${p2.x},${p2.y} ${ax1},${ay1} ${ax2},${ay2}`}
              fill={hoverStroke}
            />
          );
        }
        
        return (
          <g key={ann.id} opacity={strokeOpacity} {...hoverProps}>
            <path
              d={pathData}
              stroke={hoverStroke}
              strokeWidth={strokeWidth}
              fill={ann.closed ? fill : 'none'}
              fillOpacity={ann.closed && fill !== 'none' ? fillOpacity : 0}
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeDasharray={dasharray !== 'none' ? dasharray : undefined}
            />
            {arrowHead}
          </g>
        );
      }
      case 'cloudPolyline': {
        if (!ann.points || ann.points.length < 2) return null;
        
        const arcSize = ann.arcSize || 12;
        const inverted = ann.inverted || false;
        const sweepDir = inverted ? 0 : 1;
        
        let cloudPath = '';
        for (let i = 0; i < ann.points.length - 1; i++) {
          const p1 = ann.points[i];
          const p2 = ann.points[i + 1];
          const dx = p2.x - p1.x;
          const dy = p2.y - p1.y;
          const segLen = Math.sqrt(dx * dx + dy * dy);
          const numArcs = Math.max(1, Math.round(segLen / arcSize));
          const arcRadius = segLen / numArcs / 2;
          
          if (i === 0) {
            cloudPath += `M ${p1.x} ${p1.y}`;
          }
          
          for (let j = 0; j < numArcs; j++) {
            const t = (j + 1) / numArcs;
            const endX = p1.x + dx * t;
            const endY = p1.y + dy * t;
            cloudPath += ` A ${arcRadius} ${arcRadius} 0 0 ${sweepDir} ${endX} ${endY}`;
          }
        }
        
        if (ann.closed) {
          const pLast = ann.points[ann.points.length - 1];
          const pFirst = ann.points[0];
          const dx = pFirst.x - pLast.x;
          const dy = pFirst.y - pLast.y;
          const segLen = Math.sqrt(dx * dx + dy * dy);
          const numArcs = Math.max(1, Math.round(segLen / arcSize));
          const arcRadius = segLen / numArcs / 2;
          
          for (let j = 0; j < numArcs; j++) {
            const t = (j + 1) / numArcs;
            const endX = pLast.x + dx * t;
            const endY = pLast.y + dy * t;
            cloudPath += ` A ${arcRadius} ${arcRadius} 0 0 ${sweepDir} ${endX} ${endY}`;
          }
          cloudPath += ' Z';
        }
        
        return (
          <path
            key={ann.id}
            d={cloudPath}
            stroke={stroke}
            strokeWidth={strokeWidth}
            strokeOpacity={strokeOpacity}
            fill={ann.closed ? fill : 'none'}
            fillOpacity={ann.closed && fill !== 'none' ? fillOpacity : 0}
            {...hoverProps}
          />
        );
      }
      case 'text': {
        // Text box with border and fill
        const x = Math.min(ann.x1, ann.x2);
        const y = Math.min(ann.y1, ann.y2);
        const w = Math.abs(ann.x2 - ann.x1);
        const h = Math.abs(ann.y2 - ann.y1);
        
        if (w < 10 || h < 10) {
          return null;
        }
        
        const fontSize = ann.fontSize || 14;
        const fontFamily = ann.fontFamily || 'Arial';
        const textColor = ann.textColor || ann.color || '#000';
        const textAlign = ann.textAlign || 'left';
        const borderColor = ann.borderColor === 'none' ? 'transparent' : (ann.borderColor || stroke);
        const bgFill = ann.fillColor === 'none' ? 'transparent' : (ann.fillColor || 'transparent');
        const isEditing = editingTextId === ann.id;
        
        // Use a div overlay for click detection since SVG events are problematic
        return (
          <g key={ann.id} data-ann-id={ann.id}>
            {/* Visible background rectangle */}
            <rect
              className="text-background-rect"
              x={x}
              y={y}
              width={w}
              height={h}
              stroke={borderColor}
              strokeWidth={strokeWidth}
              strokeOpacity={strokeOpacity}
              fill={bgFill === 'transparent' ? 'none' : bgFill}
              fillOpacity={bgFill !== 'transparent' ? fillOpacity : 0}
              pointerEvents="none"
            />
            {/* Text content - only show when not editing */}
            {!isEditing && (ann.text || isSelected) && (
              <foreignObject x={x} y={y} width={w} height={h} pointerEvents="none">
                <div
                  xmlns="http://www.w3.org/1999/xhtml"
                  style={{
                    width: '100%',
                    height: '100%',
                    padding: '4px',
                    fontSize: `${fontSize}px`,
                    fontFamily: fontFamily + ', sans-serif',
                    color: textColor,
                    overflow: 'hidden',
                    wordWrap: 'break-word',
                    whiteSpace: 'pre-wrap',
                    lineHeight: 1.2,
                    boxSizing: 'border-box',
                    textAlign: textAlign,
                    display: 'flex',
                    flexDirection: 'column',
                    justifyContent: ann.verticalAlign === 'top' ? 'flex-start' : ann.verticalAlign === 'bottom' ? 'flex-end' : 'center',
                    userSelect: 'none',
                    pointerEvents: 'none'
                  }}
                >
                  <span style={{ display: 'block' }}>{ann.text || (isSelected ? 'Double-click to edit' : '')}</span>
                </div>
              </foreignObject>
            )}
          </g>
        );
      }
      default:
        return null;
    }
  };
  
  // Helper to get SVG coordinates from mouse event
  const getSvgCoords = (e) => {
    // Try to get SVG from currentTarget, or use svgRef as fallback
    let svg = e.currentTarget;
    if (!svg || !svg.createSVGPoint) {
      svg = svgRef.current;
    }
    if (!svg || !svg.createSVGPoint) {
      // Ultimate fallback - just use client coordinates
      const rect = e.target.closest('svg')?.getBoundingClientRect();
      if (rect) {
        return { x: e.clientX - rect.left, y: e.clientY - rect.top };
      }
      return { x: 0, y: 0 };
    }
    const point = svg.createSVGPoint();
    point.x = e.clientX;
    point.y = e.clientY;
    const ctm = svg.getScreenCTM();
    if (ctm) {
      const svgPoint = point.matrixTransform(ctm.inverse());
      return { x: svgPoint.x, y: svgPoint.y };
    }
    // Fallback
    const rect = svg.getBoundingClientRect();
    return { x: e.clientX - rect.left, y: e.clientY - rect.top };
  };
  
  // Handle markup mouse events
  const handleMarkupMouseDown = (e) => {
    const { x, y } = getSvgCoords(e);
    
    // Close text editing if clicking outside the text box
    if (editingTextId) {
      const editingAnn = annotations.find(a => a.id === editingTextId);
      if (editingAnn) {
        const bounds = getAnnotationBounds(editingAnn);
        if (!bounds || !isPointInBounds(x, y, bounds)) {
          // Save and close
          const currentText = textInputRef.current?.value ?? '';
          onAnnotationUpdate?.(slot.id, editingTextId, { text: currentText });
          setEditingTextId(null);
          setEditingTextValue('');
          e.stopPropagation();
          e.preventDefault();
          return;
        }
      }
    }
    
    // If eraser mode, check if clicking on an annotation to delete
    if (markupMode === 'eraser') {
      e.stopPropagation();
      e.preventDefault();
      for (const ann of annotations) {
        const bounds = getAnnotationBounds(ann);
        if (bounds && isPointInBounds(x, y, bounds)) {
          onAnnotationDelete?.(slot.id, ann.id);
          return;
        }
      }
      return;
    }
    
    // If no markup mode or select mode, check for annotation interaction
    if (!markupMode || markupMode === 'select') {
      // Check if clicking on selected annotation's resize handle or body
      if (selectedAnnotation && selectedAnnotation.slotId === slot.id) {
        const bounds = getAnnotationBounds(selectedAnnotation);
        const handle = getResizeHandleAtPoint(x, y, bounds, selectedAnnotation);
        if (handle) {
          e.stopPropagation();
          e.preventDefault();
          setIsResizingAnnotation(true);
          setActiveResizeHandle(handle);
          setAnnotationMoveStart({ x, y, annotation: { ...selectedAnnotation } });
          return;
        }
        
        // Check if clicking inside selected annotation to move it
        if (bounds && isPointInBounds(x, y, bounds)) {
          e.stopPropagation();
          e.preventDefault();
          setIsMovingAnnotation(true);
          setAnnotationMoveStart({ x, y, annotation: { ...selectedAnnotation } });
          return;
        }
      }
      
      // Check if clicking on any annotation - let the annotation's own handler handle selection
      // This is just for fallback/bounds checking
      for (let i = annotations.length - 1; i >= 0; i--) {
        const ann = annotations[i];
        const bounds = getAnnotationBounds(ann);
        if (bounds && isPointInBounds(x, y, bounds)) {
          // Annotation's own handler should handle this, just return without deselecting
          return;
        }
      }
      
      // Clicked on empty space - deselect annotation
      if (selectedAnnotation) {
        onAnnotationSelect?.(null);
      }
      // Don't stop propagation - allow pan to work
      return;
    }
    
    // We have an active markup mode - stop propagation for drawing
    e.stopPropagation();
    e.preventDefault();
    
    // Polyline modes - click to add point
    if (markupMode === 'polyline' || markupMode === 'polylineArrow' || markupMode === 'cloudPolyline') {
      // Helper to snap coordinates
      const snapTo8Directions = (startX, startY, endX, endY) => {
        const dx = endX - startX;
        const dy = endY - startY;
        const dist = Math.sqrt(dx * dx + dy * dy);
        if (dist < 0.001) return { x: endX, y: endY };
        const angle = Math.atan2(dy, dx) * 180 / Math.PI;
        const snapAngle = Math.round(angle / 45) * 45;
        const snapRad = snapAngle * Math.PI / 180;
        return {
          x: startX + dist * Math.cos(snapRad),
          y: startY + dist * Math.sin(snapRad)
        };
      };
      
      if (polylinePoints.length === 0) {
        // First point
        setPolylinePoints([{ x, y }]);
      } else {
        // Apply snap if shift is held
        let pointX = x, pointY = y;
        if (isShiftPressed) {
          const lastPt = polylinePoints[polylinePoints.length - 1];
          const snapped = snapTo8Directions(lastPt.x, lastPt.y, x, y);
          pointX = snapped.x;
          pointY = snapped.y;
        }
        
        // Check if clicking near start point to close (need at least 3 points)
        const startPt = polylinePoints[0];
        const dist = Math.sqrt(Math.pow(pointX - startPt.x, 2) + Math.pow(pointY - startPt.y, 2));
        const closeThreshold = 15;
        
        if (polylinePoints.length >= 3 && dist < closeThreshold) {
          // Close the polyline
          const newAnnotation = {
            id: `${markupMode}_${Date.now()}`,
            type: markupMode,
            slotId: slot.id,
            points: [...polylinePoints],
            closed: true,
            color: markupColor,
            strokeWidth: markupStrokeWidth,
            fillColor: markupFillColor,
            fillOpacity: markupFillOpacity,
            strokeOpacity: markupStrokeOpacity,
            lineStyle: markupLineStyle,
            arrowHeadSize: markupArrowHeadSize
          };
          onAnnotationAdd?.(slot.id, newAnnotation);
          setPolylinePoints([]);
          setPolylineMousePos(null);
        } else {
          // Add point (with snap applied)
          setPolylinePoints(prev => [...prev, { x: pointX, y: pointY }]);
        }
      }
      return;
    }
    
    // Text mode - draw a box first, then add text on complete
    if (markupMode === 'text') {
      setLocalDrawStart({ x, y });
      onDrawingStart?.({
        id: `text_${Date.now()}`,
        type: 'text',
        slotId: slot.id,
        x1: x,
        y1: y,
        x2: x,
        y2: y,
        text: '',
        color: markupColor,
        textColor: markupColor,
        borderColor: markupColor,
        fillColor: markupFillColor,
        fillOpacity: markupFillOpacity,
        strokeWidth: markupStrokeWidth,
        strokeOpacity: markupStrokeOpacity,
        fontSize: 14,
        fontFamily: 'Arial',
        textAlign: 'left'
      });
      return;
    }
    
    // Drawing mode - start new annotation (drag-based shapes)
    setLocalDrawStart({ x, y });
    
    if (markupMode === 'pen' || markupMode === 'highlighter') {
      setPenPoints([{ x, y }]);
    }
    
    onDrawingStart?.({
      id: `${markupMode}_${Date.now()}`,
      type: markupMode,
      slotId: slot.id,
      x1: x,
      y1: y,
      x2: x,
      y2: y,
      color: markupColor,
      strokeWidth: markupStrokeWidth,
      opacity: markupOpacity,
      fillColor: markupFillColor,
      fillOpacity: markupFillOpacity,
      strokeOpacity: markupStrokeOpacity,
      arrowHeadSize: markupArrowHeadSize,
      lineStyle: markupLineStyle,
      points: markupMode === 'pen' || markupMode === 'highlighter' ? [{ x, y }] : undefined
    });
  };
  
  const handleMarkupMouseMove = (e) => {
    let { x, y } = getSvgCoords(e);
    
    // Helper function to snap coordinates to 8 directions (0°, 45°, 90°, etc.)
    const snapTo8Directions = (startX, startY, endX, endY) => {
      const dx = endX - startX;
      const dy = endY - startY;
      const dist = Math.sqrt(dx * dx + dy * dy);
      if (dist < 0.001) return { x: endX, y: endY };
      const angle = Math.atan2(dy, dx) * 180 / Math.PI;
      const snapAngle = Math.round(angle / 45) * 45;
      const snapRad = snapAngle * Math.PI / 180;
      return {
        x: startX + dist * Math.cos(snapRad),
        y: startY + dist * Math.sin(snapRad)
      };
    };
    
    // Update polyline preview line with optional snap
    if ((markupMode === 'polyline' || markupMode === 'polylineArrow' || markupMode === 'cloudPolyline') && polylinePoints.length > 0) {
      e.stopPropagation();
      let previewX = x, previewY = y;
      if (isShiftPressed) {
        const lastPt = polylinePoints[polylinePoints.length - 1];
        const snapped = snapTo8Directions(lastPt.x, lastPt.y, x, y);
        previewX = snapped.x;
        previewY = snapped.y;
      }
      setPolylineMousePos({ x: previewX, y: previewY });
      return;
    }
    
    // Check for pending move (user dragging after mousedown)
    if (annotationMoveStart?.pending && selectedAnnotation) {
      const dx = Math.abs(x - annotationMoveStart.x);
      const dy = Math.abs(y - annotationMoveStart.y);
      // Start move if dragged more than 3 pixels
      if (dx > 3 || dy > 3) {
        setIsMovingAnnotation(true);
        setAnnotationMoveStart({ ...annotationMoveStart, pending: false });
      }
      return;
    }
    
    // Handle annotation resizing
    if (isResizingAnnotation && annotationMoveStart && selectedAnnotation) {
      e.stopPropagation();
      const orig = annotationMoveStart.annotation;
      let newX1 = orig.x1, newY1 = orig.y1, newX2 = orig.x2, newY2 = orig.y2;
      
      switch (activeResizeHandle) {
        // Line/arrow endpoint handles
        case 'start': newX1 = x; newY1 = y; break;
        case 'end': newX2 = x; newY2 = y; break;
        // Rectangle corner/edge handles
        case 'nw': newX1 = x; newY1 = y; break;
        case 'ne': newX2 = x; newY1 = y; break;
        case 'sw': newX1 = x; newY2 = y; break;
        case 'se': newX2 = x; newY2 = y; break;
        case 'n': newY1 = y; break;
        case 's': newY2 = y; break;
        case 'w': newX1 = x; break;
        case 'e': newX2 = x; break;
      }
      
      onAnnotationUpdate?.(slot.id, selectedAnnotation.id, { x1: newX1, y1: newY1, x2: newX2, y2: newY2 });
      return;
    }
    
    // Handle polyline point dragging
    if (draggingPolylinePoint !== null && annotationMoveStart && selectedAnnotation && selectedAnnotation.points) {
      e.stopPropagation();
      const newPoints = [...selectedAnnotation.points];
      newPoints[draggingPolylinePoint] = { x, y };
      onAnnotationUpdate?.(slot.id, selectedAnnotation.id, { points: newPoints });
      return;
    }
    
    // Handle annotation moving
    if (isMovingAnnotation && annotationMoveStart && selectedAnnotation) {
      e.stopPropagation();
      const dx = x - annotationMoveStart.x;
      const dy = y - annotationMoveStart.y;
      const orig = annotationMoveStart.annotation;
      
      if (orig.points) {
        // Move all points for pen/highlighter/polyline
        const newPoints = orig.points.map(p => ({ x: p.x + dx, y: p.y + dy }));
        onAnnotationUpdate?.(slot.id, selectedAnnotation.id, { points: newPoints });
      } else {
        onAnnotationUpdate?.(slot.id, selectedAnnotation.id, {
          x1: orig.x1 + dx,
          y1: orig.y1 + dy,
          x2: orig.x2 + dx,
          y2: orig.y2 + dy
        });
      }
      return;
    }
    
    // Handle drawing
    if (!localDrawStart || !markupMode) return;
    
    e.stopPropagation();
    
    // Apply shift-snap for pen/highlighter
    if (markupMode === 'pen' || markupMode === 'highlighter') {
      if (isShiftPressed && penPoints.length > 0) {
        // Shift-snap: straight line from first point
        const firstPt = penPoints[0];
        const snapped = snapTo8Directions(firstPt.x, firstPt.y, x, y);
        const newPoints = [firstPt, snapped];
        setPenPoints(newPoints);
        onDrawingUpdate?.({
          ...currentDrawing,
          points: newPoints,
          x2: snapped.x,
          y2: snapped.y
        });
      } else {
        const newPoints = [...penPoints, { x, y }];
        setPenPoints(newPoints);
        onDrawingUpdate?.({
          ...currentDrawing,
          points: newPoints,
          x2: x,
          y2: y
        });
      }
    } else if (markupMode === 'line' || markupMode === 'arrow') {
      // Apply shift-snap for line/arrow
      let endX = x, endY = y;
      if (isShiftPressed) {
        const snapped = snapTo8Directions(localDrawStart.x, localDrawStart.y, x, y);
        endX = snapped.x;
        endY = snapped.y;
      }
      onDrawingUpdate?.({
        ...currentDrawing,
        x2: endX,
        y2: endY
      });
    } else {
      onDrawingUpdate?.({
        ...currentDrawing,
        x2: x,
        y2: y
      });
    }
  };
  
  // Handle double-click to complete polyline without closing
  const handleMarkupDoubleClick = (e) => {
    // Handle polyline completion on double-click
    if ((markupMode === 'polyline' || markupMode === 'polylineArrow' || markupMode === 'cloudPolyline') && polylinePoints.length >= 2) {
      e.stopPropagation();
      e.preventDefault();
      
      const newAnnotation = {
        id: `${markupMode}_${Date.now()}`,
        type: markupMode,
        slotId: slot.id,
        points: [...polylinePoints],
        closed: false,
        color: markupColor,
        strokeWidth: markupStrokeWidth,
        fillColor: markupFillColor,
        fillOpacity: markupFillOpacity,
        strokeOpacity: markupStrokeOpacity,
        lineStyle: markupLineStyle,
        arrowHeadSize: markupArrowHeadSize
      };
      onAnnotationAdd?.(slot.id, newAnnotation);
      setPolylinePoints([]);
      setPolylineMousePos(null);
      return;
    }
    
    // Check if we double-clicked on a text-editable annotation
    const coords = getSvgCoords(e);
    if (!coords) return;
    
    const { x, y } = coords;
    
    // Find annotation at click position (reverse order to get topmost first)
    for (let i = (annotations || []).length - 1; i >= 0; i--) {
      const ann = annotations[i];
      if (ann.type === 'text' || ann.type === 'rectangle' || ann.type === 'circle' || ann.type === 'cloud') {
        const bounds = getAnnotationBounds(ann);
        if (bounds && x >= bounds.x && x <= bounds.x + bounds.width && y >= bounds.y && y <= bounds.y + bounds.height) {
          e.stopPropagation();
          e.preventDefault();
          // Clear move/resize state
          setIsMovingAnnotation(false);
          setIsResizingAnnotation(false);
          setAnnotationMoveStart(null);
          // Enter edit mode
          setEditingTextId(ann.id);
          setEditingTextValue(ann.text || '');
          onAnnotationSelect?.(ann);
          return;
        }
      }
    }
  };
  
  const handleMarkupMouseUp = (e) => {
    // Clear pending move state (user clicked but didn't drag)
    if (annotationMoveStart?.pending) {
      setAnnotationMoveStart(null);
      return;
    }
    
    // End polyline point dragging
    if (draggingPolylinePoint !== null) {
      setDraggingPolylinePoint(null);
      setAnnotationMoveStart(null);
      return;
    }
    
    // End annotation moving/resizing
    if (isMovingAnnotation || isResizingAnnotation) {
      setIsMovingAnnotation(false);
      setIsResizingAnnotation(false);
      setActiveResizeHandle(null);
      setAnnotationMoveStart(null);
      return;
    }
    
    if (!localDrawStart || !markupMode) return;
    
    // Helper to snap coordinates
    const snapTo8Directions = (startX, startY, endX, endY) => {
      const dx = endX - startX;
      const dy = endY - startY;
      const dist = Math.sqrt(dx * dx + dy * dy);
      if (dist < 0.001) return { x: endX, y: endY };
      const angle = Math.atan2(dy, dx) * 180 / Math.PI;
      const snapAngle = Math.round(angle / 45) * 45;
      const snapRad = snapAngle * Math.PI / 180;
      return {
        x: startX + dist * Math.cos(snapRad),
        y: startY + dist * Math.sin(snapRad)
      };
    };
    
    // Get final coordinates
    let x, y;
    if (e && e.currentTarget) {
      const coords = getSvgCoords(e);
      x = coords.x;
      y = coords.y;
    } else {
      // Use last known position
      x = currentDrawing?.x2 || localDrawStart.x;
      y = currentDrawing?.y2 || localDrawStart.y;
    }
    
    // Apply snap for line/arrow
    if (isShiftPressed && (markupMode === 'line' || markupMode === 'arrow')) {
      const snapped = snapTo8Directions(localDrawStart.x, localDrawStart.y, x, y);
      x = snapped.x;
      y = snapped.y;
    }
    
    // For pen/highlighter with shift, use the already-snapped penPoints
    let finalPoints = penPoints;
    if (isShiftPressed && (markupMode === 'pen' || markupMode === 'highlighter') && penPoints.length > 0) {
      const firstPt = penPoints[0];
      const snapped = snapTo8Directions(firstPt.x, firstPt.y, x, y);
      finalPoints = [firstPt, snapped];
    }
    
    const finalAnnotation = {
      ...currentDrawing,
      x2: x,
      y2: y,
      points: markupMode === 'pen' || markupMode === 'highlighter' ? finalPoints : undefined
    };
    
    // Only add if it has some size
    const hasSize = markupMode === 'pen' || markupMode === 'highlighter' 
      ? finalPoints.length > 1
      : Math.abs(finalAnnotation.x2 - finalAnnotation.x1) > 5 || Math.abs(finalAnnotation.y2 - finalAnnotation.y1) > 5;
    
    if (hasSize) {
      onAnnotationAdd?.(slot.id, finalAnnotation);
      
      // For text boxes, immediately enter edit mode
      if (markupMode === 'text') {
        setTimeout(() => {
          setEditingTextId(finalAnnotation.id);
          setEditingTextValue('');
        }, 50);
      }
    }
    
    setLocalDrawStart(null);
    setPenPoints([]);
    onDrawingEnd?.();
  };
  
  // Global mouse handlers for annotation move/resize (so it works even outside SVG)
  useEffect(() => {
    // Handle pending move transition (convert mousedown to move when drag threshold exceeded)
    if (annotationMoveStart?.pending && !isMovingAnnotation && !isResizingAnnotation) {
      const handlePendingMouseMove = (e) => {
        if (!svgRef.current) return;
        
        // Get SVG coordinates
        const svg = svgRef.current;
        const point = svg.createSVGPoint();
        point.x = e.clientX;
        point.y = e.clientY;
        const ctm = svg.getScreenCTM();
        if (!ctm) return;
        const svgPoint = point.matrixTransform(ctm.inverse());
        
        const dx = Math.abs(svgPoint.x - annotationMoveStart.x);
        const dy = Math.abs(svgPoint.y - annotationMoveStart.y);
        
        // Start move if dragged more than 3 pixels
        if (dx > 3 || dy > 3) {
          setIsMovingAnnotation(true);
          setAnnotationMoveStart({ ...annotationMoveStart, pending: false });
        }
      };
      
      const handlePendingMouseUp = () => {
        // User clicked but didn't drag - clear pending state
        setAnnotationMoveStart(null);
      };
      
      window.addEventListener('mousemove', handlePendingMouseMove);
      window.addEventListener('mouseup', handlePendingMouseUp);
      
      return () => {
        window.removeEventListener('mousemove', handlePendingMouseMove);
        window.removeEventListener('mouseup', handlePendingMouseUp);
      };
    }
    
    if (!isMovingAnnotation && !isResizingAnnotation && draggingPolylinePoint === null) return;
    
    // Clear hover state when moving/resizing starts
    setHoveredAnnotationId(null);
    
    const handleGlobalMouseMove = (e) => {
      if (!svgRef.current || !annotationMoveStart || !selectedAnnotation) return;
      
      // Get SVG coordinates
      const svg = svgRef.current;
      const point = svg.createSVGPoint();
      point.x = e.clientX;
      point.y = e.clientY;
      const ctm = svg.getScreenCTM();
      if (!ctm) return;
      const svgPoint = point.matrixTransform(ctm.inverse());
      const x = svgPoint.x;
      const y = svgPoint.y;
      
      // Handle polyline point dragging
      if (draggingPolylinePoint !== null && selectedAnnotation.points) {
        const newPoints = [...selectedAnnotation.points];
        newPoints[draggingPolylinePoint] = { x, y };
        onAnnotationUpdate?.(slot.id, selectedAnnotation.id, { points: newPoints });
        return;
      }
      
      if (isResizingAnnotation) {
        const orig = annotationMoveStart.annotation;
        let newX1 = orig.x1, newY1 = orig.y1, newX2 = orig.x2, newY2 = orig.y2;
        
        switch (activeResizeHandle) {
          case 'start': newX1 = x; newY1 = y; break;
          case 'end': newX2 = x; newY2 = y; break;
          case 'nw': newX1 = x; newY1 = y; break;
          case 'ne': newX2 = x; newY1 = y; break;
          case 'sw': newX1 = x; newY2 = y; break;
          case 'se': newX2 = x; newY2 = y; break;
          case 'n': newY1 = y; break;
          case 's': newY2 = y; break;
          case 'w': newX1 = x; break;
          case 'e': newX2 = x; break;
        }
        
        onAnnotationUpdate?.(slot.id, selectedAnnotation.id, { x1: newX1, y1: newY1, x2: newX2, y2: newY2 });
      } else if (isMovingAnnotation) {
        const dx = x - annotationMoveStart.x;
        const dy = y - annotationMoveStart.y;
        const orig = annotationMoveStart.annotation;
        
        if (orig.points) {
          const newPoints = orig.points.map(p => ({ x: p.x + dx, y: p.y + dy }));
          onAnnotationUpdate?.(slot.id, selectedAnnotation.id, { points: newPoints });
        } else {
          onAnnotationUpdate?.(slot.id, selectedAnnotation.id, {
            x1: orig.x1 + dx,
            y1: orig.y1 + dy,
            x2: orig.x2 + dx,
            y2: orig.y2 + dy
          });
        }
      }
    };
    
    const handleGlobalMouseUp = () => {
      setIsMovingAnnotation(false);
      setIsResizingAnnotation(false);
      setActiveResizeHandle(null);
      setAnnotationMoveStart(null);
      setDraggingPolylinePoint(null);
    };
    
    window.addEventListener('mousemove', handleGlobalMouseMove);
    window.addEventListener('mouseup', handleGlobalMouseUp);
    
    return () => {
      window.removeEventListener('mousemove', handleGlobalMouseMove);
      window.removeEventListener('mouseup', handleGlobalMouseUp);
    };
  }, [isMovingAnnotation, isResizingAnnotation, draggingPolylinePoint, annotationMoveStart, selectedAnnotation, activeResizeHandle, slot.id, onAnnotationUpdate]);
  
  // Default colors for classes (no orange)
  const defaultColors = [
    '#3498db', '#e74c3c', '#2ecc71', '#9b59b6',
    '#1abc9c', '#e91e63', '#9c27b0', '#00bcd4', '#ff5722'
  ];
  
  const getClassColors = (classNameOrNames) => {
    // Accept single name or array of names to try
    const namesToTry = Array.isArray(classNameOrNames) 
      ? classNameOrNames.filter(Boolean) 
      : [classNameOrNames].filter(Boolean);
    
    const defaultColor = '#3498db';
    if (namesToTry.length === 0) return { fillColor: defaultColor, borderColor: defaultColor };
    
    const classes = project?.classes || [];
    const colors = project?.classColors || {};
    
    // Helper to generate hash-based color
    const getHashColor = (name) => {
      let hash = 0;
      for (let i = 0; i < (name || '').length; i++) {
        hash = name.charCodeAt(i) + ((hash << 5) - hash);
      }
      return defaultColors[Math.abs(hash) % defaultColors.length];
    };
    
    // Try each name
    for (const className of namesToTry) {
      // Try exact match in project.classes FIRST - prefer root classes (no parentId) since they have the color
      let cls = classes.find(c => c.name === className && !c.parentId);
      
      // If not found as root, try any match
      if (!cls) {
        cls = classes.find(c => c.name === className);
      }
      
      // If not found, try matching the first part of a path
      if (!cls && className.includes(' > ')) {
        const parentName = className.split(' > ')[0];
        cls = classes.find(c => c.name === parentName && !c.parentId);
      }
      
      // If still not found, try case-insensitive match
      if (!cls) {
        cls = classes.find(c => c.name?.toLowerCase() === className?.toLowerCase());
      }
      
      // If found in project.classes, return fillColor and borderColor
      if (cls) {
        const legacyColor = cls.color || getHashColor(cls.name);
        return {
          fillColor: cls.fillColor !== undefined ? cls.fillColor : legacyColor,
          borderColor: cls.borderColor !== undefined ? cls.borderColor : legacyColor
        };
      }
      
      // Fall back to legacy classColors map
      if (colors[className]) {
        return { fillColor: colors[className], borderColor: colors[className] };
      }
    }
    
    // Generate a consistent default color based on first name
    const hashColor = getHashColor(namesToTry[0]);
    return { fillColor: hashColor, borderColor: hashColor };
  };

  // Get shape type for a class (from class definition)
  const getClassShapeType = (classNameOrNames) => {
    // Accept single name or array of names to try
    const namesToTry = Array.isArray(classNameOrNames) 
      ? classNameOrNames.filter(Boolean) 
      : [classNameOrNames].filter(Boolean);
    
    if (namesToTry.length === 0) return 'rectangle';
    
    const classes = project?.classes || [];
    
    // Try each name
    for (const className of namesToTry) {
      // Try exact match first
      let cls = classes.find(c => c.name === className);
      
      // If not found, try matching the first part of a path
      if (!cls && className.includes(' > ')) {
        const parentName = className.split(' > ')[0];
        cls = classes.find(c => c.name === parentName);
      }
      
      // If still not found, try case-insensitive match
      if (!cls) {
        cls = classes.find(c => c.name?.toLowerCase() === className?.toLowerCase());
      }
      
      if (cls?.shapeType) return cls.shapeType;
    }
    
    return 'rectangle';
  };
  
  // Click/drag handlers
  const handleMouseDown = (e) => {
    // Don't process delete button clicks
    if (e.target.closest('.slot-delete-btn')) {
      return;
    }
    
    // Don't process hotspot clicks for dragging
    if (e.target.closest('.infinite-hotspot')) {
      return;
    }
    
    // Handle crop drawing
    if (isDrawingCrop && canvasRef.current) {
      e.stopPropagation();
      const canvas = canvasRef.current;
      const rect = canvas.getBoundingClientRect();
      const x = (e.clientX - rect.left) / rect.width;
      const y = (e.clientY - rect.top) / rect.height;
      setCropStart({ x, y });
      setTempCropRegion({ x, y, width: 0, height: 0 });
      return;
    }
    
    // Only start dragging when Move tool is active
    if (canDrag && currentTool === 'move') {
      e.stopPropagation();
      setIsDragging(true);
      onDragStart?.();
      const currentX = e.clientX / zoom;
      const currentY = e.clientY / zoom;
      setDragStart({ x: currentX, y: currentY });
      setLastDragPos({ x: currentX, y: currentY });
    }
    // For pan tool, let event bubble up to canvas
  };
  
  const handleMouseMove = (e) => {
    // Handle crop drawing
    if (cropStart && isDrawingCrop && canvasRef.current) {
      const canvas = canvasRef.current;
      const rect = canvas.getBoundingClientRect();
      const currentX = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
      const currentY = Math.max(0, Math.min(1, (e.clientY - rect.top) / rect.height));
      
      const x = Math.min(cropStart.x, currentX);
      const y = Math.min(cropStart.y, currentY);
      const width = Math.abs(currentX - cropStart.x);
      const height = Math.abs(currentY - cropStart.y);
      
      setTempCropRegion({ x, y, width, height });
      return;
    }
    
    if (isDragging) {
      e.stopPropagation();
      const currentX = e.clientX / zoom;
      const currentY = e.clientY / zoom;
      const deltaX = currentX - lastDragPos.x;
      const deltaY = currentY - lastDragPos.y;
      setLastDragPos({ x: currentX, y: currentY });
      
      // If this slot is selected or part of multi-select, move all selected
      if (isSelected || selectedSlotIds?.size > 0) {
        onMultiDrag?.(deltaX, deltaY);
      } else {
        // Single slot drag
        onPositionUpdate?.(slot.x + deltaX, slot.y + deltaY);
      }
    }
  };
  
  const handleMouseUp = () => {
    // Handle crop drawing completion
    if (cropStart && tempCropRegion && isDrawingCrop) {
      if (tempCropRegion.width > 0.01 && tempCropRegion.height > 0.01) {
        onCropComplete?.(tempCropRegion);
      }
      setCropStart(null);
      setTempCropRegion(null);
      return;
    }
    
    if (isDragging) {
      setIsDragging(false);
      onDragEnd?.();
    }
  };
  
  const handleDoubleClick = (e) => {
    // Don't zoom if double-clicking on a hotspot
    if (e.target.closest('.infinite-hotspot')) {
      return;
    }
    // Don't zoom if double-clicking on annotation overlay
    if (e.target.closest('.annotation-overlay')) {
      return;
    }
    e.stopPropagation();
    onDoubleClick?.();
  };
  
  useEffect(() => {
    if (isDragging || cropStart) {
      window.addEventListener('mousemove', handleMouseMove);
      window.addEventListener('mouseup', handleMouseUp);
      return () => {
        window.removeEventListener('mousemove', handleMouseMove);
        window.removeEventListener('mouseup', handleMouseUp);
      };
    }
  }, [isDragging, lastDragPos, zoom, isSelected, selectedSlotIds, cropStart, tempCropRegion, isDrawingCrop]);
  
  // Render the PDF page
  useEffect(() => {
    let renderTask = null;
    let isCancelled = false;
    
    const renderPage = async () => {
      if (!slot.pdfDoc || !canvasRef.current) return;
      
      try {
        const page = await slot.pdfDoc.getPage(slot.page);
        if (isCancelled) return;
        
        const scale = 1.5; // Base scale for good quality
        const viewport = page.getViewport({ scale });
        
        const canvas = canvasRef.current;
        const context = canvas.getContext('2d');
        
        canvas.width = viewport.width;
        canvas.height = viewport.height;
        setCanvasSize({ width: viewport.width, height: viewport.height });
        onDimensionsUpdate?.(viewport.width, viewport.height);
        
        renderTask = page.render({
          canvasContext: context,
          viewport: viewport
        });
        
        await renderTask.promise;
        
        if (!isCancelled) {
          setIsRendered(true);
        }
      } catch (error) {
        if (error.name !== 'RenderingCancelledException' && !isCancelled) {
          console.error('Error rendering page:', error);
        }
      }
    };
    
    renderPage();
    
    return () => {
      isCancelled = true;
      if (renderTask) {
        renderTask.cancel();
      }
    };
  }, [slot.pdfDoc, slot.page, slot.renderKey]);
  
  // Get hotspots for this file/page
  const hotspots = (project?.hotspots?.[slot.fileId] || []).filter(
    h => h.page === undefined || h.page === slot.page - 1
  );
  
  // Get detected objects for this file/page
  const detectedObjects = (allDetectedObjects || []).filter(
    obj => obj.filename === slot.backendFilename && obj.page === slot.page - 1
  );

  // Get cursor based on tool
  const getSlotCursor = () => {
    if (isDragging) return 'grabbing';
    if (isDrawingCrop || currentTool === 'crop') return 'crosshair';
    if (currentTool === 'pan') return 'grab';
    if (currentTool === 'move' || canDrag) return 'move';
    if (currentTool === 'zoom') return 'zoom-in';
    return 'default';
  };

  // Calculate inverse scale for UI elements to maintain constant screen size
  const uiScale = 1 / zoom;
  
  // Calculate border thickness that stays constant on screen
  const borderThickness = 8 * uiScale; // 8px on screen regardless of zoom
  
  // Calculate cropped dimensions for display
  const displayWidth = cropRegion 
    ? canvasSize.width * cropRegion.width 
    : canvasSize.width;
  const displayHeight = cropRegion 
    ? canvasSize.height * cropRegion.height 
    : canvasSize.height;

  return (
    <div 
      className={`infinite-slot ${isAnchor ? 'anchor' : ''} ${isSelected ? 'selected' : ''} ${isDragging ? 'dragging' : ''} ${!showShadows ? 'no-shadow' : ''}`}
      style={{
        position: 'absolute',
        left: slot.x,
        top: slot.y,
        cursor: getSlotCursor(),
        zIndex: isHovered ? 1000 : (isSelected ? 500 : 1),
        outline: showShadows ? (isSelected ? `${Math.max(2, borderThickness * 0.7)}px solid rgba(52, 152, 219, 0.6)` : (isDragging ? `${borderThickness}px solid #3498db` : 'none')) : 'none',
        outlineOffset: showShadows ? `${2 * uiScale}px` : 0,
      }}
      onMouseDown={(e) => {
        // Check for Ctrl/Cmd click first
        if (e.ctrlKey || e.metaKey) {
          // Ctrl+click to toggle selection - don't start drag
          e.stopPropagation();
          onSlotClick?.(e);
          return;
        }
        // Normal click - pass event and handle drag
        onSlotClick?.(e);
        handleMouseDown(e);
      }}
      onDoubleClick={handleDoubleClick}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Delete button - top right - scales inversely with zoom */}
      <button 
        className="slot-delete-btn"
        onClick={(e) => {
          e.stopPropagation();
          setShowDeleteConfirm(true);
        }}
        onMouseDown={(e) => e.stopPropagation()}
        title="Remove from view"
        style={{
          transform: `scale(${uiScale})`,
          transformOrigin: 'top right'
        }}
      >
        ×
      </button>
      
      {/* Delete confirmation dialog */}
      {showDeleteConfirm && (
        <div 
          className="slot-delete-confirm"
          style={{
            transform: `scale(${uiScale})`,
            transformOrigin: 'top right'
          }}
          onClick={(e) => e.stopPropagation()}
          onMouseDown={(e) => e.stopPropagation()}
        >
          <p>Remove "{slotFileName || slot.fileName}" from canvas?</p>
          <div className="delete-confirm-buttons">
            <button 
              className="confirm-cancel"
              onClick={() => setShowDeleteConfirm(false)}
            >
              Cancel
            </button>
            <button 
              className="confirm-delete"
              onClick={() => {
                setShowDeleteConfirm(false);
                onDelete?.();
              }}
            >
              Remove
            </button>
          </div>
        </div>
      )}
      
      {/* Hover label - shows when zoomed out below 25% */}
      {showLabel && isHovered && (
        <div 
          className="slot-hover-label"
          style={{
            transform: `translateX(-50%) scale(${uiScale})`,
            transformOrigin: 'bottom center'
          }}
        >
          {slot.fileName}
        </div>
      )}
      
      {/* Document label - always visible header - scales inversely with zoom */}
      <div 
        className="slot-label"
        style={{
          transform: `scale(${uiScale})`,
          transformOrigin: 'top left'
        }}
      >
        <span className="slot-filename">{slot.fileName}</span>
        <span className="slot-page">Page {slot.page}/{slot.numPages}</span>
        {isSlotUnlocked && (
          <span className="slot-unlocked-badge" style={{
            marginLeft: '8px',
            padding: '2px 6px',
            background: '#27ae60',
            color: '#fff',
            borderRadius: '3px',
            fontSize: '10px',
            fontWeight: '500'
          }}>
            🔓 Editing
          </span>
        )}
      </div>
      
      {/* Canvas with optional crop */}
      <div 
        className="slot-canvas-wrapper"
        style={{
          width: displayWidth || 'auto',
          height: displayHeight || 'auto',
          overflow: cropRegion ? 'hidden' : 'visible'
        }}
        onMouseDownCapture={(e) => {
          // Handle all annotation interactions at wrapper level due to CSS transform issues with SVG events
          if (isSlotUnlocked && annotations?.length > 0 && (!markupMode || markupMode === 'select')) {
            const rect = e.currentTarget.getBoundingClientRect();
            const clickX = (e.clientX - rect.left) / rect.width * canvasSize.width;
            const clickY = (e.clientY - rect.top) / rect.height * canvasSize.height;
            
            // Check if clicking on a resize handle of selected annotation first
            if (selectedAnnotation) {
              const bounds = getAnnotationBounds(selectedAnnotation);
              if (bounds) {
                const handle = getResizeHandleAtPoint(clickX, clickY, bounds, selectedAnnotation);
                if (handle) {
                  e.stopPropagation();
                  e.preventDefault();
                  setIsResizingAnnotation(true);
                  setActiveResizeHandle(handle);
                  setAnnotationMoveStart({ x: clickX, y: clickY, annotation: { ...selectedAnnotation, slotId: slot.id } });
                  return;
                }
              }
            }
            
            // Check all annotations (in reverse order - top items first)
            for (let i = annotations.length - 1; i >= 0; i--) {
              const ann = annotations[i];
              const bounds = getAnnotationBounds(ann);
              
              if (bounds && clickX >= bounds.x && clickX <= bounds.x + bounds.width && 
                  clickY >= bounds.y && clickY <= bounds.y + bounds.height) {
                
                // If this is a PDF annotation we don't own yet, take ownership first
                if (ann.fromPdf && !ownedAnnotationIds.has(ann.id)) {
                  e.stopPropagation();
                  e.preventDefault();
                  
                  // Take ownership
                  onTakeOwnership?.(slot.id, ann.id);
                  
                  // Select and prepare for drag
                  onAnnotationSelect?.({ ...ann, slotId: slot.id });
                  setAnnotationMoveStart({ x: clickX, y: clickY, annotation: { ...ann, slotId: slot.id }, pending: true });
                  return;
                }
                
                // Double-click detection for text editing
                const now = Date.now();
                const timeDiff = now - lastClickRef.current.time;
                const sameAnnotation = lastClickRef.current.annId === ann.id;
                const isTextEditable = ann.type === 'text' || ann.type === 'rectangle' || ann.type === 'circle' || ann.type === 'cloud';
                
                if (sameAnnotation && timeDiff < 500 && isTextEditable) {
                  // Double-click - enter edit mode
                  e.stopPropagation();
                  e.preventDefault();
                  setIsMovingAnnotation(false);
                  setIsResizingAnnotation(false);
                  setAnnotationMoveStart(null);
                  setEditingTextId(ann.id);
                  setEditingTextValue(ann.text || '');
                  onAnnotationSelect?.(ann);
                  lastClickRef.current = { time: 0, annId: null };
                  return;
                }
                
                // Record this click for double-click detection
                lastClickRef.current = { time: now, annId: ann.id };
                
                // Close text editing if clicking on a different annotation
                if (editingTextId && editingTextId !== ann.id) {
                  const currentText = textInputRef.current?.value ?? '';
                  onAnnotationUpdate?.(slot.id, editingTextId, { text: currentText });
                  setEditingTextId(null);
                  setEditingTextValue('');
                }
                
                e.stopPropagation();
                e.preventDefault();
                
                const isCurrentlySelected = selectedAnnotation?.id === ann.id;
                
                if (!isCurrentlySelected) {
                  // Select the annotation
                  onAnnotationSelect?.(ann);
                }
                
                // Always prepare for potential move (whether newly selected or already selected)
                setAnnotationMoveStart({ x: clickX, y: clickY, annotation: { ...ann, slotId: slot.id }, pending: true });
                return;
              }
            }
          }
        }}
        onClick={(e) => {
          // Text editing save is handled by textarea's onBlur, not here
          // This just ensures editingTextId is cleared if somehow still set
          if (editingTextId) {
            // Don't save here - onBlur already did it
            setEditingTextId(null);
            setEditingTextValue('');
          }
        }}
      >
        <canvas 
          ref={canvasRef}
          style={{
            marginLeft: cropRegion ? -cropRegion.x * canvasSize.width : 0,
            marginTop: cropRegion ? -cropRegion.y * canvasSize.height : 0
          }}
        />
        
        {/* Crop drawing overlay */}
        {isDrawingCrop && tempCropRegion && (
          <div 
            className="crop-drawing-overlay"
            style={{
              position: 'absolute',
              top: 0,
              left: 0,
              width: canvasSize.width,
              height: canvasSize.height,
              pointerEvents: 'none',
              zIndex: 100
            }}
          >
            {/* Darkened areas outside selection */}
            <div className="crop-mask" style={{
              position: 'absolute',
              top: 0,
              left: 0,
              width: '100%',
              height: `${tempCropRegion.y * 100}%`,
              background: 'rgba(0,0,0,0.5)'
            }} />
            <div className="crop-mask" style={{
              position: 'absolute',
              top: `${(tempCropRegion.y + tempCropRegion.height) * 100}%`,
              left: 0,
              width: '100%',
              bottom: 0,
              background: 'rgba(0,0,0,0.5)'
            }} />
            <div className="crop-mask" style={{
              position: 'absolute',
              top: `${tempCropRegion.y * 100}%`,
              left: 0,
              width: `${tempCropRegion.x * 100}%`,
              height: `${tempCropRegion.height * 100}%`,
              background: 'rgba(0,0,0,0.5)'
            }} />
            <div className="crop-mask" style={{
              position: 'absolute',
              top: `${tempCropRegion.y * 100}%`,
              left: `${(tempCropRegion.x + tempCropRegion.width) * 100}%`,
              right: 0,
              height: `${tempCropRegion.height * 100}%`,
              background: 'rgba(0,0,0,0.5)'
            }} />
            {/* Selection border */}
            <div 
              className="crop-selection"
              style={{
                position: 'absolute',
                left: `${tempCropRegion.x * 100}%`,
                top: `${tempCropRegion.y * 100}%`,
                width: `${tempCropRegion.width * 100}%`,
                height: `${tempCropRegion.height * 100}%`,
                border: '2px dashed #3498db',
                boxSizing: 'border-box'
              }}
            />
          </div>
        )}
        
        {/* Hotspots and Objects overlay */}
        {isRendered && (
          <div 
            className="slot-overlay"
            style={{ 
              width: canvasSize.width, 
              height: canvasSize.height,
              pointerEvents: 'none',
              marginLeft: cropRegion ? -cropRegion.x * canvasSize.width : 0,
              marginTop: cropRegion ? -cropRegion.y * canvasSize.height : 0
            }}
          >
            {/* Detected Objects */}
            {detectedObjects?.filter(obj => {
              const className = obj.label || obj.className;
              return !hiddenClasses?.has(className);
            }).map((obj, idx) => {
              // Try multiple names: label, className, parentClass
              const classNames = [obj.label, obj.className, obj.parentClass];
              const { fillColor, borderColor: classBorderColor } = getClassColors(classNames);
              // Use object's shapeType, or fall back to class definition
              const shapeType = obj.shapeType || getClassShapeType(classNames);
              const isCircle = shapeType === 'circle';
              const isPolyline = shapeType === 'polyline';
              
              // Check if fill or border are 'none'
              const isNoFill = fillColor === 'none';
              const isNoBorder = classBorderColor === 'none';
              const isFullyHidden = isNoFill && isNoBorder;
              
              // Skip fully hidden objects
              if (isFullyHidden) return null;
              
              // Convert hex to rgba for background
              const hexToRgba = (hex, alpha) => {
                if (!hex || !hex.startsWith('#')) return `rgba(52, 152, 219, ${alpha})`;
                const r = parseInt(hex.slice(1, 3), 16);
                const g = parseInt(hex.slice(3, 5), 16);
                const b = parseInt(hex.slice(5, 7), 16);
                return `rgba(${r}, ${g}, ${b}, ${alpha})`;
              };
              
              const bgColor = isNoFill ? 'transparent' : hexToRgba(fillColor, 0.15);
              const borderColor = isNoBorder ? 'transparent' : classBorderColor;
              // For label background, prefer border color if fill is none
              const labelColor = isNoBorder ? (isNoFill ? '#666' : fillColor) : classBorderColor;
              
              // For polylines, render as SVG
              if (isPolyline && obj.polylinePoints) {
                return (
                  <svg
                    key={obj.id || `obj_${idx}`}
                    style={{
                      position: 'absolute',
                      top: 0,
                      left: 0,
                      width: canvasSize.width,
                      height: canvasSize.height,
                      pointerEvents: 'none',
                      zIndex: 5,
                    }}
                  >
                    <polygon
                      points={obj.polylinePoints.map(p => 
                        `${p.x * canvasSize.width},${p.y * canvasSize.height}`
                      ).join(' ')}
                      fill={isNoFill ? 'transparent' : fillColor}
                      fillOpacity={isNoFill ? 0 : 0.15}
                      stroke={isNoBorder ? 'transparent' : borderColor}
                      strokeWidth={isNoBorder ? 0 : 2}
                      style={{ pointerEvents: 'all', cursor: 'pointer' }}
                      onClick={(e) => {
                        e.stopPropagation();
                        onObjectClick?.(obj);
                      }}
                    />
                  </svg>
                );
              }
              
              // For polylines WITHOUT polylinePoints, render as dashed rectangle
              if (isPolyline) {
                return (
                  <div
                    key={obj.id || `obj_${idx}`}
                    className={`infinite-object ${highlightedObjectId === obj.id ? 'highlighted' : ''}`}
                    style={{
                      left: obj.bbox.x * canvasSize.width,
                      top: obj.bbox.y * canvasSize.height,
                      width: obj.bbox.width * canvasSize.width,
                      height: obj.bbox.height * canvasSize.height,
                      pointerEvents: 'auto',
                      cursor: 'pointer',
                      borderColor: borderColor,
                      backgroundColor: bgColor,
                      borderStyle: 'dashed',
                      borderWidth: isNoBorder ? '0' : '2px',
                    }}
                    onClick={(e) => {
                      e.stopPropagation();
                      onObjectClick?.(obj);
                    }}
                  >
                    {showObjectTags && !isFullyHidden && (obj.ocr_text || obj.subclassValues?.Tag) && (
                      <span className="object-label" style={{ backgroundColor: labelColor }}>
                        {obj.ocr_text || obj.subclassValues?.Tag || obj.label}
                      </span>
                    )}
                  </div>
                );
              }
              
              // Rectangle or Circle
              return (
                <div
                  key={obj.id || `obj_${idx}`}
                  className={`infinite-object ${highlightedObjectId === obj.id ? 'highlighted' : ''} ${isCircle ? 'circle-shape' : ''}`}
                  style={{
                    left: obj.bbox.x * canvasSize.width,
                    top: obj.bbox.y * canvasSize.height,
                    width: obj.bbox.width * canvasSize.width,
                    height: obj.bbox.height * canvasSize.height,
                    pointerEvents: 'auto',
                    cursor: 'pointer',
                    borderColor: borderColor,
                    backgroundColor: bgColor,
                    borderRadius: isCircle ? '50%' : '0',
                    borderWidth: isNoBorder ? '0' : '2px',
                  }}
                  onClick={(e) => {
                    e.stopPropagation();
                    onObjectClick?.(obj);
                  }}
                >
                  {showObjectTags && !isFullyHidden && (obj.ocr_text || obj.subclassValues?.Tag) && (
                    <span className="object-label" style={{ backgroundColor: labelColor }}>
                      {obj.ocr_text || obj.subclassValues?.Tag || obj.label}
                    </span>
                  )}
                </div>
              );
            })}
            
            {/* Hotspots */}
            {hotspots.map((hotspot, idx) => (
              <div
                key={hotspot.id || idx}
                className={`infinite-hotspot ${hotspot.targetFileId ? 'linked' : 'unlinked'}`}
                style={{
                  left: hotspot.x * canvasSize.width,
                  top: hotspot.y * canvasSize.height,
                  width: hotspot.width * canvasSize.width,
                  height: hotspot.height * canvasSize.height,
                  pointerEvents: 'auto',
                }}
                onClick={(e) => {
                  e.stopPropagation();
                  onHotspotClick?.(hotspot);
                }}
              >
                {hotspot.label && (
                  <span className="hotspot-label">{hotspot.label}</span>
                )}
              </div>
            ))}
          </div>
        )}
        
        {/* Annotation SVG Overlay */}
        {isRendered && (
          <svg
            ref={svgRef}
            className="annotation-overlay"
            viewBox={`0 0 ${canvasSize.width} ${canvasSize.height}`}
            data-slot-unlocked={isSlotUnlocked}
            style={{
              position: 'absolute',
              top: 0,
              left: 0,
              width: canvasSize.width,
              height: canvasSize.height,
              pointerEvents: !isSlotUnlocked ? 'none' : 'auto',
              zIndex: 300,
              marginLeft: cropRegion ? -cropRegion.x * canvasSize.width : 0,
              marginTop: cropRegion ? -cropRegion.y * canvasSize.height : 0,
              cursor: markupMode && markupMode !== 'select' && markupMode !== 'eraser' 
                ? 'crosshair' 
                : markupMode === 'eraser' 
                  ? 'not-allowed'
                  : currentTool === 'pan' ? 'grab' : (selectedAnnotation ? 'default' : 'inherit')
            }}
            onMouseDown={isSlotUnlocked ? handleMarkupMouseDown : undefined}
            onMouseMove={isSlotUnlocked ? handleMarkupMouseMove : undefined}
            onMouseUp={isSlotUnlocked ? handleMarkupMouseUp : undefined}
            onMouseLeave={isSlotUnlocked ? handleMarkupMouseUp : undefined}
            onDoubleClick={isSlotUnlocked ? handleMarkupDoubleClick : undefined}
            onClick={(e) => {
              handleSvgClick(e);
              if (isSlotUnlocked) {
                e.stopPropagation();
              }
            }}
          >
            {/* Render user-created annotations AND owned PDF annotations */}
            {/* PDF annotations from the file are rendered by PDF.js until we "take ownership" */}
            {/* When ownership is taken, the annotation is deleted from PDF and rendered in SVG */}
            {annotations?.filter(ann => {
              // Always show user-created annotations
              if (!ann.fromPdf) return true;
              // Only show PDF annotations we've taken ownership of
              if (ownedAnnotationIds.has(ann.id)) return true;
              return false;
            }).map(ann => renderAnnotation(ann))}
            
            {/* Hit-test overlay for unowned PDF annotations when slot is unlocked */}
            {/* These invisible rectangles let us click on PDF-rendered annotations to take ownership */}
            {isSlotUnlocked && annotations?.filter(ann => 
              ann.fromPdf && !ownedAnnotationIds.has(ann.id)
            ).map(ann => {
              const bounds = getAnnotationBounds(ann);
              if (!bounds) {
                console.log('No bounds for annotation:', ann.id, ann.type);
                return null;
              }
              
              // Debug: log hit-test overlay being rendered
              if (ann.type === 'text') {
                console.log('Rendering hit-test overlay for text annotation:', {
                  id: ann.id,
                  bounds,
                  text: ann.text
                });
              }
              
              const padding = 5;
              return (
                <rect
                  key={`hit-${ann.id}`}
                  x={bounds.x - padding}
                  y={bounds.y - padding}
                  width={bounds.width + padding * 2}
                  height={bounds.height + padding * 2}
                  fill="rgba(0, 255, 0, 0.1)" // Slightly visible green for debugging
                  stroke="rgba(0, 255, 0, 0.3)"
                  strokeWidth={1}
                  style={{ cursor: 'pointer', pointerEvents: 'auto' }}
                  onMouseDown={(e) => {
                    e.stopPropagation();
                    e.preventDefault();
                    console.log('Hit-test clicked for:', ann.id, ann.type);
                    
                    // Take ownership of this annotation (deletes from PDF, reloads)
                    onTakeOwnership?.(slot.id, ann.id);
                    
                    // Select this annotation
                    onAnnotationSelect?.({ ...ann, slotId: slot.id });
                    
                    // Set up for potential drag
                    const wrapperRect = e.currentTarget.closest('.slot-canvas-wrapper')?.getBoundingClientRect();
                    if (wrapperRect) {
                      const clickX = (e.clientX - wrapperRect.left) / wrapperRect.width * canvasSize.width;
                      const clickY = (e.clientY - wrapperRect.top) / wrapperRect.height * canvasSize.height;
                      setAnnotationMoveStart({ x: clickX, y: clickY, annotation: { ...ann, slotId: slot.id }, pending: true });
                    }
                  }}
                />
              );
            })}
            
            {/* Render current drawing preview */}
            {currentDrawing && currentDrawing.slotId === slot.id && renderAnnotation(currentDrawing, true)}
            
            {/* Render polyline preview */}
            {polylinePoints.length > 0 && (markupMode === 'polyline' || markupMode === 'polylineArrow' || markupMode === 'cloudPolyline') && (
              <g className="polyline-preview" opacity="0.7">
                {/* Draw lines between points */}
                {polylinePoints.length >= 2 && (
                  <polyline
                    points={polylinePoints.map(p => `${p.x},${p.y}`).join(' ')}
                    stroke={markupColor}
                    strokeWidth={markupStrokeWidth}
                    fill="none"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                )}
                
                {/* Draw preview line to cursor */}
                {polylineMousePos && polylinePoints.length > 0 && (
                  <line
                    x1={polylinePoints[polylinePoints.length - 1].x}
                    y1={polylinePoints[polylinePoints.length - 1].y}
                    x2={polylineMousePos.x}
                    y2={polylineMousePos.y}
                    stroke={markupColor}
                    strokeWidth={markupStrokeWidth}
                    strokeDasharray="4,4"
                  />
                )}
                
                {/* Draw dots at each point */}
                {polylinePoints.map((p, i) => (
                  <circle
                    key={i}
                    cx={p.x}
                    cy={p.y}
                    r={4}
                    fill={i === 0 && polylinePoints.length >= 3 ? '#2ecc71' : markupColor}
                    stroke="white"
                    strokeWidth="1"
                  />
                ))}
                
                {/* Close indicator when near start */}
                {polylineMousePos && polylinePoints.length >= 3 && (() => {
                  const startPt = polylinePoints[0];
                  const dist = Math.sqrt(Math.pow(polylineMousePos.x - startPt.x, 2) + Math.pow(polylineMousePos.y - startPt.y, 2));
                  if (dist < 15) {
                    return (
                      <circle
                        cx={startPt.x}
                        cy={startPt.y}
                        r={10}
                        fill="none"
                        stroke="#2ecc71"
                        strokeWidth="2"
                        strokeDasharray="3,3"
                      />
                    );
                  }
                  return null;
                })()}
              </g>
            )}
            
            {/* Selection handles for selected annotation - hide during move/resize */}
            {selectedAnnotation && selectedAnnotation.slotId === slot.id && !isMovingAnnotation && !isResizingAnnotation && (() => {
              const bounds = getAnnotationBounds(selectedAnnotation);
              if (!bounds) return null;
              
              // Scale handles inversely with zoom so they stay visible
              const baseHandleSize = 8;
              const minScale = 1;
              const maxScale = 3;
              const handleScale = Math.min(maxScale, Math.max(minScale, 1 / zoom));
              const handleSize = baseHandleSize * handleScale;
              
              // Larger hit area for polyline points (easier to grab)
              const polylineHitSize = 25 * handleScale;
              
              const isLineType = selectedAnnotation.type === 'line' || selectedAnnotation.type === 'arrow' || selectedAnnotation.type === 'arc';
              const isPolylineType = selectedAnnotation.type === 'polyline' || selectedAnnotation.type === 'polylineArrow' || 
                                     selectedAnnotation.type === 'cloudPolyline' || selectedAnnotation.type === 'pen' || selectedAnnotation.type === 'highlighter';
              
              // For polyline types, show point handles at each vertex
              if (isPolylineType && selectedAnnotation.points && selectedAnnotation.points.length > 0) {
                const validPoints = selectedAnnotation.points.filter(p => p && p.x !== undefined && p.y !== undefined);
                if (validPoints.length === 0) return null;
                
                return (
                  <g className="selection-handles polyline-handles">
                    {/* Draw connecting lines between points */}
                    {validPoints.map((point, i) => {
                      if (i === 0) return null;
                      const prevPoint = validPoints[i - 1];
                      return (
                        <line
                          key={`line-${i}`}
                          x1={prevPoint.x}
                          y1={prevPoint.y}
                          x2={point.x}
                          y2={point.y}
                          stroke="#333"
                          strokeWidth={1 * handleScale}
                          strokeDasharray="4,4"
                          style={{ pointerEvents: 'none', filter: 'none' }}
                        />
                      );
                    })}
                    {/* Close polyline if closed */}
                    {selectedAnnotation.closed && validPoints.length > 2 && (
                      <line
                        x1={validPoints[validPoints.length - 1].x}
                        y1={validPoints[validPoints.length - 1].y}
                        x2={validPoints[0].x}
                        y2={validPoints[0].y}
                        stroke="#333"
                        strokeWidth={1 * handleScale}
                        strokeDasharray="4,4"
                        style={{ pointerEvents: 'none', filter: 'none' }}
                      />
                    )}
                    {/* Point handles at each vertex - iterate with original indices */}
                    {/* When closed, render first point last so its hit area is on top near the close point */}
                    {(() => {
                      const points = selectedAnnotation.points;
                      // Reorder: if closed, put first point at end so it renders on top
                      const renderOrder = selectedAnnotation.closed && points.length > 2
                        ? [...points.slice(1).map((p, i) => ({ point: p, originalIndex: i + 1 })), { point: points[0], originalIndex: 0 }]
                        : points.map((p, i) => ({ point: p, originalIndex: i }));
                      
                      return renderOrder.map(({ point, originalIndex }) => {
                        // Skip invalid points
                        if (!point || point.x === undefined || point.y === undefined) return null;
                        
                        const isHovered = hoveredVertexIndex === originalIndex;
                        const isDragging = draggingPolylinePoint === originalIndex;
                        const isFirstPoint = originalIndex === 0;
                        const isLastPoint = originalIndex === points.length - 1;
                        
                        return (
                          <g key={`point-${originalIndex}`}>
                            {/* Invisible larger hit area for easier clicking */}
                            <circle
                              cx={point.x}
                              cy={point.y}
                              r={polylineHitSize}
                              fill="transparent"
                              style={{ cursor: 'move', pointerEvents: 'auto' }}
                              onMouseEnter={() => setHoveredVertexIndex(originalIndex)}
                              onMouseLeave={() => setHoveredVertexIndex(null)}
                              onMouseDown={(e) => {
                                e.stopPropagation();
                                e.preventDefault();
                                const svg = e.target.ownerSVGElement;
                                if (svg) {
                                  const pt = svg.createSVGPoint();
                                  pt.x = e.clientX;
                                  pt.y = e.clientY;
                                  const ctm = svg.getScreenCTM();
                                  if (ctm) {
                                    const svgPoint = pt.matrixTransform(ctm.inverse());
                                    setDraggingPolylinePoint(originalIndex);
                                    setAnnotationMoveStart({ x: svgPoint.x, y: svgPoint.y, annotation: { ...selectedAnnotation } });
                                  }
                                }
                              }}
                            />
                            {/* Hover ring - shows when hovering */}
                            {isHovered && !isDragging && (
                              <circle
                                cx={point.x}
                                cy={point.y}
                                r={handleSize * 1.2}
                                fill="transparent"
                                stroke={isFirstPoint && selectedAnnotation.closed ? '#2ecc71' : '#3498db'}
                                strokeWidth={2 * handleScale}
                                strokeOpacity={0.5}
                                style={{ pointerEvents: 'none', filter: 'none' }}
                              />
                            )}
                            {/* Visible handle - first point is green when closed */}
                            <circle
                              cx={point.x}
                              cy={point.y}
                              r={isHovered || isDragging ? handleSize * 0.9 : handleSize * 0.7}
                              fill={isDragging ? '#3498db' : isHovered ? '#555' : (isFirstPoint && selectedAnnotation.closed ? '#27ae60' : '#333')}
                              stroke="#fff"
                              strokeWidth={1.5 * handleScale}
                              style={{ cursor: 'move', pointerEvents: 'none', filter: 'none' }}
                              className="polyline-point-handle"
                              data-point-index={originalIndex}
                            />
                          </g>
                        );
                      });
                    })()}
                  </g>
                );
              }
              
              // For line/arrow/arc, show circle handles at endpoints
              if (isLineType) {
                return (
                  <g className="selection-handles">
                    {/* Dashed line connecting endpoints */}
                    <line
                      x1={selectedAnnotation.x1}
                      y1={selectedAnnotation.y1}
                      x2={selectedAnnotation.x2}
                      y2={selectedAnnotation.y2}
                      stroke="#333"
                      strokeWidth={1 * handleScale}
                      strokeDasharray="4,4"
                      style={{ pointerEvents: 'none', filter: 'none' }}
                    />
                    {/* Start point handle - invisible hit area */}
                    <circle
                      cx={selectedAnnotation.x1}
                      cy={selectedAnnotation.y1}
                      r={polylineHitSize}
                      fill="transparent"
                      style={{ cursor: 'move', pointerEvents: 'auto' }}
                      data-handle="start"
                      onMouseEnter={() => setHoveredLineHandle('start')}
                      onMouseLeave={() => setHoveredLineHandle(null)}
                      onMouseDown={(e) => {
                        e.stopPropagation();
                        e.preventDefault();
                        const svg = e.target.ownerSVGElement;
                        if (svg) {
                          const point = svg.createSVGPoint();
                          point.x = e.clientX;
                          point.y = e.clientY;
                          const ctm = svg.getScreenCTM();
                          if (ctm) {
                            const svgPoint = point.matrixTransform(ctm.inverse());
                            setIsResizingAnnotation(true);
                            setActiveResizeHandle('start');
                            setAnnotationMoveStart({ x: svgPoint.x, y: svgPoint.y, annotation: { ...selectedAnnotation } });
                          }
                        }
                      }}
                    />
                    {/* Start point hover ring */}
                    {hoveredLineHandle === 'start' && activeResizeHandle !== 'start' && (
                      <circle
                        cx={selectedAnnotation.x1}
                        cy={selectedAnnotation.y1}
                        r={handleSize * 1.2}
                        fill="transparent"
                        stroke="#3498db"
                        strokeWidth={2 * handleScale}
                        strokeOpacity={0.5}
                        style={{ pointerEvents: 'none', filter: 'none' }}
                      />
                    )}
                    {/* Start point handle - visible */}
                    <circle
                      cx={selectedAnnotation.x1}
                      cy={selectedAnnotation.y1}
                      r={hoveredLineHandle === 'start' || activeResizeHandle === 'start' ? handleSize * 0.9 : handleSize * 0.7}
                      fill={activeResizeHandle === 'start' ? '#3498db' : hoveredLineHandle === 'start' ? '#555' : '#333'}
                      stroke="#fff"
                      strokeWidth={1.5 * handleScale}
                      style={{ pointerEvents: 'none', filter: 'none' }}
                    />
                    {/* End point handle - invisible hit area */}
                    <circle
                      cx={selectedAnnotation.x2}
                      cy={selectedAnnotation.y2}
                      r={polylineHitSize}
                      fill="transparent"
                      style={{ cursor: 'move', pointerEvents: 'auto' }}
                      data-handle="end"
                      onMouseEnter={() => setHoveredLineHandle('end')}
                      onMouseLeave={() => setHoveredLineHandle(null)}
                      onMouseDown={(e) => {
                        e.stopPropagation();
                        e.preventDefault();
                        const svg = e.target.ownerSVGElement;
                        if (svg) {
                          const point = svg.createSVGPoint();
                          point.x = e.clientX;
                          point.y = e.clientY;
                          const ctm = svg.getScreenCTM();
                          if (ctm) {
                            const svgPoint = point.matrixTransform(ctm.inverse());
                            setIsResizingAnnotation(true);
                            setActiveResizeHandle('end');
                            setAnnotationMoveStart({ x: svgPoint.x, y: svgPoint.y, annotation: { ...selectedAnnotation } });
                          }
                        }
                      }}
                    />
                    {/* End point hover ring */}
                    {hoveredLineHandle === 'end' && activeResizeHandle !== 'end' && (
                      <circle
                        cx={selectedAnnotation.x2}
                        cy={selectedAnnotation.y2}
                        r={handleSize * 1.2}
                        fill="transparent"
                        stroke="#3498db"
                        strokeWidth={2 * handleScale}
                        strokeOpacity={0.5}
                        style={{ pointerEvents: 'none', filter: 'none' }}
                      />
                    )}
                    {/* End point handle - visible */}
                    <circle
                      cx={selectedAnnotation.x2}
                      cy={selectedAnnotation.y2}
                      r={hoveredLineHandle === 'end' || activeResizeHandle === 'end' ? handleSize * 0.9 : handleSize * 0.7}
                      fill={activeResizeHandle === 'end' ? '#3498db' : hoveredLineHandle === 'end' ? '#555' : '#333'}
                      stroke="#fff"
                      strokeWidth={1.5 * handleScale}
                      style={{ pointerEvents: 'none', filter: 'none' }}
                    />
                  </g>
                );
              }
              
              // For other shapes, show rectangle handles
              const handles = [
                { name: 'nw', x: bounds.x, y: bounds.y, cursor: 'nwse-resize' },
                { name: 'ne', x: bounds.x + bounds.width, y: bounds.y, cursor: 'nesw-resize' },
                { name: 'sw', x: bounds.x, y: bounds.y + bounds.height, cursor: 'nesw-resize' },
                { name: 'se', x: bounds.x + bounds.width, y: bounds.y + bounds.height, cursor: 'nwse-resize' },
                { name: 'n', x: bounds.x + bounds.width / 2, y: bounds.y, cursor: 'ns-resize' },
                { name: 's', x: bounds.x + bounds.width / 2, y: bounds.y + bounds.height, cursor: 'ns-resize' },
                { name: 'w', x: bounds.x, y: bounds.y + bounds.height / 2, cursor: 'ew-resize' },
                { name: 'e', x: bounds.x + bounds.width, y: bounds.y + bounds.height / 2, cursor: 'ew-resize' }
              ];
              
              return (
                <g className="selection-handles">
                  {/* Selection border */}
                  <rect
                    x={bounds.x - 2 * handleScale}
                    y={bounds.y - 2 * handleScale}
                    width={bounds.width + 4 * handleScale}
                    height={bounds.height + 4 * handleScale}
                    fill="none"
                    stroke="#333"
                    strokeWidth={1 * handleScale}
                    strokeDasharray="4,4"
                    style={{ pointerEvents: 'none', filter: 'none' }}
                  />
                  
                  {/* Resize handles - with larger invisible hit areas */}
                  {handles.map(h => {
                    const isHovered = hoveredRectHandle === h.name;
                    const isActive = activeResizeHandle === h.name;
                    return (
                    <g key={h.name}>
                      {/* Invisible larger hit area */}
                      <rect
                        x={h.x - polylineHitSize / 2}
                        y={h.y - polylineHitSize / 2}
                        width={polylineHitSize}
                        height={polylineHitSize}
                        fill="transparent"
                        style={{ cursor: h.cursor, pointerEvents: 'auto' }}
                        onMouseEnter={() => setHoveredRectHandle(h.name)}
                        onMouseLeave={() => setHoveredRectHandle(null)}
                        onMouseDown={(e) => {
                          e.stopPropagation();
                          e.preventDefault();
                          const svg = e.target.ownerSVGElement;
                          if (svg) {
                            const point = svg.createSVGPoint();
                            point.x = e.clientX;
                            point.y = e.clientY;
                            const ctm = svg.getScreenCTM();
                            if (ctm) {
                              const svgPoint = point.matrixTransform(ctm.inverse());
                              setIsResizingAnnotation(true);
                              setActiveResizeHandle(h.name);
                              setAnnotationMoveStart({ x: svgPoint.x, y: svgPoint.y, annotation: { ...selectedAnnotation } });
                            }
                          }
                        }}
                      />
                      {/* Hover ring */}
                      {isHovered && !isActive && (
                        <rect
                          x={h.x - handleSize * 0.8}
                          y={h.y - handleSize * 0.8}
                          width={handleSize * 1.6}
                          height={handleSize * 1.6}
                          fill="transparent"
                          stroke="#3498db"
                          strokeWidth={2 * handleScale}
                          strokeOpacity={0.5}
                          style={{ pointerEvents: 'none', filter: 'none' }}
                        />
                      )}
                      {/* Visible handle */}
                      <rect
                        x={h.x - (isHovered || isActive ? handleSize * 0.6 : handleSize / 2)}
                        y={h.y - (isHovered || isActive ? handleSize * 0.6 : handleSize / 2)}
                        width={isHovered || isActive ? handleSize * 1.2 : handleSize}
                        height={isHovered || isActive ? handleSize * 1.2 : handleSize}
                        fill={isActive ? '#3498db' : isHovered ? '#555' : '#333'}
                        stroke="#fff"
                        strokeWidth={1 * handleScale}
                        style={{ pointerEvents: 'none', filter: 'none' }}
                      />
                    </g>
                  );
                  })}
                </g>
              );
            })()}
            
            {/* Text editing overlay - rendered separately on top of everything */}
            {editingTextId && (() => {
              const ann = annotations?.find(a => a.id === editingTextId);
              if (!ann) return null;
              
              const isTextEditable = ann.type === 'text' || ann.type === 'rectangle' || ann.type === 'circle' || ann.type === 'cloud';
              if (!isTextEditable) return null;
              
              const x = Math.min(ann.x1, ann.x2);
              const y = Math.min(ann.y1, ann.y2);
              const w = Math.abs(ann.x2 - ann.x1);
              const h = Math.abs(ann.y2 - ann.y1);
              
              const fontSize = ann.fontSize || 14;
              const fontFamily = ann.fontFamily || 'Arial';
              const textColor = ann.textColor || ann.color || '#000';
              const textAlign = ann.textAlign || (ann.type === 'text' ? 'left' : 'center');
              
              return (
                <foreignObject
                  x={x}
                  y={y}
                  width={w}
                  height={h}
                  style={{ overflow: 'visible', pointerEvents: 'auto' }}
                >
                  <textarea
                    xmlns="http://www.w3.org/1999/xhtml"
                    ref={textInputRef}
                    defaultValue={ann.text || ''}
                    onBlur={(e) => {
                      onAnnotationUpdate?.(slot.id, ann.id, { text: e.target.value });
                      setEditingTextId(null);
                    }}
                    onFocus={(e) => {
                      const len = e.target.value.length;
                      e.target.setSelectionRange(len, len);
                    }}
                    onKeyDown={(e) => {
                      e.stopPropagation();
                      if (e.key === 'Escape') {
                        // Escape cancels - just close without saving
                        setEditingTextId(null);
                      }
                    }}
                    onClick={(e) => e.stopPropagation()}
                    onMouseDown={(e) => e.stopPropagation()}
                    autoFocus
                    style={{
                      width: '100%',
                      height: '100%',
                      border: '2px solid #3498db',
                      borderRadius: ann.type === 'circle' ? '50%' : '0',
                      padding: '4px',
                      fontSize: `${fontSize}px`,
                      fontFamily: fontFamily + ', sans-serif',
                      color: textColor,
                      background: 'transparent',
                      outline: 'none',
                      resize: 'none',
                      boxSizing: 'border-box',
                      textAlign: textAlign,
                    }}
                    placeholder="Type text... (click outside to save, Esc to cancel)"
                  />
                </foreignObject>
              );
            })()}
          </svg>
        )}
      </div>
    </div>
  );
}
