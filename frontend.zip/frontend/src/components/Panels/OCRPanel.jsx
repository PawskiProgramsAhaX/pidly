/**
 * OCRPanel.jsx
 * 
 * Panel for OCR - extracting text from PDF pages including pipe tags.
 */

import { useState, useMemo, useCallback, useRef, useEffect } from 'react';

// Simple text matching function
// matchType: 'contains' | 'starts' | 'ends' | 'exact'
function matchText(text, searchText, matchType) {
  if (!text || !searchText) return false;
  
  const normalizedText = text.toLowerCase();
  const normalizedSearch = searchText.toLowerCase();
  
  switch (matchType) {
    case 'starts':
      return normalizedText.startsWith(normalizedSearch);
    case 'ends':
      return normalizedText.endsWith(normalizedSearch);
    case 'exact':
      return normalizedText === normalizedSearch;
    case 'contains':
    default:
      return normalizedText.includes(normalizedSearch);
  }
}

export default function OCRPanel({
  isOpen,
  onClose,
  // Display
  showOcrOnPdf,
  onShowOcrOnPdfChange,
  // Scope
  ocrScope,
  onOcrScopeChange,
  // Context
  currentFile,
  numPages,
  currentPage,
  // Folder/Project context
  currentFolderInfo,
  projectFileCount,
  // OCR state
  isRunningOcr,
  ocrProgress,
  ocrResults,
  ocrResultsCount, // Total count across all files for this project
  // Filter
  ocrFilter,
  onOcrFilterChange,
  ocrFilterType,
  onOcrFilterTypeChange,
  // Actions
  onRunOcr,
  onCancelOcr,
  onExportOcr,
  onExportToObjects,
  // Search integration
  includeOcrInSearch,
  onIncludeOcrInSearchChange,
  // Existing classes for dropdown
  existingClasses = []
}) {
  // Export to Objects dialog state
  const [showExportDialog, setShowExportDialog] = useState(false);
  const [searchText, setSearchText] = useState('');
  const [matchType, setMatchType] = useState('contains'); // 'contains' | 'starts' | 'ends' | 'exact'
  const [exportClassName, setExportClassName] = useState('');
  const [useExistingClass, setUseExistingClass] = useState(false);
  const [selectedExistingClass, setSelectedExistingClass] = useState('');
  
  // Debounced search for performance
  const [debouncedSearch, setDebouncedSearch] = useState('');
  const searchTimeoutRef = useRef(null);
  
  // Update debounced search with delay
  useEffect(() => {
    if (searchTimeoutRef.current) {
      clearTimeout(searchTimeoutRef.current);
    }
    searchTimeoutRef.current = setTimeout(() => {
      setDebouncedSearch(searchText);
    }, 300);
    return () => {
      if (searchTimeoutRef.current) {
        clearTimeout(searchTimeoutRef.current);
      }
    };
  }, [searchText]);

  // Memoized matching items for export
  // Limits processing to first 5000 items for performance
  const matchingItems = useMemo(() => {
    if (!showExportDialog || !debouncedSearch.trim()) return [];
    
    const items = [];
    const maxItems = 5000;
    const itemsToProcess = ocrResults.slice(0, maxItems);
    
    for (const item of itemsToProcess) {
      if (items.length >= 1000) break; // Cap results at 1000
      
      if (matchText(item.text, debouncedSearch, matchType)) {
        items.push(item);
      }
    }
    
    return items;
  }, [showExportDialog, ocrResults, debouncedSearch, matchType]);

  const matchingCount = matchingItems.length;
  
  // Preview items (show only first 10 for performance)
  const previewItems = useMemo(() => {
    return matchingItems.slice(0, 10);
  }, [matchingItems]);

  // Reset dialog state
  const resetDialog = useCallback(() => {
    setSearchText('');
    setDebouncedSearch('');
    setMatchType('contains');
    setExportClassName('');
    setUseExistingClass(false);
    setSelectedExistingClass('');
  }, []);

  const handleExportToObjects = useCallback(() => {
    const className = useExistingClass ? selectedExistingClass : exportClassName.trim();
    if (!className || matchingItems.length === 0) return;
    
    if (onExportToObjects) {
      onExportToObjects({
        className,
        isNewClass: !useExistingClass,
        items: matchingItems
      });
    }
    
    // Reset and close
    setShowExportDialog(false);
    resetDialog();
  }, [useExistingClass, selectedExistingClass, exportClassName, matchingItems, onExportToObjects, resetDialog]);

  if (!isOpen) return null;

  return (
    <div className="smart-links-panel ocr-panel">
      <div className="panel-header">
        <h3>OCR</h3>
        <button className="close-panel" onClick={onClose}>×</button>
      </div>

      <div className="panel-content">
        {/* Display Options */}
        <div className="panel-section">
          <h4>Display Options</h4>
          
          <label className="toggle-option" style={{ marginBottom: 8 }}>
            <input
              type="checkbox"
              checked={showOcrOnPdf}
              onChange={(e) => onShowOcrOnPdfChange(e.target.checked)}
            />
            <span>Show OCR Boxes on Document</span>
          </label>
          
          <label className="toggle-option">
            <input
              type="checkbox"
              checked={includeOcrInSearch}
              onChange={(e) => onIncludeOcrInSearchChange(e.target.checked)}
            />
            <span>Include OCR in Search Results</span>
          </label>
        </div>

        {/* Run OCR Section */}
        <div className="panel-section">
          <h4>Run OCR</h4>
          
          <div className="option-group" style={{ marginBottom: 12 }}>
            <label style={{ display: 'block', marginBottom: 4, fontSize: 12, color: '#888' }}>Scope:</label>
            <select 
              value={ocrScope} 
              onChange={(e) => onOcrScopeChange(e.target.value)}
              style={{ width: '100%', padding: '8px 10px', borderRadius: 4, border: '1px solid #444', background: '#2a2a2a', color: 'white' }}
              disabled={isRunningOcr}
            >
              {numPages > 1 && (
                <option value="current">Current Page ({currentPage})</option>
              )}
              <option value="document">
                {numPages > 1 ? `All Pages (1-${numPages})` : 'Current Document'}
              </option>
              {currentFolderInfo?.folder && currentFolderInfo.folderFileCount > 1 && (
                <option value="folder">
                  {currentFolderInfo.folder.name || 'Current Folder'} ({currentFolderInfo.folderFileCount} files)
                </option>
              )}
              {projectFileCount > 1 && (
                <option value="project">
                  Whole Project ({projectFileCount} files)
                </option>
              )}
            </select>
          </div>

          {/* Warning for large scope operations */}
          {(ocrScope === 'folder' || ocrScope === 'project') && !isRunningOcr && (
            <div style={{
              background: 'rgba(255, 193, 7, 0.15)',
              border: '1px solid rgba(255, 193, 7, 0.4)',
              borderRadius: 4,
              padding: '8px 10px',
              marginBottom: 12,
              fontSize: 11,
              color: '#ffc107'
            }}>
              ⚠️ This may take a while. You can continue working while OCR runs in the background.
            </div>
          )}

          {!isRunningOcr ? (
            <button
              className="primary-btn run-ocr-btn"
              onClick={onRunOcr}
              disabled={!currentFile}
              style={{ 
                width: '100%',
                padding: '10px 16px',
                background: '#3498db',
                border: 'none',
                borderRadius: 4,
                color: 'white',
                cursor: currentFile ? 'pointer' : 'not-allowed',
                opacity: currentFile ? 1 : 0.6,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: 8
              }}
            >
              <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                <circle cx="7" cy="7" r="5" stroke="white" strokeWidth="1.5"/>
                <path d="M11 11L14 14" stroke="white" strokeWidth="1.5" strokeLinecap="round"/>
              </svg>
              Run OCR
            </button>
          ) : (
            <div style={{ display: 'flex', gap: 8 }}>
              <div style={{ 
                flex: 1,
                padding: '10px 16px',
                background: '#2a2a2a',
                border: '1px solid #444',
                borderRadius: 4,
                color: '#888',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: 8
              }}>
                <span style={{ display: 'inline-block', width: 16, height: 16 }}>⏳</span>
                Running...
              </div>
              <button
                onClick={onCancelOcr}
                style={{ 
                  padding: '10px 16px',
                  background: '#3a3a3a',
                  border: '1px solid #555',
                  borderRadius: 4,
                  color: '#ccc',
                  cursor: 'pointer'
                }}
              >
                Cancel
              </button>
            </div>
          )}
          
          {/* OCR Progress Bar */}
          {isRunningOcr && ocrProgress && (
            <div className="detection-progress" style={{ marginTop: 12 }}>
              <div className="progress-bar-container" style={{
                background: '#444',
                borderRadius: 4,
                height: 8,
                overflow: 'hidden',
                marginBottom: 6
              }}>
                <div className="progress-bar-fill" style={{
                  background: '#3498db',
                  height: '100%',
                  width: `${ocrProgress.percent || 0}%`,
                  transition: 'width 0.3s ease'
                }} />
              </div>
              <div className="progress-status" style={{ fontSize: 11, color: '#888' }}>
                {ocrProgress.status || 'Processing...'}
              </div>
            </div>
          )}

          {/* OCR Results Summary */}
          {ocrResultsCount > 0 && !isRunningOcr && (
            <div style={{ 
              marginTop: 10, 
              padding: '6px 10px', 
              background: 'rgba(39, 174, 96, 0.15)', 
              border: '1px solid rgba(39, 174, 96, 0.4)',
              borderRadius: 4,
              fontSize: 11,
              color: '#27ae60'
            }}>
              ✓ {ocrResultsCount} text items found across all processed pages
            </div>
          )}
        </div>

        {/* Export Section */}
        <div className="panel-section">
          <button
            onClick={() => setShowExportDialog(true)}
            disabled={ocrResults.length === 0}
            style={{ 
              width: '100%',
              padding: '10px 16px',
              background: ocrResults.length === 0 ? '#2a2a2a' : '#3a3a3a',
              border: '1px solid #555',
              borderRadius: 4,
              color: ocrResults.length === 0 ? '#666' : '#fff',
              cursor: ocrResults.length === 0 ? 'not-allowed' : 'pointer',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: 8
            }}
          >
            <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
              <path d="M8 1L14 4.5V11.5L8 15L2 11.5V4.5L8 1Z" stroke="currentColor" strokeWidth="1.5" strokeLinejoin="round" fill="none"/>
              <path d="M8 8V15" stroke="currentColor" strokeWidth="1.5"/>
              <path d="M8 8L14 4.5" stroke="currentColor" strokeWidth="1.5"/>
              <path d="M8 8L2 4.5" stroke="currentColor" strokeWidth="1.5"/>
            </svg>
            Export to Objects
          </button>
        </div>
      </div>

      {/* Export to Objects Dialog */}
      {showExportDialog && (
        <div className="modal-overlay" onClick={() => {
          setShowExportDialog(false);
          resetDialog();
        }}>
          <div className="modal export-ocr-modal" onClick={(e) => e.stopPropagation()} style={{
            background: '#2a2a2a',
            borderRadius: 8,
            padding: 20,
            minWidth: 400,
            maxWidth: 500,
            color: 'white'
          }}>
            <h2 style={{ marginTop: 0, marginBottom: 16, color: '#fff', fontWeight: 'bold' }}>Export to Objects</h2>
            
            {/* Search Section */}
            <div style={{ marginBottom: 16 }}>
              <label style={{ display: 'block', marginBottom: 8, fontWeight: 'bold', color: '#ccc' }}>
                Find Text:
              </label>
              
              <div style={{ display: 'flex', gap: 8, marginBottom: 8 }}>
                <input
                  type="text"
                  value={searchText}
                  onChange={(e) => setSearchText(e.target.value)}
                  placeholder="Enter text to search..."
                  autoFocus
                  style={{
                    flex: 1,
                    padding: '8px 12px',
                    background: '#1a1a1a',
                    border: '1px solid #444',
                    borderRadius: 4,
                    color: 'white'
                  }}
                />
                <select
                  value={matchType}
                  onChange={(e) => setMatchType(e.target.value)}
                  style={{
                    padding: '8px 12px',
                    background: '#1a1a1a',
                    border: '1px solid #444',
                    borderRadius: 4,
                    color: 'white',
                    minWidth: 120
                  }}
                >
                  <option value="contains">Contains</option>
                  <option value="starts">Starts with</option>
                  <option value="ends">Ends with</option>
                  <option value="exact">Exact match</option>
                </select>
              </div>
            </div>

            {/* Matching Preview */}
            <div style={{
              background: '#1a1a1a',
              borderRadius: 4,
              padding: 12,
              marginBottom: 16,
              maxHeight: 150,
              overflowY: 'auto'
            }}>
              <div style={{ fontSize: 12, color: '#888', marginBottom: 8 }}>
                Matching: <strong style={{ color: matchingCount > 0 ? '#27ae60' : '#e74c3c' }}>{matchingCount}{matchingCount >= 1000 ? '+' : ''}</strong> items
                {debouncedSearch !== searchText && (
                  <span style={{ marginLeft: 8, fontSize: 10, color: '#666' }}>searching...</span>
                )}
              </div>
              {matchingCount > 0 && (
                <div style={{ fontSize: 11, color: '#aaa' }}>
                  {previewItems.map((item, i) => (
                    <div key={i} style={{ padding: '2px 0' }}>
                      • <span style={{ color: '#27ae60' }}>{item.text}</span>
                      <span style={{ color: '#666' }}> P{item.page}</span>
                    </div>
                  ))}
                  {matchingCount > 10 && (
                    <div style={{ color: '#666', fontStyle: 'italic' }}>
                      ...and {matchingCount - 10} more
                    </div>
                  )}
                </div>
              )}
              {searchText && matchingCount === 0 && debouncedSearch === searchText && (
                <div style={{ fontSize: 11, color: '#888' }}>No matches found</div>
              )}
            </div>

            {/* Class Selection */}
            <div style={{ marginBottom: 16 }}>
              <label style={{ display: 'block', marginBottom: 8, fontWeight: 'bold', color: '#ccc' }}>
                Assign to Class:
              </label>
              
              {existingClasses.length > 0 && (
                <div style={{ marginBottom: 12 }}>
                  <label style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8, cursor: 'pointer' }}>
                    <input
                      type="radio"
                      checked={!useExistingClass}
                      onChange={() => setUseExistingClass(false)}
                    />
                    <span>Create new class</span>
                  </label>
                  <label style={{ display: 'flex', alignItems: 'center', gap: 8, cursor: 'pointer' }}>
                    <input
                      type="radio"
                      checked={useExistingClass}
                      onChange={() => setUseExistingClass(true)}
                    />
                    <span>Use existing class</span>
                  </label>
                </div>
              )}

              {!useExistingClass ? (
                <input
                  type="text"
                  value={exportClassName}
                  onChange={(e) => setExportClassName(e.target.value)}
                  placeholder="Enter new class name (e.g., Pipe Tags)"
                  style={{
                    width: '100%',
                    padding: '8px 12px',
                    background: '#1a1a1a',
                    border: '1px solid #444',
                    borderRadius: 4,
                    color: 'white',
                    boxSizing: 'border-box'
                  }}
                />
              ) : (
                <select
                  value={selectedExistingClass}
                  onChange={(e) => setSelectedExistingClass(e.target.value)}
                  style={{
                    width: '100%',
                    padding: '8px 12px',
                    background: '#1a1a1a',
                    border: '1px solid #444',
                    borderRadius: 4,
                    color: 'white'
                  }}
                >
                  <option value="">-- Select class --</option>
                  {existingClasses.map(cls => (
                    <option key={cls.id || cls.name} value={cls.name}>{cls.name}</option>
                  ))}
                </select>
              )}
            </div>

            {/* Buttons */}
            <div style={{ display: 'flex', gap: 12, justifyContent: 'flex-end' }}>
              <button
                onClick={() => {
                  setShowExportDialog(false);
                  resetDialog();
                }}
                style={{
                  background: '#444',
                  border: 'none',
                  borderRadius: 4,
                  color: 'white',
                  padding: '10px 20px',
                  cursor: 'pointer'
                }}
              >
                Cancel
              </button>
              <button
                onClick={handleExportToObjects}
                disabled={matchingCount === 0 || (!useExistingClass && !exportClassName.trim()) || (useExistingClass && !selectedExistingClass)}
                style={{
                  background: matchingCount > 0 && ((!useExistingClass && exportClassName.trim()) || (useExistingClass && selectedExistingClass)) ? '#27ae60' : '#555',
                  border: 'none',
                  borderRadius: 4,
                  color: 'white',
                  padding: '10px 20px',
                  cursor: matchingCount > 0 ? 'pointer' : 'not-allowed',
                  opacity: matchingCount > 0 && ((!useExistingClass && exportClassName.trim()) || (useExistingClass && selectedExistingClass)) ? 1 : 0.6
                }}
              >
                Export {matchingCount} Objects
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
