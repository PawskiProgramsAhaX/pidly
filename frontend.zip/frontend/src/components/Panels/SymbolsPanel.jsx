/**
 * SymbolsPanel.jsx
 * 
 * Panel for managing reusable symbols:
 * - Create from selected markups (drawn/vector symbols)
 * - Capture from PDF region (bitmap symbols with cleanup editor)
 * - Search, drag & drop onto PDF
 */

import { useState, useRef, useEffect, useCallback } from 'react';

export default function SymbolsPanel({
  isOpen,
  onClose,
  // Creation mode (drawn symbols)
  symbolCreationMode,
  onSetSymbolCreationMode,
  selectedMarkups,
  selectedMarkup,
  onClearSelections,
  onOpenSaveDialog,
  // Edit mode check
  markupEditMode,
  onEnterCreationMode,
  // Capture mode (bitmap symbols)
  captureMode,
  onSetCaptureMode,
  selectedRegion,
  onClearRegion,
  pdfDoc,
  currentPage,
  // Symbols list
  savedSymbols,
  setSavedSymbols,
  symbolSearchQuery,
  onSearchQueryChange,
  symbolsViewMode,
  onViewModeChange,
  onDeleteSymbol,
  // Drag state
  onDragStart,
  onDragEnd,
  // For drag image sizing
  canvasSize,
  scale
}) {
  // Cleanup editor state
  const [isEditingSymbol, setIsEditingSymbol] = useState(false);
  const [capturedImage, setCapturedImage] = useState(null);
  const [editTool, setEditTool] = useState('eraser');
  const [editBrushSize, setEditBrushSize] = useState(10);
  const [symbolColor, setSymbolColor] = useState('#000000');
  const [symbolName, setSymbolName] = useState('');
  const [isDrawingOnEdit, setIsDrawingOnEdit] = useState(false);
  const editCanvasRef = useRef(null);

  // Initialize edit canvas when captured image changes
  useEffect(() => {
    if (capturedImage && editCanvasRef.current) {
      const ctx = editCanvasRef.current.getContext('2d');
      ctx.drawImage(capturedImage.canvas, 0, 0);
    }
  }, [capturedImage]);

  // Capture region from PDF as bitmap
  const captureRegion = useCallback(async () => {
    if (!selectedRegion || !pdfDoc) return;
    
    try {
      const extractionScale = 3; // High res capture
      const page = await pdfDoc.getPage(currentPage);
      const viewport = page.getViewport({ scale: extractionScale });
      
      const regionWidth = Math.round(selectedRegion.width * viewport.width);
      const regionHeight = Math.round(selectedRegion.height * viewport.height);
      const regionX = Math.round(selectedRegion.x * viewport.width);
      const regionY = Math.round(selectedRegion.y * viewport.height);
      
      // Render full page at high res
      const tempCanvas = document.createElement('canvas');
      tempCanvas.width = viewport.width;
      tempCanvas.height = viewport.height;
      const tempCtx = tempCanvas.getContext('2d');
      
      await page.render({
        canvasContext: tempCtx,
        viewport: viewport
      }).promise;
      
      // Extract region
      const regionCanvas = document.createElement('canvas');
      regionCanvas.width = regionWidth;
      regionCanvas.height = regionHeight;
      const regionCtx = regionCanvas.getContext('2d');
      
      regionCtx.drawImage(
        tempCanvas,
        regionX, regionY, regionWidth, regionHeight,
        0, 0, regionWidth, regionHeight
      );
      
      // Store for editing
      setCapturedImage({
        canvas: regionCanvas,
        width: regionWidth,
        height: regionHeight,
        originalData: regionCtx.getImageData(0, 0, regionWidth, regionHeight),
        normalizedWidth: selectedRegion.width,
        normalizedHeight: selectedRegion.height,
      });
      setIsEditingSymbol(true);
      
    } catch (error) {
      console.error('Error capturing region:', error);
      alert('Failed to capture region: ' + error.message);
    }
  }, [selectedRegion, pdfDoc, currentPage]);

  // Handle drawing on edit canvas (erase/fill)
  const handleEditCanvasMouseDown = (e) => {
    if (!editCanvasRef.current || !capturedImage) return;
    setIsDrawingOnEdit(true);
    handleEditCanvasDraw(e);
  };

  const handleEditCanvasMouseMove = (e) => {
    if (!isDrawingOnEdit || !editCanvasRef.current) return;
    handleEditCanvasDraw(e);
  };

  const handleEditCanvasMouseUp = () => {
    setIsDrawingOnEdit(false);
  };

  const handleEditCanvasDraw = (e) => {
    if (!editCanvasRef.current || !capturedImage) return;
    
    const canvas = editCanvasRef.current;
    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;
    const x = (e.clientX - rect.left) * scaleX;
    const y = (e.clientY - rect.top) * scaleY;
    
    const ctx = canvas.getContext('2d');
    
    if (editTool === 'eraser') {
      ctx.save();
      ctx.globalCompositeOperation = 'destination-out';
      ctx.beginPath();
      ctx.arc(x, y, editBrushSize, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    } else if (editTool === 'fill') {
      ctx.fillStyle = '#FFFFFF';
      ctx.beginPath();
      ctx.arc(x, y, editBrushSize, 0, Math.PI * 2);
      ctx.fill();
    }
  };

  // Remove white/light background (make transparent)
  const removeBackground = useCallback((tolerance = 240) => {
    if (!editCanvasRef.current) return;
    
    const canvas = editCanvasRef.current;
    const ctx = canvas.getContext('2d');
    const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    const data = imageData.data;
    
    for (let i = 0; i < data.length; i += 4) {
      const r = data[i];
      const g = data[i + 1];
      const b = data[i + 2];
      
      if (r > tolerance && g > tolerance && b > tolerance) {
        data[i + 3] = 0;
      }
    }
    
    ctx.putImageData(imageData, 0, 0);
  }, []);

  // Remove color noise (keep only dark pixels)
  const removeNoise = useCallback((threshold = 200) => {
    if (!editCanvasRef.current) return;
    
    const canvas = editCanvasRef.current;
    const ctx = canvas.getContext('2d');
    const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    const data = imageData.data;
    
    for (let i = 0; i < data.length; i += 4) {
      const r = data[i];
      const g = data[i + 1];
      const b = data[i + 2];
      const gray = (r + g + b) / 3;
      
      if (gray > threshold) {
        data[i + 3] = 0;
      } else {
        data[i] = 0;
        data[i + 1] = 0;
        data[i + 2] = 0;
        data[i + 3] = 255;
      }
    }
    
    ctx.putImageData(imageData, 0, 0);
  }, []);

  // Remove small specks
  const removeSpecks = useCallback((minSize = 30) => {
    if (!editCanvasRef.current) return;
    
    const canvas = editCanvasRef.current;
    const ctx = canvas.getContext('2d');
    const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    const { data, width, height } = imageData;
    
    const mask = new Uint8Array(width * height);
    for (let i = 0; i < width * height; i++) {
      const alpha = data[i * 4 + 3];
      const gray = (data[i * 4] + data[i * 4 + 1] + data[i * 4 + 2]) / 3;
      mask[i] = (alpha > 128 && gray < 200) ? 1 : 0;
    }
    
    const labels = new Int32Array(width * height);
    const sizes = new Map();
    let labelCount = 0;
    
    const floodFill = (startX, startY, label) => {
      const stack = [[startX, startY]];
      let size = 0;
      
      while (stack.length > 0) {
        const [x, y] = stack.pop();
        if (x < 0 || x >= width || y < 0 || y >= height) continue;
        
        const idx = y * width + x;
        if (mask[idx] === 0 || labels[idx] !== 0) continue;
        
        labels[idx] = label;
        size++;
        
        stack.push([x + 1, y], [x - 1, y], [x, y + 1], [x, y - 1]);
      }
      return size;
    };
    
    for (let y = 0; y < height; y++) {
      for (let x = 0; x < width; x++) {
        const idx = y * width + x;
        if (mask[idx] === 1 && labels[idx] === 0) {
          labelCount++;
          const size = floodFill(x, y, labelCount);
          sizes.set(labelCount, size);
        }
      }
    }
    
    for (let i = 0; i < width * height; i++) {
      const label = labels[i];
      if (label > 0 && sizes.get(label) < minSize) {
        data[i * 4 + 3] = 0;
      }
    }
    
    ctx.putImageData(imageData, 0, 0);
  }, []);

  // Recolor symbol
  const recolorSymbol = useCallback((newColor) => {
    if (!editCanvasRef.current) return;
    
    const canvas = editCanvasRef.current;
    const ctx = canvas.getContext('2d');
    const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    const data = imageData.data;
    
    const hex = newColor.replace('#', '');
    const r = parseInt(hex.substring(0, 2), 16);
    const g = parseInt(hex.substring(2, 4), 16);
    const b = parseInt(hex.substring(4, 6), 16);
    
    for (let i = 0; i < data.length; i += 4) {
      const alpha = data[i + 3];
      const origR = data[i];
      const origG = data[i + 1];
      const origB = data[i + 2];
      const gray = (origR + origG + origB) / 3;
      
      if (alpha > 10 && gray < 200) {
        const darkness = 1 - (gray / 200);
        data[i] = r;
        data[i + 1] = g;
        data[i + 2] = b;
        data[i + 3] = Math.min(255, Math.round(255 * darkness));
      } else if (alpha > 10 && gray >= 200) {
        data[i + 3] = 0;
      }
    }
    
    ctx.putImageData(imageData, 0, 0);
  }, []);

  // Invert colors
  const invertColors = useCallback(() => {
    if (!editCanvasRef.current) return;
    
    const canvas = editCanvasRef.current;
    const ctx = canvas.getContext('2d');
    const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    const data = imageData.data;
    
    for (let i = 0; i < data.length; i += 4) {
      if (data[i + 3] > 0) {
        data[i] = 255 - data[i];
        data[i + 1] = 255 - data[i + 1];
        data[i + 2] = 255 - data[i + 2];
      }
    }
    
    ctx.putImageData(imageData, 0, 0);
  }, []);

  // Trim transparent edges
  const trimTransparent = useCallback(() => {
    if (!editCanvasRef.current || !capturedImage) return;
    
    const canvas = editCanvasRef.current;
    const ctx = canvas.getContext('2d');
    const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    const data = imageData.data;
    const w = canvas.width;
    const h = canvas.height;
    
    let minX = w, minY = h, maxX = 0, maxY = 0;
    
    for (let y = 0; y < h; y++) {
      for (let x = 0; x < w; x++) {
        const alpha = data[(y * w + x) * 4 + 3];
        if (alpha > 0) {
          minX = Math.min(minX, x);
          minY = Math.min(minY, y);
          maxX = Math.max(maxX, x);
          maxY = Math.max(maxY, y);
        }
      }
    }
    
    if (maxX < minX) return;
    
    const trimW = maxX - minX + 1;
    const trimH = maxY - minY + 1;
    const trimmedData = ctx.getImageData(minX, minY, trimW, trimH);
    
    const widthRatio = trimW / w;
    const heightRatio = trimH / h;
    
    canvas.width = trimW;
    canvas.height = trimH;
    ctx.putImageData(trimmedData, 0, 0);
    
    setCapturedImage(prev => ({
      ...prev,
      width: trimW,
      height: trimH,
      normalizedWidth: (prev.normalizedWidth || 0.1) * widthRatio,
      normalizedHeight: (prev.normalizedHeight || 0.1) * heightRatio,
    }));
  }, [capturedImage]);

  // Reset to original
  const resetToOriginal = useCallback(() => {
    if (!editCanvasRef.current || !capturedImage) return;
    
    const ctx = editCanvasRef.current.getContext('2d');
    editCanvasRef.current.width = capturedImage.originalData.width;
    editCanvasRef.current.height = capturedImage.originalData.height;
    ctx.putImageData(capturedImage.originalData, 0, 0);
  }, [capturedImage]);

  // Save edited symbol
  const saveEditedSymbol = useCallback(() => {
    if (!editCanvasRef.current) return;
    
    const canvas = editCanvasRef.current;
    const dataUrl = canvas.toDataURL('image/png');
    
    const newSymbol = {
      id: `symbol_${Date.now()}`,
      name: symbolName || `Captured Symbol ${savedSymbols.filter(s => s.type === 'image').length + 1}`,
      type: 'image',
      image: dataUrl,
      preview: dataUrl,
      width: canvas.width,
      height: canvas.height,
      originalWidth: capturedImage?.normalizedWidth || 0.1,
      originalHeight: capturedImage?.normalizedHeight || 0.1,
      aspectRatio: canvas.width / canvas.height,
      createdAt: new Date().toISOString()
    };
    
    const newSymbols = [...savedSymbols, newSymbol];
    setSavedSymbols(newSymbols);
    localStorage.setItem('pdfMarkupSymbols', JSON.stringify(newSymbols));
    
    // Reset state
    setCapturedImage(null);
    setIsEditingSymbol(false);
    setSymbolName('');
    onSetCaptureMode(false);
    onClearRegion();
  }, [symbolName, savedSymbols, setSavedSymbols, capturedImage, onSetCaptureMode, onClearRegion]);

  // Cancel editing
  const cancelEditing = useCallback(() => {
    setCapturedImage(null);
    setIsEditingSymbol(false);
    setSymbolName('');
  }, []);

  if (!isOpen) return null;

  const filteredSymbols = savedSymbols.filter(s => 
    !symbolSearchQuery || s.name.toLowerCase().includes(symbolSearchQuery.toLowerCase())
  );

  const hasSelection = selectedMarkups.length > 0 || selectedMarkup;
  const selectionCount = selectedMarkups.length > 0 ? selectedMarkups.length : (selectedMarkup ? 1 : 0);

  // Separate symbols by type
  const drawnSymbols = filteredSymbols.filter(s => s.type !== 'image');
  const capturedSymbols = filteredSymbols.filter(s => s.type === 'image');

  return (
    <>
      <div className="smart-links-panel" style={{ width: '320px', minWidth: '320px', display: 'flex', flexDirection: 'column' }}>
        <div className="panel-header">
          <h3>Symbols</h3>
          <button className="close-panel" onClick={onClose}>×</button>
        </div>
        <div className="panel-content" style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden', padding: '8px 12px' }}>
          
          {/* Symbol creation buttons - when not in any mode */}
          {!symbolCreationMode && !captureMode && (
            <div style={{ display: 'flex', gap: '6px', marginBottom: '10px', flexShrink: 0 }}>
              <button
                onClick={() => {
                  if (!markupEditMode) {
                    alert('Please unlock the document first to create symbols.');
                    return;
                  }
                  onEnterCreationMode();
                }}
                style={{
                  flex: 1,
                  padding: '8px 10px',
                  background: markupEditMode ? '#333' : '#ccc',
                  color: 'white',
                  border: 'none',
                  borderRadius: '4px',
                  fontSize: '11px',
                  fontWeight: '500',
                  cursor: markupEditMode ? 'pointer' : 'not-allowed',
                }}
                title={markupEditMode ? "Create symbol from selected markups" : "Unlock document first"}
              >
                ✏️ From Selection
              </button>
              <button
                onClick={() => {
                  if (!markupEditMode) {
                    alert('Please unlock the document first to capture symbols.');
                    return;
                  }
                  onSetCaptureMode(true);
                }}
                style={{
                  flex: 1,
                  padding: '8px 10px',
                  background: markupEditMode ? '#2980b9' : '#ccc',
                  color: 'white',
                  border: 'none',
                  borderRadius: '4px',
                  fontSize: '11px',
                  fontWeight: '500',
                  cursor: markupEditMode ? 'pointer' : 'not-allowed',
                }}
                title={markupEditMode ? "Capture region from PDF as image" : "Unlock document first"}
              >
                📷 Capture Region
              </button>
            </div>
          )}

          {/* Drawn symbol creation mode UI */}
          {symbolCreationMode && (
            <div style={{
              padding: '10px',
              background: '#f5f5f5',
              borderRadius: '4px',
              marginBottom: '8px',
              border: '1px dashed #666',
              flexShrink: 0
            }}>
              <p style={{ fontSize: '11px', color: '#666', margin: '0 0 8px 0' }}>
                Select markups on the PDF to include in your symbol.
              </p>
              {hasSelection && (
                <p style={{ fontSize: '12px', color: '#333', fontWeight: '500', margin: '0 0 8px 0' }}>
                  {selectionCount} markup{selectionCount > 1 ? 's' : ''} selected
                </p>
              )}
              <div style={{ display: 'flex', gap: '6px' }}>
                <button
                  onClick={() => {
                    if (hasSelection) {
                      onOpenSaveDialog();
                    }
                  }}
                  disabled={!hasSelection}
                  style={{
                    flex: 1,
                    padding: '6px 10px',
                    background: hasSelection ? '#27ae60' : '#ccc',
                    color: 'white',
                    border: 'none',
                    borderRadius: '4px',
                    fontSize: '11px',
                    fontWeight: '500',
                    cursor: hasSelection ? 'pointer' : 'not-allowed'
                  }}
                >
                  ✓ Save Symbol
                </button>
                <button
                  onClick={() => {
                    onSetSymbolCreationMode(false);
                    onClearSelections();
                  }}
                  style={{
                    padding: '6px 10px',
                    background: '#e74c3c',
                    color: 'white',
                    border: 'none',
                    borderRadius: '4px',
                    fontSize: '11px',
                    fontWeight: '500',
                    cursor: 'pointer'
                  }}
                >
                  ✕ Cancel
                </button>
              </div>
            </div>
          )}

          {/* Capture mode UI */}
          {captureMode && !isEditingSymbol && (
            <div style={{
              padding: '10px',
              background: '#e8f4fc',
              borderRadius: '4px',
              marginBottom: '8px',
              border: '1px dashed #2980b9',
              flexShrink: 0
            }}>
              <p style={{ fontSize: '11px', color: '#2980b9', margin: '0 0 8px 0' }}>
                Draw a rectangle on the PDF to capture a region.
              </p>
              {selectedRegion && (
                <p style={{ fontSize: '12px', color: '#333', fontWeight: '500', margin: '0 0 8px 0' }}>
                  Region selected ✓
                </p>
              )}
              <div style={{ display: 'flex', gap: '6px' }}>
                <button
                  onClick={captureRegion}
                  disabled={!selectedRegion}
                  style={{
                    flex: 1,
                    padding: '6px 10px',
                    background: selectedRegion ? '#2980b9' : '#ccc',
                    color: 'white',
                    border: 'none',
                    borderRadius: '4px',
                    fontSize: '11px',
                    fontWeight: '500',
                    cursor: selectedRegion ? 'pointer' : 'not-allowed'
                  }}
                >
                  📷 Capture
                </button>
                <button
                  onClick={() => {
                    onSetCaptureMode(false);
                    onClearRegion();
                  }}
                  style={{
                    padding: '6px 10px',
                    background: '#e74c3c',
                    color: 'white',
                    border: 'none',
                    borderRadius: '4px',
                    fontSize: '11px',
                    fontWeight: '500',
                    cursor: 'pointer'
                  }}
                >
                  ✕ Cancel
                </button>
              </div>
            </div>
          )}
          
          {savedSymbols.length === 0 && !symbolCreationMode && !captureMode ? (
            <p style={{ fontSize: '11px', color: '#888', margin: '8px 0', textAlign: 'center' }}>
              No symbols yet. Use the buttons above to create one.
            </p>
          ) : savedSymbols.length > 0 && (
            <>
              {/* Search bar with view toggle */}
              <div style={{ display: 'flex', gap: '6px', marginBottom: '6px', flexShrink: 0 }}>
                <input
                  type="text"
                  placeholder="Search..."
                  value={symbolSearchQuery}
                  onChange={(e) => onSearchQueryChange(e.target.value)}
                  style={{
                    flex: 1,
                    padding: '5px 8px',
                    border: '1px solid #ddd',
                    borderRadius: '3px',
                    fontSize: '11px',
                    boxSizing: 'border-box'
                  }}
                />
                <div style={{ display: 'flex', border: '1px solid #ddd', borderRadius: '3px', overflow: 'hidden' }}>
                  <button
                    onClick={() => {
                      onViewModeChange('grid');
                      localStorage.setItem('symbols_view_mode', 'grid');
                    }}
                    style={{
                      padding: '4px 8px',
                      background: symbolsViewMode === 'grid' ? '#333' : '#fff',
                      color: symbolsViewMode === 'grid' ? '#fff' : '#666',
                      border: 'none',
                      cursor: 'pointer',
                      fontSize: '11px'
                    }}
                    title="Grid view"
                  >
                    ⊞
                  </button>
                  <button
                    onClick={() => {
                      onViewModeChange('list');
                      localStorage.setItem('symbols_view_mode', 'list');
                    }}
                    style={{
                      padding: '4px 8px',
                      background: symbolsViewMode === 'list' ? '#333' : '#fff',
                      color: symbolsViewMode === 'list' ? '#fff' : '#666',
                      border: 'none',
                      borderLeft: '1px solid #ddd',
                      cursor: 'pointer',
                      fontSize: '11px'
                    }}
                    title="List view"
                  >
                    ☰
                  </button>
                </div>
              </div>
              
              {/* Symbols container */}
              <div className="symbols-list" style={{ 
                flex: 1,
                minHeight: '100px',
                overflowY: 'auto',
                overflowX: 'hidden',
                display: symbolsViewMode === 'grid' ? 'grid' : 'flex',
                gridTemplateColumns: symbolsViewMode === 'grid' ? 'repeat(3, 1fr)' : undefined,
                flexDirection: symbolsViewMode === 'list' ? 'column' : undefined,
                gap: symbolsViewMode === 'grid' ? '4px' : '2px',
                padding: '2px',
                alignContent: 'start'
              }}>
                {filteredSymbols.map(symbol => (
                  <div 
                    key={symbol.id}
                    className="symbol-item"
                    draggable
                    onDragStart={(e) => {
                      e.dataTransfer.setData('application/json', JSON.stringify(symbol));
                      onDragStart(symbol);
                      
                      // Create custom drag image
                      if (canvasSize.width && canvasSize.height) {
                        const width = (symbol.originalWidth || 0.1) * canvasSize.width * scale;
                        const height = (symbol.originalHeight || 0.1) * canvasSize.height * scale;
                        
                        const dragImg = document.createElement('div');
                        dragImg.style.cssText = `
                          position: fixed;
                          top: -10000px;
                          left: -10000px;
                          width: ${width}px;
                          height: ${height}px;
                          pointer-events: none;
                        `;
                        
                        if (symbol.type === 'image' && symbol.image) {
                          dragImg.innerHTML = `<img src="${symbol.image}" style="width:100%;height:100%;object-fit:contain" />`;
                        } else if (symbol.preview) {
                          dragImg.innerHTML = symbol.preview.replace(
                            /<svg/,
                            `<svg style="width:${width}px;height:${height}px"`
                          );
                        }
                        document.body.appendChild(dragImg);
                        
                        e.dataTransfer.setDragImage(dragImg, width / 2, height / 2);
                        
                        setTimeout(() => document.body.removeChild(dragImg), 0);
                      }
                    }}
                    onDragEnd={() => onDragEnd()}
                    style={symbolsViewMode === 'grid' ? {
                      display: 'flex',
                      flexDirection: 'column',
                      padding: '3px',
                      background: symbol.type === 'image' ? '#f0f8ff' : '#f8f8f8',
                      borderRadius: '4px',
                      cursor: 'grab',
                      border: `1px solid ${symbol.type === 'image' ? '#b8d4e8' : '#e0e0e0'}`,
                      transition: 'all 0.1s'
                    } : {
                      display: 'flex',
                      flexDirection: 'row',
                      alignItems: 'center',
                      padding: '4px 6px',
                      background: symbol.type === 'image' ? '#f0f8ff' : '#f8f8f8',
                      borderRadius: '4px',
                      cursor: 'grab',
                      border: `1px solid ${symbol.type === 'image' ? '#b8d4e8' : '#e0e0e0'}`,
                      transition: 'all 0.1s',
                      gap: '8px'
                    }}
                    onMouseEnter={(e) => { e.currentTarget.style.background = symbol.type === 'image' ? '#e0f0ff' : '#f0f0f0'; e.currentTarget.style.borderColor = '#ccc'; }}
                    onMouseLeave={(e) => { e.currentTarget.style.background = symbol.type === 'image' ? '#f0f8ff' : '#f8f8f8'; e.currentTarget.style.borderColor = symbol.type === 'image' ? '#b8d4e8' : '#e0e0e0'; }}
                  >
                    {/* Preview */}
                    {symbolsViewMode === 'grid' ? (
                      <div style={{
                        width: '100%',
                        paddingBottom: '100%',
                        position: 'relative',
                        background: 'white',
                        borderRadius: '2px',
                        marginBottom: '2px',
                        overflow: 'hidden'
                      }}>
                        <div style={{
                          position: 'absolute',
                          top: '2px',
                          left: '2px',
                          right: '2px',
                          bottom: '2px',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          backgroundImage: symbol.type === 'image' ? 
                            'linear-gradient(45deg, #f0f0f0 25%, transparent 25%), linear-gradient(-45deg, #f0f0f0 25%, transparent 25%), linear-gradient(45deg, transparent 75%, #f0f0f0 75%), linear-gradient(-45deg, transparent 75%, #f0f0f0 75%)' : 
                            'none',
                          backgroundSize: '8px 8px',
                          backgroundPosition: '0 0, 0 4px, 4px -4px, -4px 0px'
                        }}>
                          {symbol.type === 'image' && symbol.image ? (
                            <img 
                              src={symbol.image} 
                              alt={symbol.name}
                              style={{ maxWidth: '100%', maxHeight: '100%', objectFit: 'contain' }}
                            />
                          ) : symbol.preview ? (
                            <div 
                              dangerouslySetInnerHTML={{ __html: symbol.preview.replace(/<svg/, '<svg style="width:100%;height:100%"') }}
                              style={{ width: '100%', height: '100%' }}
                            />
                          ) : (
                            <span style={{ fontSize: '16px' }}>📌</span>
                          )}
                        </div>
                        {/* Type indicator badge */}
                        <div style={{
                          position: 'absolute',
                          top: '2px',
                          right: '2px',
                          fontSize: '8px',
                          background: symbol.type === 'image' ? '#2980b9' : '#27ae60',
                          color: 'white',
                          padding: '1px 3px',
                          borderRadius: '2px',
                          opacity: 0.8
                        }}>
                          {symbol.type === 'image' ? '📷' : '✏️'}
                        </div>
                      </div>
                    ) : (
                      <div style={{
                        width: '32px',
                        height: '32px',
                        flexShrink: 0,
                        background: 'white',
                        borderRadius: '3px',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        overflow: 'hidden',
                        position: 'relative',
                        backgroundImage: symbol.type === 'image' ? 
                          'linear-gradient(45deg, #f0f0f0 25%, transparent 25%), linear-gradient(-45deg, #f0f0f0 25%, transparent 25%), linear-gradient(45deg, transparent 75%, #f0f0f0 75%), linear-gradient(-45deg, transparent 75%, #f0f0f0 75%)' : 
                          'none',
                        backgroundSize: '6px 6px',
                        backgroundPosition: '0 0, 0 3px, 3px -3px, -3px 0px'
                      }}>
                        {symbol.type === 'image' && symbol.image ? (
                          <img 
                            src={symbol.image} 
                            alt={symbol.name}
                            style={{ maxWidth: '100%', maxHeight: '100%', objectFit: 'contain' }}
                          />
                        ) : symbol.preview ? (
                          <div 
                            dangerouslySetInnerHTML={{ __html: symbol.preview.replace(/<svg/, '<svg style="width:100%;height:100%"') }}
                            style={{ width: '100%', height: '100%' }}
                          />
                        ) : (
                          <span style={{ fontSize: '14px' }}>📌</span>
                        )}
                      </div>
                    )}
                    
                    {/* Title and delete row */}
                    <div style={{ 
                      display: 'flex', 
                      alignItems: 'center', 
                      justifyContent: 'space-between',
                      gap: '4px',
                      minWidth: 0,
                      flex: symbolsViewMode === 'list' ? 1 : undefined
                    }}>
                      <span style={{ 
                        fontSize: symbolsViewMode === 'grid' ? '9px' : '12px', 
                        fontWeight: '500',
                        overflow: 'hidden',
                        textOverflow: 'ellipsis',
                        whiteSpace: 'nowrap',
                        flex: 1,
                        minWidth: 0,
                        color: '#555'
                      }} title={symbol.name}>
                        {symbol.name}
                      </span>
                      {symbolsViewMode === 'list' && (
                        <span style={{
                          fontSize: '9px',
                          background: symbol.type === 'image' ? '#2980b9' : '#27ae60',
                          color: 'white',
                          padding: '1px 4px',
                          borderRadius: '2px',
                          marginRight: '4px'
                        }}>
                          {symbol.type === 'image' ? 'IMG' : 'VEC'}
                        </span>
                      )}
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          e.preventDefault();
                          if (window.confirm(`Delete "${symbol.name}"?`)) {
                            onDeleteSymbol(symbol.id);
                          }
                        }}
                        onMouseDown={(e) => e.stopPropagation()}
                        style={{
                          background: 'none',
                          border: 'none',
                          cursor: 'pointer',
                          fontSize: symbolsViewMode === 'grid' ? '9px' : '12px',
                          padding: '2px 4px',
                          opacity: 0.4,
                          flexShrink: 0,
                          borderRadius: '2px',
                          lineHeight: 1
                        }}
                        onMouseEnter={(e) => { e.target.style.opacity = '1'; e.target.style.background = '#ffebee'; }}
                        onMouseLeave={(e) => { e.target.style.opacity = '0.4'; e.target.style.background = 'none'; }}
                        title="Delete"
                      >
                        ✕
                      </button>
                    </div>
                  </div>
                ))}
                {savedSymbols.length > 0 && symbolSearchQuery && filteredSymbols.length === 0 && (
                  <div style={{ gridColumn: '1 / -1', textAlign: 'center', padding: '8px', color: '#888', fontSize: '10px' }}>
                    No matches
                  </div>
                )}
              </div>
              
              <p style={{ fontSize: '9px', color: '#aaa', marginTop: '4px', fontStyle: 'italic', flexShrink: 0, textAlign: 'center' }}>
                Drag onto PDF to place • 📷 = Captured • ✏️ = Drawn
              </p>
            </>
          )}
        </div>
      </div>

      {/* Cleanup Editor Modal */}
      {isEditingSymbol && capturedImage && (
        <div 
          style={{
            position: 'fixed',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            background: 'rgba(0, 0, 0, 0.8)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            zIndex: 10000,
            padding: '20px'
          }}
          onClick={cancelEditing}
        >
          <div 
            style={{
              background: '#1e1e1e',
              borderRadius: '12px',
              width: '90%',
              maxWidth: '900px',
              maxHeight: '90vh',
              display: 'flex',
              flexDirection: 'column',
              boxShadow: '0 20px 60px rgba(0, 0, 0, 0.5)',
              border: '1px solid #333'
            }}
            onClick={(e) => e.stopPropagation()}
          >
            {/* Modal Header */}
            <div style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              padding: '16px 20px',
              borderBottom: '1px solid #333'
            }}>
              <h3 style={{ margin: 0, color: '#fff', fontSize: '18px' }}>Edit Captured Symbol</h3>
              <button 
                onClick={cancelEditing}
                style={{
                  background: 'none',
                  border: 'none',
                  color: '#888',
                  fontSize: '28px',
                  cursor: 'pointer',
                  padding: 0,
                  lineHeight: 1
                }}
              >
                ×
              </button>
            </div>
            
            {/* Modal Body */}
            <div style={{
              display: 'flex',
              flex: 1,
              overflow: 'hidden',
              padding: '20px',
              gap: '20px'
            }}>
              {/* Canvas */}
              <div style={{
                flex: 1,
                background: '#fff',
                border: '2px solid #444',
                borderRadius: '8px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                overflow: 'auto',
                minHeight: '300px',
                backgroundImage: 'linear-gradient(45deg, #ddd 25%, transparent 25%), linear-gradient(-45deg, #ddd 25%, transparent 25%), linear-gradient(45deg, transparent 75%, #ddd 75%), linear-gradient(-45deg, transparent 75%, #ddd 75%)',
                backgroundSize: '20px 20px',
                backgroundPosition: '0 0, 0 10px, 10px -10px, -10px 0px'
              }}>
                <canvas 
                  ref={editCanvasRef}
                  width={capturedImage.width}
                  height={capturedImage.height}
                  style={{ maxWidth: '100%', maxHeight: '100%', cursor: (editTool === 'eraser' || editTool === 'fill') ? 'crosshair' : 'default' }}
                  onMouseDown={handleEditCanvasMouseDown}
                  onMouseMove={handleEditCanvasMouseMove}
                  onMouseUp={handleEditCanvasMouseUp}
                  onMouseLeave={handleEditCanvasMouseUp}
                />
              </div>
              
              {/* Tools Panel */}
              <div style={{
                width: '260px',
                flexShrink: 0,
                display: 'flex',
                flexDirection: 'column',
                gap: '12px',
                overflowY: 'auto'
              }}>
                {/* Symbol Name */}
                <div style={{ background: '#252525', borderRadius: '8px', padding: '12px' }}>
                  <label style={{ display: 'block', color: '#aaa', fontSize: '11px', marginBottom: '6px' }}>Symbol Name:</label>
                  <input 
                    type="text"
                    value={symbolName}
                    onChange={(e) => setSymbolName(e.target.value)}
                    placeholder="Enter name..."
                    style={{
                      width: '100%',
                      padding: '8px',
                      background: '#333',
                      border: '1px solid #444',
                      borderRadius: '4px',
                      color: '#fff',
                      fontSize: '13px',
                      boxSizing: 'border-box'
                    }}
                  />
                </div>

                {/* Tools */}
                <div style={{ background: '#252525', borderRadius: '8px', padding: '12px' }}>
                  <label style={{ display: 'block', color: '#aaa', fontSize: '11px', marginBottom: '6px' }}>Tools:</label>
                  <div style={{ display: 'flex', gap: '6px' }}>
                    <button 
                      onClick={() => setEditTool('eraser')}
                      style={{
                        flex: 1,
                        padding: '8px',
                        background: editTool === 'eraser' ? '#2ecc71' : '#333',
                        border: '1px solid #444',
                        borderRadius: '4px',
                        color: editTool === 'eraser' ? '#000' : '#ccc',
                        fontSize: '11px',
                        cursor: 'pointer'
                      }}
                    >
                      🧹 Eraser
                    </button>
                    <button 
                      onClick={() => setEditTool('fill')}
                      style={{
                        flex: 1,
                        padding: '8px',
                        background: editTool === 'fill' ? '#2ecc71' : '#333',
                        border: '1px solid #444',
                        borderRadius: '4px',
                        color: editTool === 'fill' ? '#000' : '#ccc',
                        fontSize: '11px',
                        cursor: 'pointer'
                      }}
                    >
                      ⬜ Fill
                    </button>
                  </div>
                  <div style={{ marginTop: '8px' }}>
                    <label style={{ display: 'block', color: '#888', fontSize: '10px', marginBottom: '4px' }}>Brush Size: {editBrushSize}px</label>
                    <input 
                      type="range" 
                      min="2" 
                      max="50" 
                      value={editBrushSize}
                      onChange={(e) => setEditBrushSize(parseInt(e.target.value))}
                      style={{ width: '100%' }}
                    />
                  </div>
                </div>
                
                {/* Quick Actions */}
                <div style={{ background: '#252525', borderRadius: '8px', padding: '12px' }}>
                  <label style={{ display: 'block', color: '#aaa', fontSize: '11px', marginBottom: '6px' }}>Quick Actions:</label>
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '4px' }}>
                    <button onClick={() => removeBackground(240)} style={actionBtnStyle}>🔲 Remove BG</button>
                    <button onClick={() => removeNoise(200)} style={actionBtnStyle}>✨ Threshold</button>
                    <button onClick={() => removeSpecks(30)} style={actionBtnStyle}>🧹 Specks</button>
                    <button onClick={invertColors} style={actionBtnStyle}>🔄 Invert</button>
                    <button onClick={trimTransparent} style={actionBtnStyle}>✂️ Trim</button>
                    <button onClick={resetToOriginal} style={actionBtnStyle}>↩️ Reset</button>
                  </div>
                </div>
                
                {/* Recolor */}
                <div style={{ background: '#252525', borderRadius: '8px', padding: '12px' }}>
                  <label style={{ display: 'block', color: '#aaa', fontSize: '11px', marginBottom: '6px' }}>Recolor:</label>
                  <div style={{ display: 'flex', gap: '6px', marginBottom: '8px' }}>
                    <input 
                      type="color" 
                      value={symbolColor}
                      onChange={(e) => setSymbolColor(e.target.value)}
                      style={{ width: '40px', height: '30px', border: 'none', borderRadius: '4px', cursor: 'pointer' }}
                    />
                    <button 
                      onClick={() => recolorSymbol(symbolColor)}
                      style={{
                        flex: 1,
                        padding: '6px',
                        background: '#444',
                        border: '1px solid #555',
                        borderRadius: '4px',
                        color: '#fff',
                        fontSize: '11px',
                        cursor: 'pointer'
                      }}
                    >
                      Apply
                    </button>
                  </div>
                  <div style={{ display: 'flex', gap: '4px', flexWrap: 'wrap' }}>
                    {['#000000', '#ff0000', '#0000ff', '#00aa00', '#ff6600', '#9900cc'].map(color => (
                      <button
                        key={color}
                        onClick={() => { setSymbolColor(color); recolorSymbol(color); }}
                        style={{
                          width: '28px',
                          height: '28px',
                          background: color,
                          border: '2px solid #444',
                          borderRadius: '4px',
                          cursor: 'pointer'
                        }}
                      />
                    ))}
                  </div>
                </div>
              </div>
            </div>
            
            {/* Modal Footer */}
            <div style={{
              display: 'flex',
              justifyContent: 'flex-end',
              gap: '12px',
              padding: '16px 20px',
              borderTop: '1px solid #333'
            }}>
              <button 
                onClick={cancelEditing}
                style={{
                  padding: '10px 20px',
                  background: '#444',
                  border: 'none',
                  borderRadius: '6px',
                  color: '#ccc',
                  fontSize: '14px',
                  cursor: 'pointer'
                }}
              >
                Cancel
              </button>
              <button 
                onClick={saveEditedSymbol}
                style={{
                  padding: '10px 24px',
                  background: '#27ae60',
                  border: 'none',
                  borderRadius: '6px',
                  color: '#fff',
                  fontSize: '14px',
                  fontWeight: '500',
                  cursor: 'pointer'
                }}
              >
                💾 Save Symbol
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}

// Shared style for action buttons
const actionBtnStyle = {
  padding: '6px 4px',
  background: '#333',
  border: '1px solid #444',
  borderRadius: '4px',
  color: '#ccc',
  fontSize: '10px',
  cursor: 'pointer'
};
