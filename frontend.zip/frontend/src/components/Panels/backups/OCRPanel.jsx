/**
 * OCRPanel.jsx
 * 
 * Panel for OCR - extracting text from PDF pages including pipe tags.
 */

import { useState } from 'react';

export default function OCRPanel({
  isOpen,
  onClose,
  // OCR mode
  ocrMode,
  onOcrModeChange,
  // Display
  showOcrOnPdf,
  onShowOcrOnPdfChange,
  // Scope
  ocrScope,
  onOcrScopeChange,
  // Context
  currentFile,
  numPages,
  currentPage,
  // OCR state
  isRunningOcr,
  ocrProgress,
  ocrResults,
  // Filter
  ocrFilter,
  onOcrFilterChange,
  ocrFilterType,
  onOcrFilterTypeChange,
  // Actions
  onRunOcr,
  onExportOcr,
  onExportToObjects,
  // Existing classes for dropdown
  existingClasses = []
}) {
  // Export to Objects dialog state
  const [showExportDialog, setShowExportDialog] = useState(false);
  const [exportPatterns, setExportPatterns] = useState([{ pattern: '', filterType: 'contains' }]);
  const [exportClassName, setExportClassName] = useState('');
  const [useExistingClass, setUseExistingClass] = useState(false);
  const [selectedExistingClass, setSelectedExistingClass] = useState('');

  if (!isOpen) return null;

  // Helper to match pattern
  const matchesPattern = (text, pattern, filterType) => {
    if (!pattern) return false;
    const upperText = text.toUpperCase();
    const upperPattern = pattern.toUpperCase();
    
    if (filterType === 'contains') {
      return upperText.includes(upperPattern);
    } else if (filterType === 'starts') {
      return upperText.startsWith(upperPattern);
    } else if (filterType === 'regex') {
      try {
        const regexPattern = pattern.replace(/\*/g, '.*').replace(/\?/g, '.');
        return new RegExp(regexPattern, 'i').test(text);
      } catch {
        return false;
      }
    }
    return false;
  };

  const filteredResults = ocrResults.filter(item => {
    if (!ocrFilter) return true;
    return matchesPattern(item.text, ocrFilter, ocrFilterType);
  });

  // Get matching items for all export patterns
  const getMatchingItems = () => {
    const matched = new Set();
    const matchedItems = [];
    
    ocrResults.forEach(item => {
      exportPatterns.forEach(p => {
        if (p.pattern && matchesPattern(item.text, p.pattern, p.filterType)) {
          const key = `${item.text}-${item.page}-${item.bbox.x}-${item.bbox.y}`;
          if (!matched.has(key)) {
            matched.add(key);
            matchedItems.push(item);
          }
        }
      });
    });
    
    return matchedItems;
  };

  const handleAddPattern = () => {
    setExportPatterns([...exportPatterns, { pattern: '', filterType: 'contains' }]);
  };

  const handleRemovePattern = (index) => {
    if (exportPatterns.length > 1) {
      setExportPatterns(exportPatterns.filter((_, i) => i !== index));
    }
  };

  const handlePatternChange = (index, field, value) => {
    const updated = [...exportPatterns];
    updated[index][field] = value;
    setExportPatterns(updated);
  };

  const handleExportToObjects = () => {
    const className = useExistingClass ? selectedExistingClass : exportClassName.trim();
    if (!className) return;
    
    const matchingItems = getMatchingItems();
    if (matchingItems.length === 0) return;
    
    if (onExportToObjects) {
      onExportToObjects({
        className,
        isNewClass: !useExistingClass,
        items: matchingItems
      });
    }
    
    // Reset and close
    setShowExportDialog(false);
    setExportPatterns([{ pattern: '', filterType: 'contains' }]);
    setExportClassName('');
    setUseExistingClass(false);
    setSelectedExistingClass('');
  };

  const matchingCount = getMatchingItems().length;

  return (
    <div className="smart-links-panel ocr-panel">
      <div className="panel-header">
        <h3>OCR</h3>
        <button className="close-panel" onClick={onClose}>×</button>
      </div>

      <div className="panel-content">
        {/* OCR Mode Selection */}
        <div className="panel-section">
          <h4>OCR Mode</h4>
          <div className="mode-buttons">
            <button
              className={ocrMode === 'page' ? 'active' : ''}
              onClick={() => onOcrModeChange('page')}
            >
              Current Page
            </button>
            <button
              className={ocrMode === 'all' ? 'active' : ''}
              onClick={() => onOcrModeChange('all')}
            >
              All Pages
            </button>
          </div>
          
          <label className="toggle-option">
            <input
              type="checkbox"
              checked={showOcrOnPdf}
              onChange={(e) => onShowOcrOnPdfChange(e.target.checked)}
            />
            <span>Show OCR Results on Document</span>
          </label>
        </div>

        {/* Run OCR Section */}
        <div className="panel-section">
          <h4>Run OCR</h4>
          
          {numPages > 1 && (
            <div className="option-group">
              <label>Scope:</label>
              <select value={ocrScope} onChange={(e) => onOcrScopeChange(e.target.value)}>
                <option value="current">Current Page ({currentPage})</option>
                <option value="all">All Pages (1-{numPages})</option>
              </select>
            </div>
          )}

          <button
            className="primary-btn run-ocr-btn"
            onClick={onRunOcr}
            disabled={isRunningOcr || !currentFile}
          >
            {isRunningOcr ? 'Running OCR...' : '🔍 Run OCR'}
          </button>
          
          {/* OCR Progress Bar */}
          {isRunningOcr && ocrProgress && (
            <div className="detection-progress" style={{ marginTop: 12 }}>
              <div className="progress-bar-container" style={{
                background: '#e0e0e0',
                borderRadius: 4,
                height: 8,
                overflow: 'hidden',
                marginBottom: 6
              }}>
                <div className="progress-bar-fill" style={{
                  background: '#3498db',
                  height: '100%',
                  width: `${ocrProgress.percent || 0}%`,
                  transition: 'width 0.3s ease'
                }} />
              </div>
              <div className="progress-status" style={{ fontSize: 11, color: '#666' }}>
                {ocrProgress.status || 'Processing...'}
              </div>
            </div>
          )}
        </div>

        {/* Filter Section */}
        <div className="panel-section">
          <h4>Filter Results</h4>
          
          <input
            type="text"
            className="model-search-input"
            placeholder="Type pattern (e.g., 12-XF, TI-, *-PW-*)"
            value={ocrFilter}
            onChange={(e) => {
              onOcrFilterChange(e.target.value);
              // Auto-switch to regex mode when wildcards are used
              if (e.target.value.includes('*') || e.target.value.includes('?')) {
                onOcrFilterTypeChange('regex');
              }
            }}
          />
          
          {/* Show generated regex when in regex mode */}
          {ocrFilterType === 'regex' && ocrFilter && (
            <div style={{ fontSize: 10, color: '#888', marginTop: 4, fontFamily: 'monospace' }}>
              Regex: {ocrFilter.replace(/\*/g, '.*').replace(/\?/g, '.')}
            </div>
          )}
          
          <div className="filter-type-options" style={{ marginTop: 8, display: 'flex', gap: 12 }}>
            <label style={{ fontSize: 12, color: '#ccc' }}>
              <input
                type="radio"
                name="filterType"
                value="contains"
                checked={ocrFilterType === 'contains'}
                onChange={() => onOcrFilterTypeChange('contains')}
              />
              Contains
            </label>
            <label style={{ fontSize: 12, color: '#ccc' }}>
              <input
                type="radio"
                name="filterType"
                value="starts"
                checked={ocrFilterType === 'starts'}
                onChange={() => onOcrFilterTypeChange('starts')}
              />
              Starts with
            </label>
            <label style={{ fontSize: 12, color: '#ccc' }}>
              <input
                type="radio"
                name="filterType"
                value="regex"
                checked={ocrFilterType === 'regex'}
                onChange={() => onOcrFilterTypeChange('regex')}
              />
              Pattern (* = any)
            </label>
          </div>

          {/* Quick filter buttons */}
          <div className="quick-filters" style={{ marginTop: 10, display: 'flex', flexWrap: 'wrap', gap: 4 }}>
            <button className="quick-filter-btn" onClick={() => { onOcrFilterChange('TI'); onOcrFilterTypeChange('starts'); }}>TI</button>
            <button className="quick-filter-btn" onClick={() => { onOcrFilterChange('FI'); onOcrFilterTypeChange('starts'); }}>FI</button>
            <button className="quick-filter-btn" onClick={() => { onOcrFilterChange('LI'); onOcrFilterTypeChange('starts'); }}>LI</button>
            <button className="quick-filter-btn" onClick={() => { onOcrFilterChange('PI'); onOcrFilterTypeChange('starts'); }}>PI</button>
            <button className="quick-filter-btn" onClick={() => { onOcrFilterChange('HS'); onOcrFilterTypeChange('starts'); }}>HS</button>
            <button className="quick-filter-btn" onClick={() => { onOcrFilterChange(''); }}>Clear</button>
          </div>
        </div>

        {/* Results Section */}
        <div className="panel-section" style={{ flex: 1, display: 'flex', flexDirection: 'column', minHeight: 150 }}>
          <h4>Results ({filteredResults.length}{ocrFilter ? ` / ${ocrResults.length}` : ''})</h4>
          
          {ocrResults.length === 0 ? (
            <p className="no-models">No OCR results yet. Run OCR to extract text.</p>
          ) : (
            <div className="models-list scrollable" style={{ flex: 1, overflowY: 'auto' }}>
              {filteredResults.map((item, index) => (
                <div key={index} className="model-item ocr-result-item" style={{ background: 'transparent', borderBottom: '1px solid #333' }}>
                  <span className="ocr-text" style={{ color: 'white', fontWeight: 'bold' }}>{item.text}</span>
                  <span className="model-info" style={{ color: '#888' }}>
                    {item.page && `P${item.page}`} ({(item.confidence * 100).toFixed(0)}%)
                  </span>
                </div>
              ))}
              {filteredResults.length === 0 && ocrFilter && (
                <p className="no-results">No results match "{ocrFilter}"</p>
              )}
            </div>
          )}
        </div>

        {/* Export Section */}
        <div className="panel-section">
          <button
            className="primary-btn export-to-objects-btn"
            onClick={() => setShowExportDialog(true)}
            disabled={ocrResults.length === 0}
            style={{ width: '100%', marginBottom: 8 }}
          >
            📦 Export to Objects
          </button>
          <button
            className="secondary-btn export-btn"
            onClick={onExportOcr}
            disabled={ocrResults.length === 0}
            style={{ width: '100%' }}
          >
            💾 Export CSV
          </button>
        </div>
      </div>

      {/* Export to Objects Dialog */}
      {showExportDialog && (
        <div className="modal-overlay" onClick={() => setShowExportDialog(false)}>
          <div className="modal export-ocr-modal" onClick={(e) => e.stopPropagation()} style={{
            background: '#2a2a2a',
            borderRadius: 8,
            padding: 20,
            minWidth: 400,
            maxWidth: 500,
            color: 'white'
          }}>
            <h2 style={{ marginTop: 0, marginBottom: 16 }}>Export OCR to Objects</h2>
            
            {/* Patterns Section */}
            <div style={{ marginBottom: 16 }}>
              <label style={{ display: 'block', marginBottom: 8, fontWeight: 'bold' }}>
                Patterns to Match:
              </label>
              {exportPatterns.map((p, idx) => (
                <div key={idx} style={{ display: 'flex', gap: 8, marginBottom: 8, alignItems: 'center' }}>
                  <input
                    type="text"
                    value={p.pattern}
                    onChange={(e) => handlePatternChange(idx, 'pattern', e.target.value)}
                    placeholder="e.g., TI-*, 12-XF*, *-PW-*"
                    style={{
                      flex: 1,
                      padding: '8px 12px',
                      background: '#1a1a1a',
                      border: '1px solid #444',
                      borderRadius: 4,
                      color: 'white'
                    }}
                  />
                  <select
                    value={p.filterType}
                    onChange={(e) => handlePatternChange(idx, 'filterType', e.target.value)}
                    style={{
                      padding: '8px',
                      background: '#1a1a1a',
                      border: '1px solid #444',
                      borderRadius: 4,
                      color: 'white'
                    }}
                  >
                    <option value="contains">Contains</option>
                    <option value="starts">Starts with</option>
                    <option value="regex">Pattern (*)</option>
                  </select>
                  {exportPatterns.length > 1 && (
                    <button
                      onClick={() => handleRemovePattern(idx)}
                      style={{
                        background: '#c0392b',
                        border: 'none',
                        borderRadius: 4,
                        color: 'white',
                        padding: '6px 10px',
                        cursor: 'pointer'
                      }}
                    >
                      ×
                    </button>
                  )}
                </div>
              ))}
              <button
                onClick={handleAddPattern}
                style={{
                  background: 'transparent',
                  border: '1px dashed #666',
                  borderRadius: 4,
                  color: '#888',
                  padding: '6px 12px',
                  cursor: 'pointer',
                  width: '100%'
                }}
              >
                + Add Another Pattern
              </button>
            </div>

            {/* Matching Preview */}
            <div style={{
              background: '#1a1a1a',
              borderRadius: 4,
              padding: 12,
              marginBottom: 16,
              maxHeight: 120,
              overflowY: 'auto'
            }}>
              <div style={{ fontSize: 12, color: '#888', marginBottom: 8 }}>
                Matching: <strong style={{ color: matchingCount > 0 ? '#27ae60' : '#e74c3c' }}>{matchingCount}</strong> items
              </div>
              {matchingCount > 0 && (
                <div style={{ fontSize: 11, color: '#aaa' }}>
                  {getMatchingItems().slice(0, 5).map((item, i) => (
                    <div key={i} style={{ padding: '2px 0' }}>
                      • {item.text} <span style={{ color: '#666' }}>(P{item.page})</span>
                    </div>
                  ))}
                  {matchingCount > 5 && (
                    <div style={{ color: '#666', fontStyle: 'italic' }}>
                      ...and {matchingCount - 5} more
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Class Selection */}
            <div style={{ marginBottom: 16 }}>
              <label style={{ display: 'block', marginBottom: 8, fontWeight: 'bold' }}>
                Assign to Class:
              </label>
              
              {existingClasses.length > 0 && (
                <div style={{ marginBottom: 12 }}>
                  <label style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8, cursor: 'pointer' }}>
                    <input
                      type="radio"
                      checked={!useExistingClass}
                      onChange={() => setUseExistingClass(false)}
                    />
                    <span>Create new class</span>
                  </label>
                  <label style={{ display: 'flex', alignItems: 'center', gap: 8, cursor: 'pointer' }}>
                    <input
                      type="radio"
                      checked={useExistingClass}
                      onChange={() => setUseExistingClass(true)}
                    />
                    <span>Use existing class</span>
                  </label>
                </div>
              )}

              {!useExistingClass ? (
                <input
                  type="text"
                  value={exportClassName}
                  onChange={(e) => setExportClassName(e.target.value)}
                  placeholder="Enter new class name (e.g., Pipe Tags)"
                  style={{
                    width: '100%',
                    padding: '8px 12px',
                    background: '#1a1a1a',
                    border: '1px solid #444',
                    borderRadius: 4,
                    color: 'white',
                    boxSizing: 'border-box'
                  }}
                />
              ) : (
                <select
                  value={selectedExistingClass}
                  onChange={(e) => setSelectedExistingClass(e.target.value)}
                  style={{
                    width: '100%',
                    padding: '8px 12px',
                    background: '#1a1a1a',
                    border: '1px solid #444',
                    borderRadius: 4,
                    color: 'white'
                  }}
                >
                  <option value="">-- Select class --</option>
                  {existingClasses.map(cls => (
                    <option key={cls.id || cls.name} value={cls.name}>{cls.name}</option>
                  ))}
                </select>
              )}
            </div>

            {/* Buttons */}
            <div style={{ display: 'flex', gap: 12, justifyContent: 'flex-end' }}>
              <button
                onClick={() => setShowExportDialog(false)}
                style={{
                  background: '#444',
                  border: 'none',
                  borderRadius: 4,
                  color: 'white',
                  padding: '10px 20px',
                  cursor: 'pointer'
                }}
              >
                Cancel
              </button>
              <button
                onClick={handleExportToObjects}
                disabled={matchingCount === 0 || (!useExistingClass && !exportClassName.trim()) || (useExistingClass && !selectedExistingClass)}
                style={{
                  background: matchingCount > 0 ? '#27ae60' : '#555',
                  border: 'none',
                  borderRadius: 4,
                  color: 'white',
                  padding: '10px 20px',
                  cursor: matchingCount > 0 ? 'pointer' : 'not-allowed',
                  opacity: matchingCount > 0 ? 1 : 0.6
                }}
              >
                Export {matchingCount} Objects
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
