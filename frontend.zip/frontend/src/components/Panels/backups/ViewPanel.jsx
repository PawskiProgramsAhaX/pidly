/**
 * ViewPanel.jsx
 * 
 * Panel for controlling view mode settings - page layout and view preferences.
 */

import { useState } from 'react';

export default function ViewPanel({
  isOpen,
  onClose,
  viewMode,
  onViewModeChange,
  numPages,
  currentFile,
  currentPage,
  onOpenInfiniteView,
  pdfBackgroundColor,
  onBackgroundColorChange
}) {
  const [showContinuousOptions, setShowContinuousOptions] = useState(false);

  if (!isOpen) return null;

  return (
    <div className="smart-links-panel">
      <div className="panel-header">
        <h3>View Mode</h3>
        <button className="close-panel" onClick={onClose}>×</button>
      </div>
      <div className="panel-content">
        <div className="panel-section">
          <h4>Page Layout</h4>
          <div className="view-mode-options-simple">
            <label 
              className={`view-mode-option-simple ${viewMode === 'single' ? 'selected' : ''}`}
              onClick={() => { onViewModeChange('single'); setShowContinuousOptions(false); }}
            >
              <input 
                type="radio" 
                name="viewMode" 
                checked={viewMode === 'single'} 
                onChange={() => {}}
              />
              <span>Single Page</span>
            </label>
            
            <label 
              className={`view-mode-option-simple ${(viewMode === 'continuous' || viewMode === 'sideBySide') ? 'selected' : ''} ${numPages <= 1 ? 'disabled' : ''}`}
              onClick={(e) => {
                e.preventDefault();
                if (numPages > 1) {
                  setShowContinuousOptions(!showContinuousOptions);
                }
              }}
            >
              <input 
                type="radio" 
                name="viewMode" 
                checked={viewMode === 'continuous' || viewMode === 'sideBySide'} 
                onChange={() => {}}
                disabled={numPages <= 1}
              />
              <span>Continuous</span>
              {numPages > 1 && (
                <svg 
                  width="12" 
                  height="12" 
                  viewBox="0 0 16 16" 
                  fill="none" 
                  style={{ marginLeft: 'auto', transform: showContinuousOptions ? 'rotate(180deg)' : 'rotate(0deg)', transition: 'transform 0.2s' }}
                >
                  <path d="M4 6L8 10L12 6" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              )}
            </label>
            
            {showContinuousOptions && (
              <div className="continuous-sub-options">
                <label 
                  className={`view-mode-sub-option ${viewMode === 'continuous' ? 'selected' : ''}`}
                  onClick={(e) => { e.preventDefault(); e.stopPropagation(); onViewModeChange('continuous'); }}
                >
                  <input 
                    type="radio" 
                    name="continuousMode" 
                    checked={viewMode === 'continuous'} 
                    onChange={() => {}}
                  />
                  <span>Vertical</span>
                </label>
                <label 
                  className={`view-mode-sub-option ${viewMode === 'sideBySide' ? 'selected' : ''}`}
                  onClick={(e) => { e.preventDefault(); e.stopPropagation(); onViewModeChange('sideBySide'); }}
                >
                  <input 
                    type="radio" 
                    name="continuousMode" 
                    checked={viewMode === 'sideBySide'} 
                    onChange={() => {}}
                  />
                  <span>Horizontal</span>
                </label>
              </div>
            )}
            
            <label 
              className="view-mode-option-simple"
              onClick={() => {
                if (onOpenInfiniteView) {
                  onClose();
                  onOpenInfiniteView(currentFile, currentPage);
                }
              }}
            >
              <input 
                type="radio" 
                name="viewMode" 
                checked={false} 
                onChange={() => {}}
              />
              <span>Infinite Canvas</span>
            </label>
          </div>
          
          {numPages <= 1 && (
            <p className="view-mode-tip-small">
              Continuous view requires multi-page documents.
            </p>
          )}
        </div>
        
        <div className="panel-section">
          <h4>View Preferences</h4>
          <div className="view-preferences">
            <div className="view-pref-row">
              <label>Background Colour</label>
              <input 
                type="color" 
                value={pdfBackgroundColor}
                onChange={(e) => onBackgroundColorChange(e.target.value)}
                className="color-input-small"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
