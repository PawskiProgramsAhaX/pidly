/**
 * SearchPanel.jsx
 * 
 * Panel for searching objects, tags, and links with filtering options.
 */

export default function SearchPanel({
  isOpen,
  onClose,
  // Search state
  searchQuery,
  onSearchQueryChange,
  searchScope,
  onSearchScopeChange,
  searchPageScope,
  onSearchPageScopeChange,
  debouncedSearchQuery,
  // Display options
  hideLabels,
  onHideLabelsChange,
  showRegionBoxes,
  onShowRegionBoxesChange,
  // Class filter
  hiddenClasses,
  onHiddenClassesChange,
  uniqueObjectClasses,
  // Results
  filteredSearchResults,
  onNavigateToObject,
  // Context info
  currentFile,
  currentFolderInfo,
  currentFolderFiles,
  detectedObjects,
  numPages,
  currentPage
}) {
  if (!isOpen) return null;

  return (
    <div className="smart-links-panel">
      <div className="panel-header">
        <h3>Search</h3>
        <button className="close-panel" onClick={onClose}>×</button>
      </div>
      <div className="panel-content">
        <div className="panel-section">
          <input
            type="text"
            className="search-input"
            placeholder="Search objects, tags, links..."
            value={searchQuery}
            onChange={(e) => onSearchQueryChange(e.target.value)}
            autoFocus
          />
          <div className="search-scope-container">
            <select
              className="scope-select dark-select"
              value={searchScope}
              onChange={(e) => onSearchScopeChange(e.target.value)}
            >
              <option value="current">{currentFile?.name?.replace('.pdf', '') || 'Current Document'}</option>
              <option value="folder">{currentFolderInfo.folder?.name || 'Root'} ({currentFolderFiles.length} files)</option>
              <option value="all">Project ({detectedObjects.length} objects)</option>
            </select>
            {searchScope === 'current' && numPages > 1 && (
              <select
                className="scope-select dark-select"
                value={searchPageScope}
                onChange={(e) => onSearchPageScopeChange(e.target.value)}
                style={{ marginTop: '6px' }}
              >
                <option value="all">Entire Document ({numPages} pages)</option>
                <option value="current">Page {currentPage} only</option>
              </select>
            )}
          </div>
        </div>

        <div className="panel-section">
          <h4>Display Options</h4>
          <div className="class-filter-item">
            <label className="class-checkbox-label">
              <input
                type="checkbox"
                checked={hideLabels}
                onChange={(e) => onHideLabelsChange(e.target.checked)}
              />
              <span>Hide labels on boxes</span>
            </label>
          </div>
        </div>

        <div className="panel-section filter-by-class-section">
          <h4>Filter by Class/Region</h4>
          <div className="class-filters">
            {/* Regions visibility toggle */}
            <div className="class-filter-item">
              <label className="class-checkbox-label">
                <input
                  type="checkbox"
                  checked={showRegionBoxes}
                  onChange={(e) => onShowRegionBoxesChange(e.target.checked)}
                />
                <span>Show Regions</span>
              </label>
            </div>
            
            {/* Get unique classes from detected objects */}
            {uniqueObjectClasses.length === 0 ? (
              <p className="no-classes">No classes detected yet</p>
            ) : (
              <>
                <div className="class-filter-actions">
                  <button 
                    className="show-all-btn"
                    onClick={() => onHiddenClassesChange([])}
                  >
                    Show All
                  </button>
                  <button 
                    className="hide-all-btn"
                    onClick={() => onHiddenClassesChange(uniqueObjectClasses)}
                  >
                    Hide All
                  </button>
                </div>
                {uniqueObjectClasses.map(cls => (
                  <div key={cls} className="class-filter-item">
                    <label className="class-checkbox-label">
                      <input
                        type="checkbox"
                        checked={!hiddenClasses.includes(cls)}
                        onChange={(e) => {
                          if (e.target.checked) {
                            onHiddenClassesChange(hiddenClasses.filter(c => c !== cls));
                          } else {
                            onHiddenClassesChange([...hiddenClasses, cls]);
                          }
                        }}
                      />
                      <span>{cls}</span>
                    </label>
                  </div>
                ))}
              </>
            )}
          </div>
        </div>

        <div className="panel-section search-results-section">
          <h4>Search Results {filteredSearchResults.length > 0 && `(${filteredSearchResults.length}${filteredSearchResults.length >= 100 ? '+' : ''})`}</h4>
          {searchQuery.trim() === '' ? (
            <p className="no-results">Enter a search term</p>
          ) : searchQuery !== debouncedSearchQuery ? (
            <p className="no-results">Searching...</p>
          ) : (
            <div className="search-results">
              {filteredSearchResults.length === 0 ? (
                <p className="no-results">No results found</p>
              ) : (
                filteredSearchResults.map((obj, i) => (
                  <div key={obj.id || `obj_${i}`} className="search-result-item" onClick={() => onNavigateToObject(obj)}>
                    {/* Subclass values - each on its own line */}
                    {obj.subclassValues && Object.keys(obj.subclassValues).length > 0 ? (
                      Object.entries(obj.subclassValues).map(([k, v]) => (
                        <div key={k} className="result-line">{k}: {v || '-'}</div>
                      ))
                    ) : (
                      obj.ocr_text && <div className="result-line">Tag: {obj.ocr_text}</div>
                    )}
                    <div className="result-line">{obj.label}</div>
                    <div className="result-line result-document">{obj.filename?.replace('.pdf', '') || 'Unknown'}</div>
                  </div>
                ))
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
