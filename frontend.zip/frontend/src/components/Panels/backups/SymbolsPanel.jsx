/**
 * SymbolsPanel.jsx
 * 
 * Panel for managing reusable symbols - create, search, drag & drop onto PDF.
 */

export default function SymbolsPanel({
  isOpen,
  onClose,
  // Creation mode
  symbolCreationMode,
  onSetSymbolCreationMode,
  selectedMarkups,
  selectedMarkup,
  onClearSelections,
  onOpenSaveDialog,
  // Edit mode check
  markupEditMode,
  onEnterCreationMode,
  // Symbols list
  savedSymbols,
  symbolSearchQuery,
  onSearchQueryChange,
  symbolsViewMode,
  onViewModeChange,
  onDeleteSymbol,
  // Drag state
  onDragStart,
  onDragEnd,
  // For drag image sizing
  canvasSize,
  scale
}) {
  if (!isOpen) return null;

  const filteredSymbols = savedSymbols.filter(s => 
    !symbolSearchQuery || s.name.toLowerCase().includes(symbolSearchQuery.toLowerCase())
  );

  const hasSelection = selectedMarkups.length > 0 || selectedMarkup;
  const selectionCount = selectedMarkups.length > 0 ? selectedMarkups.length : (selectedMarkup ? 1 : 0);

  return (
    <div className="smart-links-panel" style={{ width: '320px', minWidth: '320px', display: 'flex', flexDirection: 'column' }}>
      <div className="panel-header">
        <h3>Symbols</h3>
        <button className="close-panel" onClick={onClose}>×</button>
      </div>
      <div className="panel-content" style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden', padding: '8px 12px' }}>
        
        {/* Symbol creation mode UI */}
        {symbolCreationMode ? (
          <div style={{
            padding: '10px',
            background: '#f5f5f5',
            borderRadius: '4px',
            marginBottom: '8px',
            border: '1px dashed #666',
            flexShrink: 0
          }}>
            <p style={{ fontSize: '11px', color: '#666', margin: '0 0 8px 0' }}>
              Select markups on the PDF to include in your symbol.
            </p>
            {hasSelection && (
              <p style={{ fontSize: '12px', color: '#333', fontWeight: '500', margin: '0 0 8px 0' }}>
                {selectionCount} markup{selectionCount > 1 ? 's' : ''} selected
              </p>
            )}
            <div style={{ display: 'flex', gap: '6px' }}>
              <button
                onClick={() => {
                  if (hasSelection) {
                    onOpenSaveDialog();
                  }
                }}
                disabled={!hasSelection}
                style={{
                  flex: 1,
                  padding: '6px 10px',
                  background: hasSelection ? '#27ae60' : '#ccc',
                  color: 'white',
                  border: 'none',
                  borderRadius: '4px',
                  fontSize: '11px',
                  fontWeight: '500',
                  cursor: hasSelection ? 'pointer' : 'not-allowed'
                }}
              >
                ✓ Save Symbol
              </button>
              <button
                onClick={() => {
                  onSetSymbolCreationMode(false);
                  onClearSelections();
                }}
                style={{
                  padding: '6px 10px',
                  background: '#e74c3c',
                  color: 'white',
                  border: 'none',
                  borderRadius: '4px',
                  fontSize: '11px',
                  fontWeight: '500',
                  cursor: 'pointer'
                }}
              >
                ✕ Cancel
              </button>
            </div>
          </div>
        ) : (
          /* Create Symbol button when not in creation mode */
          <button
            onClick={() => {
              if (!markupEditMode) {
                alert('Please unlock the document first to create symbols.');
                return;
              }
              onEnterCreationMode();
            }}
            style={{
              width: '100%',
              padding: '8px 12px',
              background: markupEditMode ? '#333' : '#ccc',
              color: 'white',
              border: 'none',
              borderRadius: '4px',
              fontSize: '12px',
              fontWeight: '500',
              cursor: markupEditMode ? 'pointer' : 'not-allowed',
              marginBottom: '10px',
              flexShrink: 0
            }}
            title={markupEditMode ? "Create a new symbol from selected markups" : "Unlock document to create symbols"}
          >
            + Create Symbol
          </button>
        )}
        
        {savedSymbols.length === 0 && !symbolCreationMode ? (
          <p style={{ fontSize: '11px', color: '#888', margin: '8px 0', textAlign: 'center' }}>
            No symbols yet. Click the button above to create one.
          </p>
        ) : savedSymbols.length > 0 && (
          <>
            {/* Search bar with view toggle */}
            <div style={{ display: 'flex', gap: '6px', marginBottom: '6px', flexShrink: 0 }}>
              <input
                type="text"
                placeholder="Search..."
                value={symbolSearchQuery}
                onChange={(e) => onSearchQueryChange(e.target.value)}
                style={{
                  flex: 1,
                  padding: '5px 8px',
                  border: '1px solid #ddd',
                  borderRadius: '3px',
                  fontSize: '11px',
                  boxSizing: 'border-box'
                }}
              />
              <div style={{ display: 'flex', border: '1px solid #ddd', borderRadius: '3px', overflow: 'hidden' }}>
                <button
                  onClick={() => {
                    onViewModeChange('grid');
                    localStorage.setItem('symbols_view_mode', 'grid');
                  }}
                  style={{
                    padding: '4px 8px',
                    background: symbolsViewMode === 'grid' ? '#333' : '#fff',
                    color: symbolsViewMode === 'grid' ? '#fff' : '#666',
                    border: 'none',
                    cursor: 'pointer',
                    fontSize: '11px'
                  }}
                  title="Grid view"
                >
                  ⊞
                </button>
                <button
                  onClick={() => {
                    onViewModeChange('list');
                    localStorage.setItem('symbols_view_mode', 'list');
                  }}
                  style={{
                    padding: '4px 8px',
                    background: symbolsViewMode === 'list' ? '#333' : '#fff',
                    color: symbolsViewMode === 'list' ? '#fff' : '#666',
                    border: 'none',
                    borderLeft: '1px solid #ddd',
                    cursor: 'pointer',
                    fontSize: '11px'
                  }}
                  title="List view"
                >
                  ☰
                </button>
              </div>
            </div>
            
            {/* Symbols container - grid or list */}
            <div className="symbols-list" style={{ 
              flex: 1,
              minHeight: '100px',
              overflowY: 'auto',
              overflowX: 'hidden',
              display: symbolsViewMode === 'grid' ? 'grid' : 'flex',
              gridTemplateColumns: symbolsViewMode === 'grid' ? 'repeat(3, 1fr)' : undefined,
              flexDirection: symbolsViewMode === 'list' ? 'column' : undefined,
              gap: symbolsViewMode === 'grid' ? '4px' : '2px',
              padding: '2px',
              alignContent: 'start'
            }}>
              {filteredSymbols.map(symbol => (
                <div 
                  key={symbol.id}
                  className="symbol-item"
                  draggable
                  onDragStart={(e) => {
                    e.dataTransfer.setData('application/json', JSON.stringify(symbol));
                    onDragStart(symbol);
                    
                    // Create custom drag image at actual size
                    if (symbol.preview && canvasSize.width && canvasSize.height) {
                      const width = (symbol.originalWidth || 0.1) * canvasSize.width * scale;
                      const height = (symbol.originalHeight || 0.1) * canvasSize.height * scale;
                      
                      const dragImg = document.createElement('div');
                      dragImg.style.cssText = `
                        position: fixed;
                        top: -10000px;
                        left: -10000px;
                        width: ${width}px;
                        height: ${height}px;
                        pointer-events: none;
                      `;
                      dragImg.innerHTML = symbol.preview.replace(
                        /<svg/,
                        `<svg style="width:${width}px;height:${height}px"`
                      );
                      document.body.appendChild(dragImg);
                      
                      e.dataTransfer.setDragImage(dragImg, width / 2, height / 2);
                      
                      setTimeout(() => document.body.removeChild(dragImg), 0);
                    }
                  }}
                  onDragEnd={() => onDragEnd()}
                  style={symbolsViewMode === 'grid' ? {
                    display: 'flex',
                    flexDirection: 'column',
                    padding: '3px',
                    background: '#f8f8f8',
                    borderRadius: '4px',
                    cursor: 'grab',
                    border: '1px solid #e0e0e0',
                    transition: 'all 0.1s'
                  } : {
                    display: 'flex',
                    flexDirection: 'row',
                    alignItems: 'center',
                    padding: '4px 6px',
                    background: '#f8f8f8',
                    borderRadius: '4px',
                    cursor: 'grab',
                    border: '1px solid #e0e0e0',
                    transition: 'all 0.1s',
                    gap: '8px'
                  }}
                  onMouseEnter={(e) => { e.currentTarget.style.background = '#f0f0f0'; e.currentTarget.style.borderColor = '#ccc'; }}
                  onMouseLeave={(e) => { e.currentTarget.style.background = '#f8f8f8'; e.currentTarget.style.borderColor = '#e0e0e0'; }}
                >
                  {/* Preview */}
                  {symbolsViewMode === 'grid' ? (
                    <div style={{
                      width: '100%',
                      paddingBottom: '100%',
                      position: 'relative',
                      background: 'white',
                      borderRadius: '2px',
                      marginBottom: '2px',
                      overflow: 'hidden'
                    }}>
                      <div style={{
                        position: 'absolute',
                        top: '2px',
                        left: '2px',
                        right: '2px',
                        bottom: '2px',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center'
                      }}>
                        {symbol.preview ? (
                          <div 
                            dangerouslySetInnerHTML={{ __html: symbol.preview.replace(/<svg/, '<svg style="width:100%;height:100%"') }}
                            style={{ width: '100%', height: '100%' }}
                          />
                        ) : (
                          <span style={{ fontSize: '16px' }}>📌</span>
                        )}
                      </div>
                    </div>
                  ) : (
                    <div style={{
                      width: '32px',
                      height: '32px',
                      flexShrink: 0,
                      background: 'white',
                      borderRadius: '3px',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      overflow: 'hidden'
                    }}>
                      {symbol.preview ? (
                        <div 
                          dangerouslySetInnerHTML={{ __html: symbol.preview.replace(/<svg/, '<svg style="width:100%;height:100%"') }}
                          style={{ width: '100%', height: '100%' }}
                        />
                      ) : (
                        <span style={{ fontSize: '14px' }}>📌</span>
                      )}
                    </div>
                  )}
                  
                  {/* Title and delete row */}
                  <div style={{ 
                    display: 'flex', 
                    alignItems: 'center', 
                    justifyContent: 'space-between',
                    gap: '4px',
                    minWidth: 0,
                    flex: symbolsViewMode === 'list' ? 1 : undefined
                  }}>
                    <span style={{ 
                      fontSize: symbolsViewMode === 'grid' ? '9px' : '12px', 
                      fontWeight: '500',
                      overflow: 'hidden',
                      textOverflow: 'ellipsis',
                      whiteSpace: 'nowrap',
                      flex: 1,
                      minWidth: 0,
                      color: '#555'
                    }} title={symbol.name}>
                      {symbol.name}
                    </span>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        e.preventDefault();
                        if (window.confirm(`Delete "${symbol.name}"?`)) {
                          onDeleteSymbol(symbol.id);
                        }
                      }}
                      onMouseDown={(e) => e.stopPropagation()}
                      style={{
                        background: 'none',
                        border: 'none',
                        cursor: 'pointer',
                        fontSize: symbolsViewMode === 'grid' ? '9px' : '12px',
                        padding: '2px 4px',
                        opacity: 0.4,
                        flexShrink: 0,
                        borderRadius: '2px',
                        lineHeight: 1
                      }}
                      onMouseEnter={(e) => { e.target.style.opacity = '1'; e.target.style.background = '#ffebee'; }}
                      onMouseLeave={(e) => { e.target.style.opacity = '0.4'; e.target.style.background = 'none'; }}
                      title="Delete"
                    >
                      ✕
                    </button>
                  </div>
                </div>
              ))}
              {savedSymbols.length > 0 && symbolSearchQuery && filteredSymbols.length === 0 && (
                <div style={{ gridColumn: '1 / -1', textAlign: 'center', padding: '8px', color: '#888', fontSize: '10px' }}>
                  No matches
                </div>
              )}
            </div>
            
            <p style={{ fontSize: '9px', color: '#aaa', marginTop: '4px', fontStyle: 'italic', flexShrink: 0, textAlign: 'center' }}>
              Drag onto PDF to place
            </p>
          </>
        )}
      </div>
    </div>
  );
}
