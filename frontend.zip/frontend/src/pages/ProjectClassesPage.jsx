import { useState, useEffect, useRef, useMemo, useCallback } from 'react';
import { useParams, useNavigate, useLocation } from 'react-router-dom';
import { getProject, saveProject, getThumbnail, getObjectsFromBackend, saveObjectsToBackend, runDetection } from '../utils/storage';
import './ProjectClassesPage.css';

export default function ProjectClassesPage() {
  const { projectId } = useParams();
  const navigate = useNavigate();
  const location = useLocation();
  const returnToFile = location.state?.returnToFile || null;
  const [project, setProject] = useState(null);
  const [detectedObjects, setDetectedObjects] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [classes, setClasses] = useState([]);
  const [selectedClass, setSelectedClass] = useState(null);
  const [viewMode, setViewMode] = useState('home'); // 'home', 'registry', or 'class'
  const [registryFilter, setRegistryFilter] = useState('all'); // 'all' or class name or 'subclass:ClassName:SubclassName'
  const [selectedTag, setSelectedTag] = useState(null);
  const [registrySearchQuery, setRegistrySearchQuery] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [showNewClassDialog, setShowNewClassDialog] = useState(false);
  const [newClassName, setNewClassName] = useState('');
  const [newClassParentId, setNewClassParentId] = useState(null);
  const [pendingSubclasses, setPendingSubclasses] = useState([]);
  const [newSubclassInput, setNewSubclassInput] = useState('');
  const [showAddColumnDialog, setShowAddColumnDialog] = useState(false);
  const [newColumnName, setNewColumnName] = useState('');
  const [showAddSubclassDialog, setShowAddSubclassDialog] = useState(false);
  const [newSubclassName, setNewSubclassName] = useState('');
  const [editingCell, setEditingCell] = useState(null);
  const [editValue, setEditValue] = useState('');
  const [columnFilters, setColumnFilters] = useState({});
  const [classColumnWidths, setClassColumnWidths] = useState({}); // Per-class column widths: { className: { columnId: width } }
  const [columnAlignments, setColumnAlignments] = useState({}); // Per-class column alignments: { className: { columnId: 'left'|'center'|'right' } }
  const [resizingColumn, setResizingColumn] = useState(null);
  const [thumbnails, setThumbnails] = useState({});
  const [loadingThumbnails, setLoadingThumbnails] = useState({});
  const [sidebarWidth, setSidebarWidth] = useState(320);
  const [isResizingSidebar, setIsResizingSidebar] = useState(false);
  const tableRef = useRef(null);
  
  // Orphaned objects state
  const [showReassignDialog, setShowReassignDialog] = useState(false);
  const [reassignSourceFile, setReassignSourceFile] = useState(null);
  const [reassignTargetFile, setReassignTargetFile] = useState(null);
  const [isReassigning, setIsReassigning] = useState(false);
  const [showDeleteOrphanedDialog, setShowDeleteOrphanedDialog] = useState(false);
  
  // Find and replace state
  const [showFindReplace, setShowFindReplace] = useState(false);
  const [findText, setFindText] = useState('');
  const [replaceText, setReplaceText] = useState('');
  const [findField, setFindField] = useState('filename'); // Which field to search in
  const [matchCase, setMatchCase] = useState(false);
  
  // Import/Export state
  const [showImportDialog, setShowImportDialog] = useState(false);
  const [importData, setImportData] = useState(null);
  const [importMode, setImportMode] = useState('merge'); // 'merge' or 'replace'
  const [importError, setImportError] = useState(null);
  const fileInputRef = useRef(null);

  // === PERFORMANCE: Row virtualization state ===
  const ROW_HEIGHT = 60; // Height of each table row in pixels
  const BUFFER_ROWS = 5; // Extra rows to render above/below viewport
  const [tableScrollTop, setTableScrollTop] = useState(0);
  const [tableHeight, setTableHeight] = useState(600);

  // System columns that appear at the end (Document, Page, Confidence)
  const endColumns = [
    { id: 'filename', name: 'Document', editable: false, deletable: false, filterable: true, defaultWidth: 200 },
    { id: 'page', name: 'Page', editable: false, deletable: false, filterable: true, defaultWidth: 60 },
    { id: 'confidence', name: 'Confidence', editable: false, deletable: false, filterable: true, defaultWidth: 100 },
  ];

  // Get subclasses for the selected class
  const getSelectedClassSubclasses = () => {
    if (!selectedClass || !project?.classes) return [];
    // Find the root class definition
    const rootClass = project.classes.find(c => c.name === selectedClass.name && !c.parentId);
    if (!rootClass) return [];
    // Find all subclasses of this root class
    return project.classes.filter(c => c.parentId === rootClass.id);
  };

  // Get custom columns for the selected class
  const getClassCustomColumns = () => {
    if (!selectedClass || !project?.classColumns) return [];
    const cols = project.classColumns[selectedClass.name] || [];
    // Add deletable, editable, filterable properties to custom columns
    return cols.map(col => ({
      ...col,
      editable: col.editable !== false,
      deletable: true,
      filterable: true,
      isCustom: true,
      defaultWidth: col.defaultWidth || 150
    }));
  };
  
  // Determine user columns based on whether class has subclasses
  const subclasses = getSelectedClassSubclasses();
  const userColumns = subclasses.length > 0
    ? subclasses.map(sub => ({
        id: `subclass_${sub.name}`,
        name: `${sub.name} (SUBCLASS)`,
        subclassName: sub.name,
        subclassId: sub.id,
        editable: true,
        deletable: true,
        filterable: true,
        defaultWidth: 150,
        isSubclass: true
      }))
    : [{ id: 'ocr_text', name: 'Tag', editable: true, deletable: false, filterable: true, defaultWidth: 150 }];
  
  // Computed columns: Tag/Subclasses + custom columns + end columns (Document, Page, Confidence)
  const customColumns = getClassCustomColumns();
  const columns = [...userColumns, ...customColumns, ...endColumns];

  // Get column width for current class
  const getColumnWidth = (columnId) => {
    if (!selectedClass) return 150;
    return classColumnWidths[selectedClass.name]?.[columnId] || columns.find(c => c.id === columnId)?.defaultWidth || 150;
  };

  // Get column alignment for current class
  const getColumnAlignment = (columnId) => {
    if (!selectedClass) return 'center';
    return columnAlignments[selectedClass.name]?.[columnId] || 'center';
  };

  // Toggle column alignment (left -> center -> right -> left)
  const toggleColumnAlignment = (columnId) => {
    if (!selectedClass) return;
    const currentAlign = getColumnAlignment(columnId);
    const nextAlign = currentAlign === 'left' ? 'center' : currentAlign === 'center' ? 'right' : 'left';
    setColumnAlignments(prev => ({
      ...prev,
      [selectedClass.name]: {
        ...(prev[selectedClass.name] || {}),
        [columnId]: nextAlign
      }
    }));
  };

  // All project classes (from project.classes)
  const allProjectClasses = project?.classes || [];
  
  // Get full class path (Parent > Child > Grandchild)
  const getClassPath = (cls) => {
    if (!cls) return '';
    const path = [cls.name];
    let current = cls;
    while (current.parentId) {
      const parent = allProjectClasses.find(c => c.id === current.parentId);
      if (parent) {
        path.unshift(parent.name);
        current = parent;
      } else {
        break;
      }
    }
    return path.join(' > ');
  };

  // Load project data
  useEffect(() => {
    const loadProject = async () => {
      try {
        const loadedProject = await getProject(projectId);
        
        if (loadedProject) {
          setProject(loadedProject);
          
          // Load detected objects from backend file
          try {
            const objects = await getObjectsFromBackend(projectId);
            if (objects.length > 0) {
              setDetectedObjects(objects);
            } else if (loadedProject.detectedObjects?.length > 0) {
              // Migration: load from project if backend file is empty
              setDetectedObjects(loadedProject.detectedObjects);
              // Migrate to backend
              await saveObjectsToBackend(projectId, loadedProject.detectedObjects);
              console.log('Migrated objects to backend file');
            }
          } catch (objError) {
            console.error('Error loading objects from backend:', objError);
            // Fallback to project.detectedObjects
            if (loadedProject.detectedObjects) {
              setDetectedObjects(loadedProject.detectedObjects);
            }
          }
          
          // Load per-class column widths if saved
          if (loadedProject.classColumnWidths) {
            setClassColumnWidths(loadedProject.classColumnWidths);
          }
        } else {
          navigate('/');
        }
      } catch (error) {
        console.error('Error loading project:', error);
        navigate('/');
      } finally {
        setIsLoading(false);
      }
    };

    loadProject();
  }, [projectId, navigate]);

  // Disable browser zoom on this page
  useEffect(() => {
    // Prevent ctrl+wheel zoom
    const preventZoom = (e) => {
      if (e.ctrlKey || e.metaKey) {
        e.preventDefault();
      }
    };
    
    // Prevent ctrl+plus/minus zoom
    const preventKeyZoom = (e) => {
      if ((e.ctrlKey || e.metaKey) && (e.key === '+' || e.key === '-' || e.key === '=' || e.key === '0')) {
        e.preventDefault();
      }
    };
    
    // Prevent pinch zoom on touch devices
    const preventTouchZoom = (e) => {
      if (e.touches.length > 1) {
        e.preventDefault();
      }
    };
    
    document.addEventListener('wheel', preventZoom, { passive: false });
    document.addEventListener('keydown', preventKeyZoom);
    document.addEventListener('touchmove', preventTouchZoom, { passive: false });
    
    // Set viewport meta to prevent zoom
    const viewport = document.querySelector('meta[name="viewport"]');
    const originalContent = viewport?.getAttribute('content');
    if (viewport) {
      viewport.setAttribute('content', 'width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no');
    }
    
    return () => {
      document.removeEventListener('wheel', preventZoom);
      document.removeEventListener('keydown', preventKeyZoom);
      document.removeEventListener('touchmove', preventTouchZoom);
      // Restore original viewport
      if (viewport && originalContent) {
        viewport.setAttribute('content', originalContent);
      }
    };
  }, []);

  // === PERFORMANCE: Initialize table height on mount and resize ===
  useEffect(() => {
    const updateTableHeight = () => {
      if (tableRef.current) {
        setTableHeight(tableRef.current.clientHeight);
      }
    };
    
    // Initial measurement
    updateTableHeight();
    
    // Update on window resize
    window.addEventListener('resize', updateTableHeight);
    
    // Use ResizeObserver for more accurate tracking
    const resizeObserver = new ResizeObserver(updateTableHeight);
    if (tableRef.current) {
      resizeObserver.observe(tableRef.current);
    }
    
    return () => {
      window.removeEventListener('resize', updateTableHeight);
      resizeObserver.disconnect();
    };
  }, [selectedClass]); // Re-run when selected class changes (table might resize)

  // Refresh data without losing current view
  const refreshData = async () => {
    try {
      const loadedProject = await getProject(projectId);
      if (loadedProject) {
        setProject(loadedProject);
        
        // Reload objects from backend
        try {
          const objects = await getObjectsFromBackend(projectId);
          setDetectedObjects(objects);
        } catch (objError) {
          console.error('Error refreshing objects:', objError);
        }
        
        // Update selected class if it still exists
        if (selectedClass) {
          const updatedClass = classes.find(c => c.name === selectedClass.name);
          setSelectedClass(updatedClass || null);
        }
        
        // Clear thumbnails cache to reload fresh
        setThumbnails({});
      }
    } catch (error) {
      console.error('Error refreshing data:', error);
    }
  };

  // Extract unique classes from detected objects
  const extractClasses = (proj, objects = []) => {
    if (objects.length === 0 && !proj?.classes) return [];
    
    const classMap = {};
    
    // First, add all class definitions from project.classes (these have shapeType, id, etc.)
    if (proj?.classes) {
      proj.classes.forEach(cls => {
        if (!cls.parentId) { // Only root classes
          classMap[cls.name] = {
            ...cls,
            count: 0,
            objects: []
          };
        }
      });
    }
    
    // Then count objects from detectedObjects
    objects.forEach(obj => {
      const className = obj.label || obj.className;
      if (className) {
        if (!classMap[className]) {
          classMap[className] = {
            name: className,
            count: 0,
            objects: []
          };
        }
        classMap[className].count++;
        classMap[className].objects.push(obj);
      }
    });
    
    return Object.values(classMap).sort((a, b) => a.name.localeCompare(b.name));
  };

  // Update classes when detectedObjects changes
  useEffect(() => {
    if (project) {
      const uniqueClasses = extractClasses(project, detectedObjects);
      setClasses(uniqueClasses);
    }
  }, [detectedObjects, project?.classes]);

  // Compute orphaned objects grouped by originalFilename
  const orphanedObjectsInfo = useMemo(() => {
    const orphaned = detectedObjects.filter(obj => obj.status === 'orphaned');
    const byFile = {};
    orphaned.forEach(obj => {
      const key = obj.originalFilename || 'Unknown';
      if (!byFile[key]) {
        byFile[key] = [];
      }
      byFile[key].push(obj);
    });
    return {
      total: orphaned.length,
      byFile,
      fileNames: Object.keys(byFile)
    };
  }, [detectedObjects]);

  // Get all available files for reassignment
  const allProjectFiles = useMemo(() => {
    if (!project) return [];
    const files = [];
    
    // Collect from folders
    const collectFiles = (folders) => {
      folders?.forEach(folder => {
        folder.files?.forEach(file => files.push(file));
        if (folder.subfolders) {
          collectFiles(folder.subfolders);
        }
      });
    };
    collectFiles(project.folders);
    
    // Add project-level files
    project.files?.forEach(file => files.push(file));
    
    return files;
  }, [project]);

  // Filter classes by search query
  const filteredClasses = classes.filter(cls => 
    cls.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Handle creating a new class
  const handleCreateClass = async () => {
    if (!newClassName.trim()) return;
    
    const name = newClassName.trim();
    
    // Check for duplicate class name (case-insensitive)
    if (newClassParentId) {
      // Creating a subclass - check for duplicate subclass names under this parent
      const existingSubclass = (project.classes || []).find(
        c => c.name.toLowerCase() === name.toLowerCase() && c.parentId === newClassParentId
      );
      
      if (existingSubclass) {
        alert(`A subclass named "${existingSubclass.name}" already exists under this class. Please choose a different name.`);
        return;
      }
    } else {
      // Creating a root class - check for duplicate root class names
      const existingClass = (project.classes || []).find(
        c => c.name.toLowerCase() === name.toLowerCase() && !c.parentId
      );
      
      if (existingClass) {
        alert(`A class named "${existingClass.name}" already exists. Please choose a different name.`);
        return;
      }
    }
    
    // Generate a default color based on class name
    const defaultColors = ['#3498db', '#e74c3c', '#2ecc71', '#f39c12', '#9b59b6', '#1abc9c', '#e67e22', '#34495e'];
    let hash = 0;
    for (let i = 0; i < name.length; i++) {
      hash = name.charCodeAt(i) + ((hash << 5) - hash);
    }
    const defaultColor = defaultColors[Math.abs(hash) % defaultColors.length];
    
    const newClass = {
      id: `class_${Date.now()}`,
      name: name,
      color: defaultColor,
      parentId: newClassParentId || null,
      count: 0,
      objects: [],
      created: new Date().toISOString()
    };
    
    // Build list of classes to add (main class + any pending subclasses)
    const classesToAdd = [newClass];
    
    // Add pending subclasses if this is a root class
    if (!newClassParentId && pendingSubclasses.length > 0) {
      pendingSubclasses.forEach((subName, idx) => {
        classesToAdd.push({
          id: `class_${Date.now()}_sub_${idx}`,
          name: subName,
          parentId: newClass.id,
          count: 0,
          objects: [],
          created: new Date().toISOString()
        });
      });
    }
    
    const updatedProject = {
      ...project,
      classes: [...(project.classes || []), ...classesToAdd]
    };
    
    setProject(updatedProject);
    setClasses(extractClasses(updatedProject));
    
    try {
      await saveProject(updatedProject);
    } catch (error) {
      console.error('Error saving class:', error);
    }
    
    setNewClassName('');
    setNewClassParentId(null);
    setPendingSubclasses([]);
    setNewSubclassInput('');
    setShowNewClassDialog(false);
    setSelectedClass(newClass);
  };

  // Handle deleting a class and all its objects
  const handleDeleteClass = async (className) => {
    const objectCount = detectedObjects.filter(
      obj => (obj.label || obj.className) === className
    ).length || 0;
    
    const message = objectCount > 0 
      ? `Are you sure you want to delete the class "${className}"?\n\nThis will DELETE all ${objectCount} object(s) in this class.`
      : `Are you sure you want to delete the class "${className}"?`;
    
    if (!confirm(message)) {
      return;
    }
    
    // Remove class columns for this class
    const updatedClassColumns = { ...(project.classColumns || {}) };
    delete updatedClassColumns[className];
    
    // Remove class definition from project
    const updatedProject = {
      ...project,
      classes: (project.classes || []).filter(c => c.name !== className),
      classColumns: updatedClassColumns
    };
    
    // Filter out objects with this class
    const updatedObjects = detectedObjects.filter(
      obj => (obj.label || obj.className) !== className
    );
    
    setProject(updatedProject);
    setDetectedObjects(updatedObjects);
    setSelectedClass(null);
    
    try {
      await saveProject(updatedProject);
      await saveObjectsToBackend(projectId, updatedObjects);
    } catch (error) {
      console.error('Error deleting class:', error);
    }
  };

  // Delete a single object
  const handleDeleteObject = async (objId) => {
    if (!confirm('Delete this object?')) {
      return;
    }
    
    const updatedObjects = detectedObjects.filter(obj => obj.id !== objId);
    
    setDetectedObjects(updatedObjects);
    
    // Clear thumbnail if exists
    if (thumbnails[objId]) {
      const newThumbnails = { ...thumbnails };
      delete newThumbnails[objId];
      setThumbnails(newThumbnails);
    }
    
    try {
      await saveObjectsToBackend(projectId, updatedObjects);
    } catch (error) {
      console.error('Error deleting object:', error);
    }
  };

  // Delete all filtered objects (currently visible in table)
  const handleDeleteFilteredObjects = async (filteredObjects) => {
    if (filteredObjects.length === 0) return;
    
    // Check if any filters are active
    const hasFilters = Object.values(columnFilters).some(v => v && v.trim());
    
    const message = hasFilters
      ? `Delete ${filteredObjects.length} filtered object(s)?\n\nThis will delete all currently filtered/visible objects.`
      : `Delete all ${filteredObjects.length} object(s) in this class?\n\nThis cannot be undone.`;
    
    if (!confirm(message)) {
      return;
    }
    
    const idsToDelete = new Set(filteredObjects.map(obj => obj.id));
    
    const updatedObjects = detectedObjects.filter(obj => !idsToDelete.has(obj.id));
    
    setDetectedObjects(updatedObjects);
    
    // Clear thumbnails for deleted objects
    const newThumbnails = { ...thumbnails };
    idsToDelete.forEach(id => delete newThumbnails[id]);
    setThumbnails(newThumbnails);
    
    try {
      await saveObjectsToBackend(projectId, updatedObjects);
    } catch (error) {
      console.error('Error deleting filtered objects:', error);
    }
  };

  // ============ Orphaned Object Handlers ============

  // Open reassign dialog for a specific source file
  const openReassignDialog = (sourceFilename) => {
    setReassignSourceFile(sourceFilename);
    setReassignTargetFile(null);
    setShowReassignDialog(true);
  };

  // Handle reassignment - keep existing boxes
  const handleReassignKeepBoxes = async () => {
    if (!reassignSourceFile || !reassignTargetFile) return;
    
    setIsReassigning(true);
    try {
      const updatedObjects = detectedObjects.map(obj => {
        if (obj.status === 'orphaned' && obj.originalFilename === reassignSourceFile) {
          return {
            ...obj,
            status: 'active',
            filename: reassignTargetFile.backendFilename,
            originalFilename: undefined // Clear originalFilename
          };
        }
        return obj;
      });
      
      setDetectedObjects(updatedObjects);
      await saveObjectsToBackend(projectId, updatedObjects);
      
      setShowReassignDialog(false);
      setReassignSourceFile(null);
      setReassignTargetFile(null);
    } catch (error) {
      console.error('Error reassigning objects:', error);
      alert('Failed to reassign objects: ' + error.message);
    } finally {
      setIsReassigning(false);
    }
  };

  // Handle reassignment - re-detect on new file
  const handleReassignRedetect = async () => {
    if (!reassignSourceFile || !reassignTargetFile) return;
    
    // Show confirmation warning
    const orphanedCount = orphanedObjectsInfo.byFile[reassignSourceFile]?.length || 0;
    const confirmed = confirm(
      `⚠️ Warning: Do you want to proceed?\n\nThis will permanently delete ${orphanedCount} orphaned object(s) from "${reassignSourceFile}" and open the Object Finder to re-detect on "${reassignTargetFile.name}".\n\nThis action cannot be undone.`
    );
    
    if (!confirmed) return;
    
    // First, permanently delete the orphaned objects
    const updatedObjects = detectedObjects.filter(
      obj => !(obj.status === 'orphaned' && obj.originalFilename === reassignSourceFile)
    );
    
    setDetectedObjects(updatedObjects);
    await saveObjectsToBackend(projectId, updatedObjects);
    
    setShowReassignDialog(false);
    setReassignSourceFile(null);
    setReassignTargetFile(null);
    
    // Navigate to the file for re-detection
    navigate(`/project/${projectId}`, {
      state: {
        returnToFile: reassignTargetFile,
        openObjectFinder: true
      }
    });
  };

  // Permanently delete all orphaned objects from a specific source file
  const handlePermanentDeleteOrphaned = async (sourceFilename) => {
    const count = orphanedObjectsInfo.byFile[sourceFilename]?.length || 0;
    
    if (!confirm(`Permanently delete ${count} orphaned object(s) from "${sourceFilename}"?\n\nThis cannot be undone.`)) {
      return;
    }
    
    const updatedObjects = detectedObjects.filter(
      obj => !(obj.status === 'orphaned' && obj.originalFilename === sourceFilename)
    );
    
    setDetectedObjects(updatedObjects);
    
    try {
      await saveObjectsToBackend(projectId, updatedObjects);
    } catch (error) {
      console.error('Error deleting orphaned objects:', error);
    }
  };

  // Permanently delete ALL orphaned objects
  const handlePermanentDeleteAllOrphaned = () => {
    setShowDeleteOrphanedDialog(true);
  };

  // Actually delete all orphaned objects (called from dialog)
  const confirmDeleteAllOrphaned = async () => {
    const updatedObjects = detectedObjects.filter(obj => obj.status !== 'orphaned');
    
    setDetectedObjects(updatedObjects);
    setShowDeleteOrphanedDialog(false);
    
    try {
      await saveObjectsToBackend(projectId, updatedObjects);
    } catch (error) {
      console.error('Error deleting all orphaned objects:', error);
    }
  };

  // Delete all orphaned and navigate to object finder for re-detection
  const deleteOrphanedAndRedetect = async () => {
    const updatedObjects = detectedObjects.filter(obj => obj.status !== 'orphaned');
    
    setDetectedObjects(updatedObjects);
    setShowDeleteOrphanedDialog(false);
    
    try {
      await saveObjectsToBackend(projectId, updatedObjects);
    } catch (error) {
      console.error('Error deleting all orphaned objects:', error);
    }
    
    // Navigate to project with object finder open
    navigate(`/project/${projectId}`, {
      state: {
        openObjectFinder: true
      }
    });
  };

  // Add custom column for current class
  const handleAddColumn = async () => {
    if (!newColumnName.trim() || !selectedClass) {
      console.log('handleAddColumn: early return - no name or no selectedClass');
      return;
    }
    
    const columnId = `custom_${Date.now()}`;
    const newColumn = {
      id: columnId,
      name: newColumnName.trim(),
      editable: true,
      deletable: true,
      filterable: true,
      isCustom: true,
      defaultWidth: 150
    };
    
    console.log('Adding column to class:', selectedClass.name, newColumn);
    
    // Get existing columns for this class
    const existingClassColumns = project?.classColumns?.[selectedClass.name] || [];
    const updatedClassColumns = [...existingClassColumns, newColumn];
    
    // Update project with new class columns
    const updatedProject = {
      ...project,
      classColumns: {
        ...(project.classColumns || {}),
        [selectedClass.name]: updatedClassColumns
      }
    };
    
    console.log('Updated classColumns:', updatedProject.classColumns);
    
    setProject(updatedProject);
    
    // Update per-class column widths
    const className = selectedClass.name;
    setClassColumnWidths(prev => ({
      ...prev,
      [className]: {
        ...(prev[className] || {}),
        [columnId]: 150
      }
    }));
    
    // Close dialog immediately
    setNewColumnName('');
    setShowAddColumnDialog(false);
    
    try {
      await saveProject(updatedProject);
      console.log('Column saved successfully');
    } catch (error) {
      console.error('Error saving column:', error);
    }
  };

  // Add subclass to current class
  const handleAddSubclass = async () => {
    if (!newSubclassName.trim() || !selectedClass) return;
    
    const subName = newSubclassName.trim();
    
    // Check for duplicate
    const existingSubclasses = getSelectedClassSubclasses();
    if (existingSubclasses.some(s => s.name.toLowerCase() === subName.toLowerCase())) {
      alert(`Subclass "${subName}" already exists.`);
      return;
    }
    
    // Find the root class to get its ID
    const rootClass = project.classes?.find(c => c.name === selectedClass.name && !c.parentId);
    const parentId = rootClass?.id || selectedClass.id;
    
    const newSubclass = {
      id: `class_${Date.now()}_sub`,
      name: subName,
      parentId: parentId,
      created: new Date().toISOString()
    };
    
    const updatedProject = {
      ...project,
      classes: [...(project.classes || []), newSubclass]
    };
    
    setProject(updatedProject);
    
    // Close dialog immediately
    setNewSubclassName('');
    setShowAddSubclassDialog(false);
    
    try {
      await saveProject(updatedProject);
    } catch (error) {
      console.error('Error saving subclass:', error);
    }
  };

  // Delete custom column for current class
  const handleDeleteColumn = async (columnId) => {
    if (!selectedClass) return;
    
    const column = columns.find(c => c.id === columnId);
    if (!confirm(`Are you sure you want to delete the column "${column?.name}"?`)) {
      return;
    }
    
    // Check if this is a subclass column
    if (column?.isSubclass && column?.subclassId) {
      // Remove the subclass from project.classes
      const updatedClasses = (project.classes || []).filter(c => c.id !== column.subclassId);
      
      // Remove subclass data from objects
      const subclassName = column.subclassName;
      const updatedObjects = detectedObjects.map(obj => {
        if ((obj.label || obj.className) === selectedClass.name && obj.subclassValues) {
          const newSubclassValues = { ...obj.subclassValues };
          delete newSubclassValues[subclassName];
          return { ...obj, subclassValues: newSubclassValues };
        }
        return obj;
      });
      
      // Update per-class column widths
      const className = selectedClass.name;
      const newClassColumnWidths = { ...classColumnWidths };
      if (newClassColumnWidths[className]) {
        delete newClassColumnWidths[className][columnId];
      }
      
      const updatedProject = {
        ...project,
        classes: updatedClasses,
        classColumnWidths: newClassColumnWidths
      };
      
      setProject(updatedProject);
      setDetectedObjects(updatedObjects);
      setClassColumnWidths(newClassColumnWidths);
      
      try {
        await saveProject(updatedProject);
        await saveObjectsToBackend(projectId, updatedObjects);
      } catch (error) {
        console.error('Error deleting subclass:', error);
      }
      return;
    }
    
    // Regular custom column deletion
    // Get existing columns for this class and filter out the deleted one
    const existingClassColumns = project?.classColumns?.[selectedClass.name] || [];
    const updatedClassColumns = existingClassColumns.filter(c => c.id !== columnId);
    
    // Also remove this column's data from objects of this class
    const updatedObjects = detectedObjects.map(obj => {
      if ((obj.label || obj.className) === selectedClass.name) {
        const newObj = { ...obj };
        delete newObj[columnId];
        return newObj;
      }
      return obj;
    });
    
    // Update per-class column widths
    const className = selectedClass.name;
    const newClassColumnWidths = { ...classColumnWidths };
    if (newClassColumnWidths[className]) {
      delete newClassColumnWidths[className][columnId];
    }
    
    const updatedProject = {
      ...project,
      classColumns: {
        ...(project.classColumns || {}),
        [selectedClass.name]: updatedClassColumns
      },
      classColumnWidths: newClassColumnWidths
    };
    setProject(updatedProject);
    setDetectedObjects(updatedObjects);
    setClassColumnWidths(newClassColumnWidths);
    
    try {
      await saveProject(updatedProject);
      await saveObjectsToBackend(projectId, updatedObjects);
    } catch (error) {
      console.error('Error deleting column:', error);
    }
  };

  // Column resize handlers
  const handleResizeStart = (e, columnId) => {
    if (!selectedClass) return;
    e.preventDefault();
    setResizingColumn(columnId);
    
    const className = selectedClass.name;
    const startX = e.clientX;
    const startWidth = getColumnWidth(columnId);
    let currentWidth = startWidth;
    
    const handleMouseMove = (moveEvent) => {
      const diff = moveEvent.clientX - startX;
      currentWidth = Math.max(80, startWidth + diff);
      setClassColumnWidths(prev => ({
        ...prev,
        [className]: {
          ...(prev[className] || {}),
          [columnId]: currentWidth
        }
      }));
    };
    
    const handleMouseUp = async () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
      setResizingColumn(null);
      
      // Save per-class column widths
      const newClassColumnWidths = {
        ...classColumnWidths,
        [className]: {
          ...(classColumnWidths[className] || {}),
          [columnId]: currentWidth
        }
      };
      const updatedProject = {
        ...project,
        classColumnWidths: newClassColumnWidths
      };
      setProject(updatedProject);
      try {
        await saveProject(updatedProject);
      } catch (error) {
        console.error('Error saving column widths:', error);
      }
    };
    
    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseUp);
  };

  // Start editing a cell
  const startEditing = (objId, columnId, currentValue) => {
    setEditingCell({ rowId: objId, column: columnId });
    setEditValue(currentValue || '');
  };

  // Save cell edit
  const saveEdit = async () => {
    if (!editingCell) return;
    
    const updatedObjects = detectedObjects.map(obj => {
      if (obj.id === editingCell.rowId) {
        // Check if this is a subclass column
        if (editingCell.column.startsWith('subclass_')) {
          const subclassName = editingCell.column.replace('subclass_', '');
          return {
            ...obj,
            subclassValues: {
              ...(obj.subclassValues || {}),
              [subclassName]: editValue
            }
          };
        }
        // Regular column
        return { ...obj, [editingCell.column]: editValue };
      }
      return obj;
    });
    
    setDetectedObjects(updatedObjects);
    
    try {
      await saveObjectsToBackend(projectId, updatedObjects);
    } catch (error) {
      console.error('Error saving edit:', error);
    }
    
    setEditingCell(null);
    setEditValue('');
  };

  // Cancel edit
  const cancelEdit = () => {
    setEditingCell(null);
    setEditValue('');
  };

  // Sidebar resize handlers
  const handleSidebarMouseDown = (e) => {
    e.preventDefault();
    setIsResizingSidebar(true);
    document.body.style.userSelect = 'none';
  };

  useEffect(() => {
    const handleMouseMove = (e) => {
      if (isResizingSidebar) {
        const newWidth = Math.max(320, Math.min(500, e.clientX));
        setSidebarWidth(newWidth);
      }
    };

    const handleMouseUp = () => {
      setIsResizingSidebar(false);
      document.body.style.userSelect = '';
    };

    if (isResizingSidebar) {
      document.addEventListener('mousemove', handleMouseMove);
      document.addEventListener('mouseup', handleMouseUp);
    }

    return () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
    };
  }, [isResizingSidebar]);

  // Handle key press in edit mode
  const handleEditKeyPress = (e) => {
    if (e.key === 'Enter') {
      saveEdit();
    } else if (e.key === 'Escape') {
      cancelEdit();
    }
  };

  // Navigate to object in PDF viewer
  const handleFindObject = (obj) => {
    navigate(`/project/${projectId}`, { 
      state: { 
        navigateToObject: obj 
      } 
    });
  };

  // Get cell value for display
  const getCellValue = (obj, column) => {
    // Handle subclass columns - get value from subclassValues map
    if (column.isSubclass) {
      const subclassValues = obj.subclassValues || {};
      // Use subclassName (the actual key) not column.name (which has " (SUBCLASS)" suffix)
      return subclassValues[column.subclassName] || '-';
    }
    
    switch (column.id) {
      case 'filename':
        return obj.filename?.replace('.pdf', '') || '-';
      case 'page':
        return obj.page || 1;
      case 'confidence':
        return obj.confidence ? `${(obj.confidence * 100).toFixed(0)}%` : '-';
      case 'ocr_confidence':
        // OCR confidence is now a numeric value from PaddleOCR (0.0 - 1.0)
        if (typeof obj.ocr_confidence === 'number') {
          return `${(obj.ocr_confidence * 100).toFixed(0)}%`;
        }
        return obj.ocr_confidence || '-';
      case 'bbox_x':
        return obj.bbox?.x !== undefined ? obj.bbox.x.toFixed(6) : '-';
      case 'bbox_y':
        return obj.bbox?.y !== undefined ? obj.bbox.y.toFixed(6) : '-';
      case 'bbox_width':
        return obj.bbox?.width !== undefined ? obj.bbox.width.toFixed(6) : '-';
      case 'bbox_height':
        return obj.bbox?.height !== undefined ? obj.bbox.height.toFixed(6) : '-';
      default:
        return obj[column.id] || '-';
    }
  };

  // Get raw cell value for filtering
  const getRawCellValue = useCallback((obj, columnId) => {
    // Handle subclass columns
    if (columnId.startsWith('subclass_')) {
      const subclassName = columnId.replace('subclass_', '');
      const subclassValues = obj.subclassValues || {};
      return subclassValues[subclassName] || '';
    }
    
    switch (columnId) {
      case 'filename':
        // For orphaned objects, use originalFilename for filtering
        if (obj.status === 'orphaned') {
          return obj.originalFilename?.replace('.pdf', '') || '';
        }
        return obj.filename?.replace('.pdf', '') || '';
      case 'page':
        return String(obj.page || 1);
      case 'confidence':
        return obj.confidence ? `${(obj.confidence * 100).toFixed(0)}%` : '';
      case 'ocr_confidence':
        if (typeof obj.ocr_confidence === 'number') {
          return `${(obj.ocr_confidence * 100).toFixed(0)}%`;
        }
        return obj.ocr_confidence || '';
      case 'bbox_x':
        return obj.bbox?.x !== undefined ? obj.bbox.x.toFixed(6) : '';
      case 'bbox_y':
        return obj.bbox?.y !== undefined ? obj.bbox.y.toFixed(6) : '';
      case 'bbox_width':
        return obj.bbox?.width !== undefined ? obj.bbox.width.toFixed(6) : '';
      case 'bbox_height':
        return obj.bbox?.height !== undefined ? obj.bbox.height.toFixed(6) : '';
      default:
        return obj[columnId] || '';
    }
  }, []);

  // === PERFORMANCE: Memoized class data with filtering ===
  const classData = useMemo(() => {
    if (!selectedClass) return [];
    
    let data = detectedObjects.filter(
      obj => (obj.label || obj.className) === selectedClass.name
    );
    
    // Apply column filters
    Object.entries(columnFilters).forEach(([columnId, filterValue]) => {
      if (filterValue !== undefined && filterValue !== null && filterValue !== '') {
        // Special case: filter for empty/blank values
        if (filterValue === ' ' || filterValue.toLowerCase() === '(empty)' || filterValue.toLowerCase() === 'empty') {
          data = data.filter(obj => {
            const cellValue = getRawCellValue(obj, columnId);
            return cellValue === '' || cellValue === null || cellValue === undefined || cellValue === '-';
          });
        }
        // Numeric comparison for confidence columns (e.g., ">0.5", "<0.8", ">=0.9")
        else if ((columnId === 'confidence' || columnId === 'ocr_confidence') && /^[<>]=?\d/.test(filterValue.trim())) {
          const match = filterValue.trim().match(/^([<>]=?)(\d*\.?\d+)/);
          if (match) {
            const operator = match[1];
            const threshold = parseFloat(match[2]);
            data = data.filter(obj => {
              let cellValue = obj[columnId];
              if (typeof cellValue === 'string' && cellValue.endsWith('%')) {
                cellValue = parseFloat(cellValue) / 100;
              } else {
                cellValue = parseFloat(cellValue) || 0;
              }
              switch (operator) {
                case '>': return cellValue > threshold;
                case '>=': return cellValue >= threshold;
                case '<': return cellValue < threshold;
                case '<=': return cellValue <= threshold;
                default: return true;
              }
            });
          }
        }
        // Standard text search
        else if (filterValue.trim()) {
          const searchTerm = filterValue.toLowerCase().trim();
          data = data.filter(obj => {
            const cellValue = getRawCellValue(obj, columnId);
            return String(cellValue).toLowerCase().includes(searchTerm);
          });
        }
      }
    });
    
    return data;
  }, [selectedClass, detectedObjects, columnFilters, getRawCellValue]);

  // === Equipment Registry: Build filter options and tag data ===
  
  // Get all available filter options (classes and their subclasses)
  const registryFilterOptions = useMemo(() => {
    const options = [{ value: 'all', label: 'All Tags' }];
    
    // Get root classes (no parentId)
    const rootClasses = (project?.classes || []).filter(c => !c.parentId);
    
    rootClasses.forEach(cls => {
      // Add the class itself
      options.push({ value: cls.name, label: cls.name, type: 'class' });
      
      // Find subclasses
      const subs = (project?.classes || []).filter(c => c.parentId === cls.id);
      subs.forEach(sub => {
        options.push({ 
          value: `subclass:${cls.name}:${sub.name}`, 
          label: `  └ ${sub.name}`, 
          type: 'subclass',
          parentClass: cls.name,
          subclassName: sub.name
        });
      });
    });
    
    return options;
  }, [project?.classes]);

  // Get tags based on current filter
  const registryTags = useMemo(() => {
    const tags = {};
    
    detectedObjects.forEach(obj => {
      const className = obj.label || obj.className;
      
      // Check if this object matches the filter
      if (registryFilter !== 'all') {
        if (registryFilter.startsWith('subclass:')) {
          // Filter by specific subclass - skip for now, handled below
          const [, parentClass] = registryFilter.split(':');
          if (className !== parentClass) return;
        } else {
          // Filter by class
          if (className !== registryFilter) return;
        }
      }
      
      // If filtering by subclass, extract tags from that subclass only
      if (registryFilter.startsWith('subclass:')) {
        const [, , subclassName] = registryFilter.split(':');
        const subVal = obj.subclassValues?.[subclassName];
        if (subVal && subVal.trim()) {
          const tag = subVal.trim();
          if (!tags[tag]) {
            tags[tag] = { tag, occurrences: [] };
          }
          tags[tag].occurrences.push({
            objectId: obj.id,
            className,
            filename: obj.filename?.replace('.pdf', '') || 'Unknown',
            page: obj.pageNumber || 1,
            confidence: obj.confidence,
            subclassValues: obj.subclassValues,
            customData: obj.customData,
            obj // Keep reference to full object for column access
          });
        }
      } else {
        // For class filter or 'all', use ocr_text or all subclass values
        const tagsToAdd = [];
        
        if (obj.ocr_text && obj.ocr_text.trim()) {
          tagsToAdd.push(obj.ocr_text.trim());
        }
        
        // Also add subclass values as tags
        if (obj.subclassValues) {
          Object.values(obj.subclassValues).forEach(val => {
            if (val && val.trim()) {
              tagsToAdd.push(val.trim());
            }
          });
        }
        
        tagsToAdd.forEach(tag => {
          if (!tags[tag]) {
            tags[tag] = { tag, occurrences: [] };
          }
          tags[tag].occurrences.push({
            objectId: obj.id,
            className,
            filename: obj.filename?.replace('.pdf', '') || 'Unknown',
            page: obj.pageNumber || 1,
            confidence: obj.confidence,
            subclassValues: obj.subclassValues,
            customData: obj.customData,
            obj
          });
        });
      }
    });
    
    return Object.values(tags).sort((a, b) => a.tag.localeCompare(b.tag));
  }, [detectedObjects, registryFilter]);

  // Smart Search - search across ALL objects and ALL columns
  const smartSearchResults = useMemo(() => {
    if (!registrySearchQuery.trim()) return null;
    
    const search = registrySearchQuery.toLowerCase().trim();
    const results = [];
    
    // Search through all detected objects
    detectedObjects.forEach(obj => {
      const matches = [];
      const className = obj.label || obj.className || obj.class_name;
      
      // Search in tag/ocr_text
      if (obj.ocr_text && obj.ocr_text.toLowerCase().includes(search)) {
        matches.push({ field: 'Tag', value: obj.ocr_text });
      }
      
      // Search in subclass values
      if (obj.subclassValues) {
        Object.entries(obj.subclassValues).forEach(([subName, subValue]) => {
          if (subValue && subValue.toLowerCase().includes(search)) {
            matches.push({ field: subName, value: subValue });
          }
        });
      }
      
      // Search in ALL custom columns for this class
      // Custom column values are stored directly on the object as obj[col.id]
      const customCols = project?.classColumns?.[className] || [];
      customCols.forEach(col => {
        // Check direct object property first (main storage location)
        const value = obj[col.id];
        if (value && value.toString().toLowerCase().includes(search)) {
          matches.push({ field: col.name, value: value });
        }
        // Also check customData object (alternative storage)
        else if (obj.customData?.[col.id]) {
          const cdValue = obj.customData[col.id];
          if (cdValue && cdValue.toString().toLowerCase().includes(search)) {
            matches.push({ field: col.name, value: cdValue });
          }
        }
      });
      
      // Search in filename
      const filename = obj.originalFilename?.replace('.pdf', '') || obj.filename?.replace('.pdf', '') || '';
      if (filename.toLowerCase().includes(search)) {
        matches.push({ field: 'Document', value: filename });
      }
      
      if (matches.length > 0) {
        results.push({
          obj,
          className,
          filename: obj.filename?.replace('.pdf', '') || obj.originalFilename?.replace('.pdf', '') || 'Unknown',
          page: obj.page || 1,
          matches,
          // Include all data for display
          tag: obj.ocr_text || '',
          subclassValues: obj.subclassValues || {},
          customData: obj.customData || {},
          confidence: obj.confidence
        });
      }
    });
    
    // Group by class - filter out undefined class names
    const byClass = {};
    results.forEach(result => {
      const clsName = result.className || 'Unknown';
      if (!byClass[clsName]) {
        byClass[clsName] = [];
      }
      byClass[clsName].push(result);
    });
    
    return {
      query: registrySearchQuery,
      totalCount: results.length,
      byClass
    };
  }, [registrySearchQuery, detectedObjects, project?.classColumns]);

  // Filter tags by search
  const filteredRegistryTags = useMemo(() => {
    if (!registrySearchQuery.trim()) return registryTags;
    const search = registrySearchQuery.toLowerCase();
    return registryTags.filter(item => item.tag.toLowerCase().includes(search));
  }, [registryTags, registrySearchQuery]);

  // Get occurrences for selected tag, grouped by class
  const selectedTagData = useMemo(() => {
    if (!selectedTag) return null;
    const tagItem = registryTags.find(t => t.tag === selectedTag);
    if (!tagItem) return null;
    
    // Group occurrences by class
    const byClass = {};
    tagItem.occurrences.forEach(occ => {
      if (!byClass[occ.className]) {
        byClass[occ.className] = [];
      }
      byClass[occ.className].push(occ);
    });
    
    return {
      tag: tagItem.tag,
      totalCount: tagItem.occurrences.length,
      byClass
    };
  }, [selectedTag, registryTags]);

  // Get columns for a specific class (for registry view)
  const getColumnsForClass = useCallback((className) => {
    const rootClass = (project?.classes || []).find(c => c.name === className && !c.parentId);
    const subclasses = rootClass 
      ? (project?.classes || []).filter(c => c.parentId === rootClass.id)
      : [];
    
    const cols = [];
    
    // Tag or Subclass columns first
    if (subclasses.length > 0) {
      subclasses.forEach(sub => {
        cols.push({ id: `subclass_${sub.name}`, name: sub.name, isSubclass: true, subclassName: sub.name });
      });
    } else {
      cols.push({ id: 'ocr_text', name: 'Tag' });
    }
    
    // Add custom columns for this class
    const customCols = project?.classColumns?.[className] || [];
    customCols.forEach(col => {
      cols.push({ id: col.id, name: col.name, isCustom: true });
    });
    
    // Document, Page, Confidence at the end
    cols.push({ id: 'filename', name: 'Document' });
    cols.push({ id: 'page', name: 'Page' });
    cols.push({ id: 'confidence', name: 'Confidence' });
    
    return cols;
  }, [project?.classes, project?.classColumns]);

  // Get cell value for registry table
  const getRegistryCellValue = useCallback((occ, columnId) => {
    if (columnId === 'filename') return occ.filename;
    if (columnId === 'page') return occ.page;
    if (columnId === 'confidence') return occ.confidence ? `${(occ.confidence * 100).toFixed(0)}%` : '-';
    if (columnId === 'ocr_text') return occ.obj?.ocr_text || '-';
    if (columnId.startsWith('subclass_')) {
      const subName = columnId.replace('subclass_', '');
      return occ.subclassValues?.[subName] || '-';
    }
    // Custom columns
    return occ.customData?.[columnId] || occ.obj?.[columnId] || '-';
  }, []);

  // === PERFORMANCE: Calculate visible row range for virtualization ===
  const { visibleStartIndex, visibleEndIndex, totalHeight } = useMemo(() => {
    const totalRows = classData.length;
    const totalHeight = totalRows * ROW_HEIGHT;
    
    const startIndex = Math.max(0, Math.floor(tableScrollTop / ROW_HEIGHT) - BUFFER_ROWS);
    const visibleRowCount = Math.ceil(tableHeight / ROW_HEIGHT) + (BUFFER_ROWS * 2);
    const endIndex = Math.min(totalRows, startIndex + visibleRowCount);
    
    return {
      visibleStartIndex: startIndex,
      visibleEndIndex: endIndex,
      totalHeight
    };
  }, [classData.length, tableScrollTop, tableHeight, ROW_HEIGHT, BUFFER_ROWS]);

  // Get only the visible rows
  const visibleRows = useMemo(() => {
    return classData.slice(visibleStartIndex, visibleEndIndex);
  }, [classData, visibleStartIndex, visibleEndIndex]);

  // Legacy function wrapper for compatibility with existing code
  const getClassData = useCallback(() => classData, [classData]);

  // Load thumbnail for an object
  const loadThumbnail = async (obj) => {
    if (!obj?.id || !obj?.filename || !obj?.bbox) return;
    if (thumbnails[obj.id] || loadingThumbnails[obj.id]) return;
    
    setLoadingThumbnails(prev => ({ ...prev, [obj.id]: true }));
    
    try {
      // Pass detected_rotation and detected_inverted so backend can normalize thumbnail
      const thumbnail = await getThumbnail(
        obj.filename, 
        obj.page || 0, 
        obj.bbox, 
        obj.detected_rotation || 0,
        obj.detected_inverted || false
      );
      setThumbnails(prev => ({ ...prev, [obj.id]: thumbnail }));
    } catch (error) {
      console.error('Failed to load thumbnail:', error);
      setThumbnails(prev => ({ ...prev, [obj.id]: null }));
    } finally {
      setLoadingThumbnails(prev => ({ ...prev, [obj.id]: false }));
    }
  };

  // Update column filter
  const handleFilterChange = (columnId, value) => {
    setColumnFilters(prev => ({
      ...prev,
      [columnId]: value
    }));
  };

  // Export to CSV (class-specific, but import-compatible)
  const handleExportCSV = () => {
    const data = getClassData();
    if (data.length === 0) {
      alert('No data to export');
      return;
    }
    
    // Get defined subclasses for this class from project.classes
    const definedSubclasses = getSelectedClassSubclasses().map(s => s.name);
    
    // Get defined custom columns for this class from project.classColumns (need both id and name)
    const definedCustomColumns = (project?.classColumns?.[selectedClass.name] || []);
    
    // Build headers (import-compatible format) - use human-readable names with prefixes
    const headers = [
      'id', 'className', 'label', 'ocr_text', 'filename', 'page', 'confidence', 'ocr_confidence', 'shapeType', 'isManual',
      'bbox_x', 'bbox_y', 'bbox_width', 'bbox_height',
      ...definedSubclasses.map(k => `subclass_${k}`),
      ...definedCustomColumns.map(c => `column_${c.name}`)
    ];
    
    // Build rows
    const rows = data.map(obj => {
      const row = [
        obj.id || '',
        obj.className || '',
        obj.label || '',
        obj.ocr_text || '',
        obj.filename || '',
        obj.page ?? '',
        obj.confidence ?? '',
        obj.ocr_confidence ?? '',
        obj.shapeType || 'rectangle',
        obj.isManual ? 'true' : 'false',
        obj.bbox?.x ?? '',
        obj.bbox?.y ?? '',
        obj.bbox?.width ?? '',
        obj.bbox?.height ?? '',
        ...definedSubclasses.map(k => obj.subclassValues?.[k] || ''),
        ...definedCustomColumns.map(c => obj[c.id] || '')
      ];
      
      // Escape and quote values
      return row.map(v => {
        const str = String(v);
        if (str.includes(',') || str.includes('"') || str.includes('\n')) {
          return `"${str.replace(/"/g, '""')}"`;
        }
        return str;
      }).join(',');
    });
    
    const csv = [headers.join(','), ...rows].join('\n');
    
    // Download
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `${selectedClass.name}_export.csv`;
    link.click();
    URL.revokeObjectURL(link.href);
  };

  // Export ALL objects as JSON
  const handleExportAllJSON = () => {
    if (detectedObjects.length === 0) {
      alert('No objects to export');
      return;
    }
    
    // Get all defined subclasses
    const definedSubclasses = (project.classes || [])
      .filter(c => c.parentId)
      .map(c => ({ name: c.name, parentId: c.parentId }));
    
    // Get all defined custom columns
    const definedColumns = project.classColumns || {};
    
    const exportData = {
      projectId,
      projectName: project?.name || 'Unknown',
      exportDate: new Date().toISOString(),
      objectCount: detectedObjects.length,
      // Include structure for reference
      structure: {
        subclasses: definedSubclasses,
        customColumns: definedColumns
      },
      objects: detectedObjects
    };
    
    const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `${project?.name || 'objects'}_export.json`;
    link.click();
    URL.revokeObjectURL(link.href);
  };

  // Export ALL objects as CSV
  const handleExportAllCSV = () => {
    if (detectedObjects.length === 0) {
      alert('No objects to export');
      return;
    }
    
    // Get all defined subclasses from project.classes
    const allSubclasses = [];
    (project.classes || []).forEach(cls => {
      if (cls.parentId) {
        allSubclasses.push(cls.name);
      }
    });
    
    // Get all defined custom columns from project.classColumns (need id and name)
    const allCustomColumns = [];
    const seenColumnNames = new Set();
    Object.values(project.classColumns || {}).forEach(cols => {
      cols.forEach(col => {
        // Avoid duplicates by name
        if (!seenColumnNames.has(col.name)) {
          seenColumnNames.add(col.name);
          allCustomColumns.push({ id: col.id, name: col.name });
        }
      });
    });
    
    // Build headers with human-readable names
    const headers = [
      'id', 'className', 'label', 'ocr_text', 'filename', 'page', 'confidence', 'ocr_confidence', 'shapeType', 'isManual',
      'bbox_x', 'bbox_y', 'bbox_width', 'bbox_height',
      ...allSubclasses.map(k => `subclass_${k}`),
      ...allCustomColumns.map(c => `column_${c.name}`)
    ];
    
    // Build rows
    const rows = detectedObjects.map(obj => {
      const row = [
        obj.id || '',
        obj.className || '',
        obj.label || '',
        obj.ocr_text || '',
        obj.filename || '',
        obj.page ?? '',
        obj.confidence ?? '',
        obj.ocr_confidence ?? '',
        obj.shapeType || 'rectangle',
        obj.isManual ? 'true' : 'false',
        obj.bbox?.x ?? '',
        obj.bbox?.y ?? '',
        obj.bbox?.width ?? '',
        obj.bbox?.height ?? '',
        ...allSubclasses.map(k => obj.subclassValues?.[k] || ''),
        ...allCustomColumns.map(c => obj[c.id] || '')
      ];
      
      // Escape and quote values
      return row.map(v => {
        const str = String(v);
        if (str.includes(',') || str.includes('"') || str.includes('\n')) {
          return `"${str.replace(/"/g, '""')}"`;
        }
        return str;
      }).join(',');
    });
    
    const csv = [headers.join(','), ...rows].join('\n');
    
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `${project?.name || 'objects'}_all_export.csv`;
    link.click();
    URL.revokeObjectURL(link.href);
  };

  // Handle file selection for import
  const handleFileSelect = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target.result;
      
      try {
        if (file.name.endsWith('.json')) {
          const data = JSON.parse(content);
          // Validate JSON structure
          const objects = data.objects || data;
          if (!Array.isArray(objects)) {
            throw new Error('Invalid JSON format: expected an array of objects or {objects: [...]}');
          }
          // Validate each object has required fields
          const validObjects = objects.filter(obj => obj.id || obj.className || obj.label);
          if (validObjects.length === 0) {
            throw new Error('No valid objects found. Each object needs at least id, className, or label.');
          }
          setImportData({ format: 'json', objects: validObjects, fileName: file.name });
          setImportError(null);
        } else if (file.name.endsWith('.csv')) {
          // Parse CSV
          const lines = content.split('\n').filter(line => line.trim());
          if (lines.length < 2) {
            throw new Error('CSV file must have a header row and at least one data row');
          }
          
          // Parse header
          const headers = parseCSVLine(lines[0]);
          
          // Parse data rows
          const objects = [];
          for (let i = 1; i < lines.length; i++) {
            const values = parseCSVLine(lines[i]);
            if (values.length !== headers.length) continue;
            
            const obj = {};
            headers.forEach((header, idx) => {
              const value = values[idx];
              if (value === '') return;
              
              // Handle special columns
              if (header === 'bbox_x') {
                obj.bbox = obj.bbox || {};
                obj.bbox.x = parseFloat(value);
              } else if (header === 'bbox_y') {
                obj.bbox = obj.bbox || {};
                obj.bbox.y = parseFloat(value);
              } else if (header === 'bbox_width') {
                obj.bbox = obj.bbox || {};
                obj.bbox.width = parseFloat(value);
              } else if (header === 'bbox_height') {
                obj.bbox = obj.bbox || {};
                obj.bbox.height = parseFloat(value);
              } else if (header.startsWith('subclass_')) {
                const subclassName = header.replace('subclass_', '');
                obj.subclassValues = obj.subclassValues || {};
                obj.subclassValues[subclassName] = value;
              } else if (header.startsWith('column_')) {
                // Custom column - store by name, will be matched to ID on import
                const columnName = header.replace('column_', '');
                obj._customColumnsByName = obj._customColumnsByName || {};
                obj._customColumnsByName[columnName] = value;
              } else if (header === 'page') {
                obj.page = parseInt(value, 10);
              } else if (header === 'confidence') {
                obj.confidence = parseFloat(value);
              } else if (header === 'ocr_confidence') {
                obj.ocr_confidence = parseFloat(value);
              } else if (header === 'isManual') {
                obj.isManual = value === 'true';
              } else {
                obj[header] = value;
              }
            });
            
            // Generate ID if missing
            if (!obj.id) {
              obj.id = `imported_${Date.now()}_${i}`;
            }
            
            if (obj.className || obj.label) {
              objects.push(obj);
            }
          }
          
          if (objects.length === 0) {
            throw new Error('No valid objects found in CSV');
          }
          
          setImportData({ format: 'csv', objects, fileName: file.name });
          setImportError(null);
        } else {
          throw new Error('Unsupported file format. Please use .json or .csv');
        }
        
        setShowImportDialog(true);
      } catch (error) {
        setImportError(error.message);
        setImportData(null);
        setShowImportDialog(true);
      }
    };
    
    reader.readAsText(file);
    // Reset input so same file can be selected again
    e.target.value = '';
  };

  // Parse a CSV line handling quoted values
  const parseCSVLine = (line) => {
    const result = [];
    let current = '';
    let inQuotes = false;
    
    for (let i = 0; i < line.length; i++) {
      const char = line[i];
      
      if (inQuotes) {
        if (char === '"' && line[i + 1] === '"') {
          current += '"';
          i++;
        } else if (char === '"') {
          inQuotes = false;
        } else {
          current += char;
        }
      } else {
        if (char === '"') {
          inQuotes = true;
        } else if (char === ',') {
          result.push(current.trim());
          current = '';
        } else {
          current += char;
        }
      }
    }
    result.push(current.trim());
    return result;
  };

  // Execute import
  const handleImport = async () => {
    if (!importData?.objects) return;
    
    try {
      // Get all valid subclass names from project.classes
      const validSubclasses = new Set();
      (project.classes || []).forEach(cls => {
        if (cls.parentId) {
          validSubclasses.add(cls.name);
        }
      });
      
      // Build map of column name -> column ID for all classes
      const columnNameToId = new Map();
      Object.values(project.classColumns || {}).forEach(cols => {
        cols.forEach(col => {
          columnNameToId.set(col.name, col.id);
        });
      });
      
      // Filter imported objects to only include valid columns
      const filteredObjects = importData.objects.map(obj => {
        const filtered = { ...obj };
        
        // Filter subclassValues to only include valid subclasses
        if (filtered.subclassValues) {
          const validSubclassValues = {};
          Object.entries(filtered.subclassValues).forEach(([key, value]) => {
            if (validSubclasses.has(key)) {
              validSubclassValues[key] = value;
            }
          });
          filtered.subclassValues = Object.keys(validSubclassValues).length > 0 ? validSubclassValues : undefined;
        }
        
        // Convert _customColumnsByName to actual column IDs
        if (filtered._customColumnsByName) {
          Object.entries(filtered._customColumnsByName).forEach(([colName, value]) => {
            const colId = columnNameToId.get(colName);
            if (colId) {
              filtered[colId] = value;
            }
          });
          delete filtered._customColumnsByName;
        }
        
        // Remove old-style custom columns that don't exist anymore (legacy support)
        Object.keys(filtered).forEach(key => {
          if (key.startsWith('custom_') && !columnNameToId.has(key) && ![...columnNameToId.values()].includes(key)) {
            delete filtered[key];
          }
        });
        
        return filtered;
      });
      
      let newObjects;
      
      if (importMode === 'replace') {
        // Replace all objects
        newObjects = filteredObjects;
      } else {
        // Merge: add new objects, update existing by id
        const existingById = new Map(detectedObjects.map(obj => [obj.id, obj]));
        
        filteredObjects.forEach(importObj => {
          existingById.set(importObj.id, { ...existingById.get(importObj.id), ...importObj });
        });
        
        newObjects = Array.from(existingById.values());
      }
      
      setDetectedObjects(newObjects);
      await saveObjectsToBackend(projectId, newObjects);
      
      // Show what was filtered out
      const skippedSubclasses = new Set();
      const skippedColumns = new Set();
      importData.objects.forEach(obj => {
        if (obj.subclassValues) {
          Object.keys(obj.subclassValues).forEach(k => {
            if (!validSubclasses.has(k)) skippedSubclasses.add(k);
          });
        }
        if (obj._customColumnsByName) {
          Object.keys(obj._customColumnsByName).forEach(k => {
            if (!columnNameToId.has(k)) skippedColumns.add(k);
          });
        }
      });
      
      let message = `Successfully imported ${filteredObjects.length} objects (${importMode} mode)`;
      if (skippedSubclasses.size > 0 || skippedColumns.size > 0) {
        message += '\n\nSkipped columns (no longer exist):';
        if (skippedSubclasses.size > 0) message += `\n• Subclasses: ${Array.from(skippedSubclasses).join(', ')}`;
        if (skippedColumns.size > 0) message += `\n• Custom columns: ${Array.from(skippedColumns).join(', ')}`;
      }
      
      alert(message);
      setShowImportDialog(false);
      setImportData(null);
      setImportError(null);
    } catch (error) {
      console.error('Import failed:', error);
      alert('Import failed: ' + error.message);
    }
  };

  // Find matching objects for find/replace
  const findMatches = useMemo(() => {
    if (!findText || !selectedClass) return [];
    
    const data = getClassData();
    const searchText = matchCase ? findText : findText.toLowerCase();
    
    return data.filter(obj => {
      // Exclude orphaned objects from search
      if (obj.status === 'orphaned') return false;
      
      let fieldValue = '';
      if (findField === 'filename') {
        fieldValue = obj.filename?.replace('.pdf', '') || '';
      } else if (findField.startsWith('subclass_')) {
        const subclassName = findField.replace('subclass_', '');
        fieldValue = obj.subclassValues?.[subclassName] || '';
      } else {
        fieldValue = obj[findField] || '';
      }
      const compareValue = matchCase ? fieldValue : fieldValue.toLowerCase();
      return compareValue.includes(searchText);
    });
  }, [findText, findField, matchCase, selectedClass, detectedObjects, columnFilters]);

  // Replace in single object
  const handleReplaceSingle = async (objId) => {
    if (!findText) return;
    
    const updatedObjects = detectedObjects.map(obj => {
      if (obj.id === objId) {
        let currentValue = '';
        if (findField === 'filename') {
          // Can't replace filename
          return obj;
        } else if (findField.startsWith('subclass_')) {
          const subclassName = findField.replace('subclass_', '');
          currentValue = obj.subclassValues?.[subclassName] || '';
          const regex = new RegExp(findText.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), matchCase ? 'g' : 'gi');
          return {
            ...obj,
            subclassValues: {
              ...(obj.subclassValues || {}),
              [subclassName]: currentValue.replace(regex, replaceText)
            }
          };
        } else {
          currentValue = obj[findField] || '';
          const regex = new RegExp(findText.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), matchCase ? 'g' : 'gi');
          return { ...obj, [findField]: currentValue.replace(regex, replaceText) };
        }
      }
      return obj;
    });
    
    setDetectedObjects(updatedObjects);
    
    try {
      await saveObjectsToBackend(projectId, updatedObjects);
    } catch (error) {
      console.error('Error replacing:', error);
    }
  };

  // Replace all matches
  const handleReplaceAll = async () => {
    if (!findText || findMatches.length === 0) return;
    if (findField === 'filename') {
      alert('Cannot replace in filename field');
      return;
    }
    
    const matchIds = new Set(findMatches.map(obj => obj.id));
    
    const updatedObjects = detectedObjects.map(obj => {
      if (matchIds.has(obj.id)) {
        if (findField.startsWith('subclass_')) {
          const subclassName = findField.replace('subclass_', '');
          const currentValue = obj.subclassValues?.[subclassName] || '';
          const regex = new RegExp(findText.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), matchCase ? 'g' : 'gi');
          return {
            ...obj,
            subclassValues: {
              ...(obj.subclassValues || {}),
              [subclassName]: currentValue.replace(regex, replaceText)
            }
          };
        } else {
          const currentValue = obj[findField] || '';
          const regex = new RegExp(findText.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), matchCase ? 'g' : 'gi');
          return { ...obj, [findField]: currentValue.replace(regex, replaceText) };
        }
      }
      return obj;
    });
    
    setDetectedObjects(updatedObjects);
    
    try {
      await saveObjectsToBackend(projectId, updatedObjects);
      alert(`Replaced ${findMatches.length} occurrence(s)`);
    } catch (error) {
      console.error('Error replacing all:', error);
    }
  };

  // Get searchable fields for find/replace
  const getSearchableFields = () => {
    const fields = [
      { id: 'filename', name: 'Document' }
    ];
    // Add subclass columns if they exist, otherwise add Tag
    const subclasses = getSelectedClassSubclasses();
    if (subclasses.length > 0) {
      subclasses.forEach(sub => {
        fields.push({ id: `subclass_${sub.name}`, name: sub.name });
      });
    } else {
      // No subclasses - add the default Tag column
      fields.push({ id: 'ocr_text', name: 'Tag' });
    }
    // Add custom columns
    const customCols = getClassCustomColumns();
    customCols.forEach(col => {
      if (col.editable) {
        fields.push({ id: col.id, name: col.name });
      }
    });
    return fields;
  };

  if (isLoading) {
    return <div className="loading">Loading project...</div>;
  }

  if (!project) {
    return <div className="loading">Project not found</div>;
  }

  // classData is now memoized above - no need to call getClassData() here

  return (
    <div className="project-classes-page" style={{ display: 'flex', flexDirection: 'column', height: '100vh', overflow: 'hidden' }}>
      <header className="classes-header">
        <button className="back-btn" onClick={() => navigate(`/project/${projectId}`, { state: { returnToFile } })}>
          ← Back to Project
        </button>
        <h1>{project.name} - Classes</h1>
        <h1 className="brand-title">pidly</h1>
      </header>

      <div className="classes-content" style={{ display: 'flex', flex: 1, overflow: 'hidden' }}>
        {/* Sidebar - Resizable */}
        <div className="classes-sidebar" style={{ width: sidebarWidth, minWidth: 320, maxWidth: 500, flexShrink: 0, display: 'flex', flexDirection: 'column', position: 'relative' }}>
          {/* Overview button */}
          <div 
            className={`sidebar-item home-item ${viewMode === 'home' ? 'selected' : ''}`}
            onClick={() => { setViewMode('home'); setSelectedClass(null); setSelectedTag(null); }}
          >
            <span className="item-name">Overview</span>
          </div>

          {/* Object Search button */}
          <div 
            className={`sidebar-item home-item ${viewMode === 'registry' ? 'selected' : ''}`}
            onClick={() => { setViewMode('registry'); setSelectedClass(null); setSelectedTag(null); setRegistrySearchQuery(''); }}
          >
            <span className="item-name">Object Search</span>
          </div>

          {/* Classes section - matching Smart Links models-section */}
          <div className="classes-section" style={{ display: 'flex', flexDirection: 'column', flex: 1, minHeight: '100px', overflow: 'hidden', background: '#1e1e1e' }}>
            <div className="classes-section-header" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '16px 16px 12px', flexShrink: 0 }}>
              <span style={{ fontSize: '14px', fontWeight: 700, color: '#fff' }}>Current Classes</span>
            </div>
            
            {/* Search */}
            <div className="classes-search" style={{ padding: '0 12px 12px' }}>
              <input
                type="text"
                placeholder="Search..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                style={{ width: '100%', padding: '6px 10px', border: '1px solid #444', borderRadius: '4px', fontSize: '13px', boxSizing: 'border-box', background: '#2a2a2a', color: '#fff' }}
              />
            </div>

            {/* New Class Button */}
            <div style={{ padding: '0 12px 12px' }}>
              <button 
                onClick={() => setShowNewClassDialog(true)}
                style={{ 
                  width: '100%', 
                  padding: '8px 12px', 
                  background: 'linear-gradient(135deg, #252525 0%, #2a2a2a 100%)', 
                  border: '1px solid #3a3a3a', 
                  borderRadius: '6px', 
                  color: '#bbb', 
                  fontSize: '12px', 
                  cursor: 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: '6px',
                  transition: 'all 0.2s'
                }}
                onMouseEnter={(e) => { e.currentTarget.style.background = 'linear-gradient(135deg, #2a2a2a 0%, #333 100%)'; e.currentTarget.style.borderColor = '#3498db'; e.currentTarget.style.color = '#fff'; }}
                onMouseLeave={(e) => { e.currentTarget.style.background = 'linear-gradient(135deg, #252525 0%, #2a2a2a 100%)'; e.currentTarget.style.borderColor = '#3a3a3a'; e.currentTarget.style.color = '#bbb'; }}
              >
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M12 5v14M5 12h14"/>
                </svg>
                New Class
              </button>
            </div>
            
            {/* Classes list */}
            <div className="class-list" style={{ flex: '1 1 auto', overflowY: 'auto', overflowX: 'hidden', padding: '4px 8px', minHeight: 0, scrollbarWidth: 'thin', scrollbarColor: '#555 #2a2a2a', background: '#1e1e1e' }}>
              {filteredClasses.length === 0 ? (
                <p className="no-classes" style={{ padding: '20px 12px', color: '#666', fontSize: '13px', textAlign: 'center' }}>
                  {searchQuery ? 'No classes found' : 'No classes yet'}
                </p>
              ) : (
                filteredClasses.map(cls => (
                  <div
                    key={cls.name}
                    className={`class-item ${selectedClass?.name === cls.name && viewMode === 'class' ? 'selected' : ''}`}
                    onClick={() => { setSelectedClass(cls); setViewMode('class'); setSelectedTag(null); }}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '10px',
                      padding: '8px 12px',
                      borderRadius: '6px',
                      cursor: 'pointer',
                      marginBottom: '2px',
                      transition: 'all 0.15s',
                      background: selectedClass?.name === cls.name && viewMode === 'class' ? '#2a2a2a' : 'transparent',
                      borderLeft: selectedClass?.name === cls.name && viewMode === 'class' ? '3px solid #3498db' : '3px solid transparent'
                    }}
                    onMouseEnter={(e) => { 
                      if (!(selectedClass?.name === cls.name && viewMode === 'class')) e.currentTarget.style.background = '#252525'; 
                      e.currentTarget.querySelector('.delete-btn').style.opacity = '1';
                    }}
                    onMouseLeave={(e) => { 
                      if (!(selectedClass?.name === cls.name && viewMode === 'class')) e.currentTarget.style.background = 'transparent'; 
                      e.currentTarget.querySelector('.delete-btn').style.opacity = '0';
                    }}
                  >
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="2" style={{ flexShrink: 0 }}>
                      <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/>
                      <polyline points="3.27 6.96 12 12.01 20.73 6.96"/>
                      <line x1="12" y1="22.08" x2="12" y2="12"/>
                    </svg>
                    <div className="class-item-info" style={{ flex: 1, minWidth: 0 }}>
                      <div className="class-item-name" style={{ fontSize: '13px', fontWeight: 600, color: '#fff', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{cls.name}</div>
                      <div className="class-item-meta" style={{ fontSize: '11px', color: '#888' }}>{cls.count} objects</div>
                    </div>
                    <button
                      className="class-action-btn delete delete-btn"
                      title="Delete class"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDeleteClass(cls.name);
                      }}
                      style={{ background: 'transparent', border: 'none', color: '#666', cursor: 'pointer', padding: '4px', borderRadius: '4px', display: 'flex', alignItems: 'center', justifyContent: 'center', opacity: 0, transition: 'all 0.15s' }}
                      onMouseEnter={(e) => { e.currentTarget.style.color = '#e74c3c'; }}
                      onMouseLeave={(e) => { e.currentTarget.style.color = '#666'; }}
                    >
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                        <path d="M3 6h18M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2"/>
                      </svg>
                    </button>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Sidebar Footer - Models link */}
          <div className="sidebar-footer" style={{ marginTop: 'auto', padding: '12px', borderTop: '1px solid #333', background: 'linear-gradient(to top, #1a1a1a, #1e1e1e)' }}>
            <div style={{ fontSize: '11px', color: '#666', marginBottom: '8px', paddingLeft: '2px' }}>Need to train object detection models?</div>
            <button 
              onClick={() => navigate(`/project/${projectId}/models`, { state: { returnToFile } })}
              style={{ 
                display: 'flex', 
                alignItems: 'center', 
                gap: '8px', 
                width: '100%', 
                padding: '10px 12px', 
                background: 'linear-gradient(135deg, #252525 0%, #2a2a2a 100%)', 
                border: '1px solid #3a3a3a', 
                borderRadius: '6px', 
                color: '#bbb', 
                fontSize: '12px', 
                cursor: 'pointer',
                transition: 'all 0.2s'
              }}
              onMouseEnter={(e) => { e.currentTarget.style.background = 'linear-gradient(135deg, #2a2a2a 0%, #333 100%)'; e.currentTarget.style.borderColor = '#3498db'; e.currentTarget.style.color = '#fff'; }}
              onMouseLeave={(e) => { e.currentTarget.style.background = 'linear-gradient(135deg, #252525 0%, #2a2a2a 100%)'; e.currentTarget.style.borderColor = '#3a3a3a'; e.currentTarget.style.color = '#bbb'; }}
            >
              Models
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" style={{ marginLeft: 'auto', opacity: 0.5 }}>
                <polyline points="9 18 15 12 9 6"/>
              </svg>
            </button>
          </div>
          
          {/* Resize handle */}
          <div
            style={{
              position: 'absolute',
              right: 0,
              top: 0,
              bottom: 0,
              width: 5,
              cursor: 'col-resize',
              background: isResizingSidebar ? '#3498db' : 'transparent',
              transition: 'background 0.2s',
            }}
            onMouseDown={handleSidebarMouseDown}
            onMouseEnter={(e) => e.currentTarget.style.background = '#3498db'}
            onMouseLeave={(e) => !isResizingSidebar && (e.currentTarget.style.background = 'transparent')}
          />
        </div>

        {/* Main Content - Takes remaining space */}
        <div className="classes-main" style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
          {viewMode === 'home' ? (
            <div className="home-content-wrapper" style={{ flex: 1, overflowY: 'auto', overflowX: 'hidden' }}>
              <div className="home-content" style={{ overflowY: 'visible', padding: '16px 20px' }}>
              <div className="home-header-section">
                <div className="home-icon">
                  <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="1.5">
                    <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/>
                    <polyline points="3.27 6.96 12 12.01 20.73 6.96"/>
                    <line x1="12" y1="22.08" x2="12" y2="12"/>
                  </svg>
                </div>
                <h2>Classes Overview</h2>
                <p className="home-subtitle">Manage detected objects and their classifications</p>
              </div>
              
              <div className="home-stats-row">
                <div className="stat-card" style={{ background: 'transparent', border: '1px solid #333' }}>
                  <div className="stat-number" style={{ color: '#fff', fontWeight: 700 }}>{filteredClasses.length}</div>
                  <div className="stat-label" style={{ color: '#888', fontWeight: 600 }}>Classes</div>
                </div>
                <div className="stat-card" style={{ background: 'transparent', border: '1px solid #333' }}>
                  <div className="stat-number" style={{ color: '#fff', fontWeight: 700 }}>
                    {filteredClasses.reduce((sum, cls) => sum + cls.count, 0)}
                  </div>
                  <div className="stat-label" style={{ color: '#888', fontWeight: 600 }}>Objects</div>
                </div>
                <div className="stat-card" style={{ background: 'transparent', border: '1px solid #333' }}>
                  <div className="stat-number" style={{ color: '#fff', fontWeight: 700 }}>
                    {project?.classes?.filter(c => c.parentId)?.length || 0}
                  </div>
                  <div className="stat-label" style={{ color: '#888', fontWeight: 600 }}>Subclasses</div>
                </div>
              </div>

              {/* Class Distribution Bar Chart */}
              {filteredClasses.length > 0 && filteredClasses.some(cls => cls.count > 0) && (
                <div className="class-distribution-section" style={{ background: 'transparent', border: 'none' }}>
                  <h3 style={{ textAlign: 'center' }}>Class Distribution</h3>
                  <div className="bar-chart">
                    {filteredClasses
                      .filter(cls => cls.count > 0)
                      .sort((a, b) => b.count - a.count)
                      .slice(0, 10)
                      .map((cls, index) => {
                        const maxCount = Math.max(...filteredClasses.map(c => c.count));
                        const percentage = maxCount > 0 ? (cls.count / maxCount) * 100 : 0;
                        return (
                          <div 
                            key={cls.name} 
                            className="bar-column"
                            onClick={() => { setSelectedClass(cls); setViewMode('class'); }}
                            title={`${cls.name}: ${cls.count} objects`}
                          >
                            <div className="bar-fill-wrapper">
                              <div className="bar-count-vertical">{cls.count}</div>
                              <div 
                                className="bar-fill-vertical" 
                                style={{ 
                                  height: `${percentage}%`,
                                  backgroundColor: `hsl(${200 + (index * 15) % 60}, 70%, 55%)`
                                }}
                              />
                            </div>
                            <div className="bar-label-vertical">{cls.name}</div>
                          </div>
                        );
                      })}
                  </div>
                  {filteredClasses.filter(cls => cls.count > 0).length > 10 && (
                    <div className="bar-more">
                      +{filteredClasses.filter(cls => cls.count > 0).length - 10} more classes
                    </div>
                  )}
                </div>
              )}

              <div className="home-actions-section" style={{ background: 'transparent', border: 'none', padding: 0 }}>
                <h3 style={{ color: '#fff', fontWeight: 700 }}>Quick Actions</h3>
                <div className="home-actions-grid" style={{ display: 'flex', gap: '12px' }}>
                  <div className="action-card" onClick={() => setShowNewClassDialog(true)}>
                    <div className="action-row">
                      <div className="action-icon">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="2.5" strokeLinecap="round">
                          <path d="M12 5v14M5 12h14"/>
                        </svg>
                      </div>
                      <div className="action-title">New Class</div>
                    </div>
                    <div className="action-desc">Create a new object class</div>
                  </div>
                  
                  <div className="action-card" onClick={handleExportAllJSON}>
                    <div className="action-row">
                      <div className="action-icon">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="2.5" strokeLinecap="round">
                          <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M17 8l-5-5-5 5M12 3v12"/>
                        </svg>
                      </div>
                      <div className="action-title">Export JSON</div>
                    </div>
                    <div className="action-desc">Full backup of all objects</div>
                  </div>
                  
                  <div className="action-card" onClick={handleExportAllCSV}>
                    <div className="action-row">
                      <div className="action-icon">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="2.5" strokeLinecap="round">
                          <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
                          <path d="M14 2v6h6M8 13h8M8 17h8"/>
                        </svg>
                      </div>
                      <div className="action-title">Export CSV</div>
                    </div>
                    <div className="action-desc">Spreadsheet format</div>
                  </div>
                  
                  <div className="action-card" onClick={() => fileInputRef.current?.click()}>
                    <div className="action-row">
                      <div className="action-icon">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="2.5" strokeLinecap="round">
                          <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3"/>
                        </svg>
                      </div>
                      <div className="action-title">Import</div>
                    </div>
                    <div className="action-desc">Load JSON or CSV file</div>
                  </div>
                </div>
                <input
                  type="file"
                  ref={fileInputRef}
                  accept=".json,.csv"
                  onChange={handleFileSelect}
                  style={{ display: 'none' }}
                />
              </div>

              {/* Orphaned Objects Banner */}
              {orphanedObjectsInfo.total > 0 && (
                <div className="orphaned-banner">
                  <div className="orphaned-banner-content">
                    <div className="orphaned-banner-title">
                      {orphanedObjectsInfo.total} Orphaned Object{orphanedObjectsInfo.total !== 1 ? 's' : ''}
                    </div>
                    <div className="orphaned-banner-desc">
                      Objects from {orphanedObjectsInfo.fileNames.length} deleted file{orphanedObjectsInfo.fileNames.length !== 1 ? 's' : ''} that can be reassigned.
                    </div>
                    <div className="orphaned-actions">
                      <button 
                        className="orphaned-reassign-btn"
                        onClick={() => {
                          setReassignSourceFile(null);
                          setReassignTargetFile(null);
                          setShowReassignDialog(true);
                        }}
                      >
                        Reassign
                      </button>
                      <button 
                        className="orphaned-delete-all-btn"
                        onClick={handlePermanentDeleteAllOrphaned}
                      >
                        Delete All
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>
            </div>
          ) : viewMode === 'registry' ? (
            /* Smart Search View */
            <div className="smart-search-view" style={{ display: 'flex', flexDirection: 'column', height: '100%', background: '#1a1a1a' }}>
              {/* Search Header */}
              <div style={{ padding: '16px 40px 20px', borderBottom: '1px solid #333', background: '#1e1e1e' }}>
                <h2 style={{ color: '#fff', fontWeight: 700, margin: '0 0 8px', fontSize: '24px' }}>Object Search</h2>
                <p style={{ color: '#888', margin: '0 0 20px', fontSize: '14px' }}>Search across all classes, tags, subclasses, and custom columns</p>
                
                {/* Search Input */}
                <div style={{ position: 'relative', maxWidth: '600px' }}>
                  <input
                    type="text"
                    placeholder="Search for tags, equipment IDs, values..."
                    value={registrySearchQuery}
                    onChange={(e) => setRegistrySearchQuery(e.target.value)}
                    autoFocus
                    style={{
                      width: '100%',
                      padding: '14px 20px 14px 48px',
                      fontSize: '16px',
                      background: '#2a2a2a',
                      border: '2px solid #3a3a3a',
                      borderRadius: '10px',
                      color: '#fff',
                      outline: 'none',
                      transition: 'border-color 0.2s'
                    }}
                    onFocus={(e) => e.target.style.borderColor = '#3498db'}
                    onBlur={(e) => e.target.style.borderColor = '#3a3a3a'}
                  />
                  <svg 
                    width="20" 
                    height="20" 
                    viewBox="0 0 24 24" 
                    fill="none" 
                    stroke="#888" 
                    strokeWidth="2"
                    style={{ position: 'absolute', left: '16px', top: '50%', transform: 'translateY(-50%)' }}
                  >
                    <circle cx="11" cy="11" r="8"/>
                    <path d="M21 21l-4.35-4.35"/>
                  </svg>
                  {registrySearchQuery && (
                    <button
                      onClick={() => setRegistrySearchQuery('')}
                      style={{
                        position: 'absolute',
                        right: '12px',
                        top: '50%',
                        transform: 'translateY(-50%)',
                        background: '#444',
                        border: 'none',
                        borderRadius: '50%',
                        width: '24px',
                        height: '24px',
                        cursor: 'pointer',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        color: '#888'
                      }}
                    >
                      ×
                    </button>
                  )}
                </div>
              </div>
              
              {/* Search Results */}
              <div style={{ flex: 1, overflow: 'auto', padding: '24px 40px' }}>
                {!registrySearchQuery.trim() ? (
                  /* Empty State */
                  <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', height: '300px', color: '#666' }}>
                    <svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" style={{ marginBottom: '16px', opacity: 0.5 }}>
                      <circle cx="11" cy="11" r="8"/>
                      <path d="M21 21l-4.35-4.35"/>
                    </svg>
                    <h3 style={{ margin: '0 0 8px', fontWeight: 600, color: '#888' }}>Start Searching</h3>
                    <p style={{ margin: 0, fontSize: '14px', textAlign: 'center', maxWidth: '400px' }}>
                      Enter a tag, equipment ID, or any value to find matching objects across all classes
                    </p>
                  </div>
                ) : smartSearchResults && smartSearchResults.totalCount === 0 ? (
                  /* No Results */
                  <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', height: '300px', color: '#666' }}>
                    <div style={{ fontSize: '48px', marginBottom: '16px', opacity: 0.5 }}>🔍</div>
                    <h3 style={{ margin: '0 0 8px', fontWeight: 600, color: '#888' }}>No Results Found</h3>
                    <p style={{ margin: 0, fontSize: '14px', color: '#666' }}>
                      No objects match "{registrySearchQuery}"
                    </p>
                  </div>
                ) : smartSearchResults ? (
                  /* Results - Horizontal Layout */
                  <>
                    <div style={{ marginBottom: '24px', display: 'flex', alignItems: 'center', gap: '12px' }}>
                      <span style={{ color: '#fff', fontWeight: 600, fontSize: '16px' }}>
                        {smartSearchResults.totalCount} result{smartSearchResults.totalCount !== 1 ? 's' : ''}
                      </span>
                      <span style={{ color: '#666', fontSize: '14px' }}>
                        for "{smartSearchResults.query}"
                      </span>
                    </div>
                    
                    {/* Results Container */}
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                      {/* Each result row: searched value on left, class cards on right */}
                      {Object.entries(smartSearchResults.byClass).map(([className, results]) => {
                        const classColumns = getColumnsForClass(className);
                        return results.map((result, idx) => (
                          <div 
                            key={`${className}-${idx}`}
                            style={{ 
                              display: 'flex', 
                              gap: '20px',
                              background: '#1e1e1e',
                              borderRadius: '10px',
                              border: '1px solid #333',
                              overflow: 'hidden'
                            }}
                          >
                            {/* Left: Matched Value */}
                            <div style={{ 
                              width: '200px',
                              flexShrink: 0,
                              padding: '20px',
                              background: '#252525',
                              display: 'flex',
                              flexDirection: 'column',
                              justifyContent: 'center',
                              borderRight: '1px solid #333'
                            }}>
                              <div style={{ fontSize: '11px', color: '#888', textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: '8px' }}>
                                Matched in {result.matches[0]?.field || 'Tag'}
                              </div>
                              <div style={{ fontSize: '18px', fontWeight: 700, color: '#3498db', wordBreak: 'break-word' }}>
                                {result.matches[0]?.value || result.tag || '-'}
                              </div>
                            </div>
                            
                            {/* Right: Class Card with all columns */}
                            <div style={{ flex: 1, padding: '16px 20px', minWidth: 0 }}>
                              {/* Class Header */}
                              <div style={{ 
                                display: 'flex', 
                                alignItems: 'center', 
                                gap: '8px', 
                                marginBottom: '12px',
                                paddingBottom: '10px',
                                borderBottom: '1px solid #333'
                              }}>
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#3498db" strokeWidth="2">
                                  <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/>
                                  <polyline points="3.27 6.96 12 12.01 20.73 6.96"/>
                                  <line x1="12" y1="22.08" x2="12" y2="12"/>
                                </svg>
                                <span style={{ fontWeight: 700, color: '#fff', fontSize: '14px' }}>{className}</span>
                                <button
                                  onClick={() => {
                                    const cls = classes.find(c => c.name === className);
                                    if (cls) {
                                      setSelectedClass(cls);
                                      setViewMode('class');
                                    }
                                  }}
                                  style={{
                                    marginLeft: 'auto',
                                    padding: '4px 10px',
                                    background: '#333',
                                    border: 'none',
                                    borderRadius: '4px',
                                    color: '#888',
                                    fontSize: '11px',
                                    cursor: 'pointer'
                                  }}
                                  onMouseEnter={(e) => { e.currentTarget.style.background = '#3498db'; e.currentTarget.style.color = '#fff'; }}
                                  onMouseLeave={(e) => { e.currentTarget.style.background = '#333'; e.currentTarget.style.color = '#888'; }}
                                >
                                  View Class →
                                </button>
                              </div>
                              
                              {/* Column Data Grid */}
                              <div style={{ display: 'flex', flexWrap: 'wrap', gap: '16px 24px' }}>
                                {classColumns.map(col => {
                                  let value = '-';
                                  if (col.id === 'filename') {
                                    value = result.filename;
                                  } else if (col.id === 'page') {
                                    value = result.page;
                                  } else if (col.id === 'confidence') {
                                    value = result.confidence ? `${(result.confidence * 100).toFixed(0)}%` : '-';
                                  } else if (col.id === 'ocr_text') {
                                    value = result.tag || '-';
                                  } else if (col.isSubclass) {
                                    value = result.subclassValues[col.subclassName] || '-';
                                  } else if (col.isCustom) {
                                    // Custom columns: check obj[col.id] first (main storage), then customData
                                    value = result.obj[col.id] || result.customData[col.id] || '-';
                                  }
                                  
                                  const searchLower = registrySearchQuery.toLowerCase();
                                  const valueLower = value.toString().toLowerCase();
                                  const isMatch = valueLower.includes(searchLower);
                                  
                                  return (
                                    <div key={col.id} style={{ minWidth: '100px' }}>
                                      <div style={{ fontSize: '10px', color: '#666', textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: '4px' }}>
                                        {col.name}
                                      </div>
                                      <div style={{ 
                                        fontSize: '13px', 
                                        fontWeight: 600, 
                                        color: isMatch ? '#3498db' : '#fff',
                                        background: isMatch ? 'rgba(52, 152, 219, 0.15)' : 'transparent',
                                        padding: isMatch ? '2px 6px' : '0',
                                        borderRadius: '4px',
                                        display: 'inline-block'
                                      }}>
                                        {value}
                                      </div>
                                    </div>
                                  );
                                })}
                              </div>
                            </div>
                          </div>
                        ));
                      })}
                    </div>
                  </>
                ) : null}
              </div>
            </div>
          ) : viewMode === 'class' && selectedClass ? (
            <>
              {/* Header - Fixed, never scrolls */}
              <div className="class-data-header" style={{ background: '#252525', borderBottom: '1px solid #333', padding: '12px 20px' }}>
                {/* Single Row: Class info left, all buttons right */}
                <div className="header-row header-row-primary" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 0 }}>
                  <div className="header-left" style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                    <h2 style={{ color: '#fff', fontWeight: 700, margin: 0 }}>{selectedClass.name}</h2>
                    <span className="object-count" style={{ background: '#333', color: '#fff', padding: '4px 10px', borderRadius: '12px', fontSize: '12px', fontWeight: 600 }}>{classData.length} objects</span>
                    <div className="class-settings" style={{ display: 'flex', alignItems: 'center', gap: '12px', marginLeft: '8px' }}>
                      {/* Fill Color */}
                      <div className="color-picker-group" title="Fill Color" style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                        <span className="color-label" style={{ fontSize: '12px', color: '#fff', fontWeight: 600 }}>Fill</span>
                        <button
                          className={`no-color-btn ${selectedClass.fillColor === 'none' || (selectedClass.color === 'none' && !selectedClass.fillColor) ? 'active' : ''}`}
                          style={{ width: '24px', height: '24px', background: '#2a2a2a', border: '1px solid #444', borderRadius: '4px', color: '#fff', cursor: 'pointer' }}
                          onClick={async () => {
                            const existingClasses = project.classes || [];
                            const classExists = existingClasses.some(cls => 
                              cls.id === selectedClass.id || cls.name === selectedClass.name
                            );
                            
                            let updatedClasses;
                            if (classExists) {
                              updatedClasses = existingClasses.map(cls => 
                                cls.id === selectedClass.id || cls.name === selectedClass.name 
                                  ? { ...cls, fillColor: 'none' } 
                                  : cls
                              );
                            } else {
                              updatedClasses = [
                                ...existingClasses,
                                {
                                  id: selectedClass.id || `class_${Date.now()}`,
                                  name: selectedClass.name,
                                  fillColor: 'none',
                                  shapeType: selectedClass.shapeType || 'rectangle',
                                  created: new Date().toISOString()
                                }
                              ];
                            }
                            
                            const updatedProject = { ...project, classes: updatedClasses };
                            setProject(updatedProject);
                            setSelectedClass({ ...selectedClass, fillColor: 'none' });
                            setClasses(extractClasses(updatedProject));
                            try {
                              await saveProject(updatedProject);
                            } catch (error) {
                              console.error('Error saving color:', error);
                            }
                          }}
                          title="No fill (transparent)"
                        >
                          ∅
                        </button>
                        <input
                          type="color"
                          value={(() => {
                            if (selectedClass.fillColor && selectedClass.fillColor !== 'none') return selectedClass.fillColor;
                            if (selectedClass.color && selectedClass.color !== 'none') return selectedClass.color;
                            return '#3498db';
                          })()}
                          onChange={async (e) => {
                            const newFillColor = e.target.value;
                            const existingClasses = project.classes || [];
                            
                            const classExists = existingClasses.some(cls => 
                              cls.id === selectedClass.id || cls.name === selectedClass.name
                            );
                            
                            let updatedClasses;
                            if (classExists) {
                              updatedClasses = existingClasses.map(cls => 
                                cls.id === selectedClass.id || cls.name === selectedClass.name 
                                  ? { ...cls, fillColor: newFillColor } 
                                  : cls
                              );
                            } else {
                              updatedClasses = [
                                ...existingClasses,
                                {
                                  id: selectedClass.id || `class_${Date.now()}`,
                                  name: selectedClass.name,
                                  fillColor: newFillColor,
                                  shapeType: selectedClass.shapeType || 'rectangle',
                                  created: new Date().toISOString()
                                }
                              ];
                            }
                            
                            const updatedProject = { ...project, classes: updatedClasses };
                            setProject(updatedProject);
                            setSelectedClass({ ...selectedClass, fillColor: newFillColor });
                            setClasses(extractClasses(updatedProject));
                            try {
                              await saveProject(updatedProject);
                            } catch (error) {
                              console.error('Error saving fill color:', error);
                            }
                          }}
                          className={`class-color-picker ${selectedClass.fillColor === 'none' || (selectedClass.color === 'none' && !selectedClass.fillColor) ? 'inactive' : ''}`}
                          title="Fill color"
                        />
                      </div>
                      
                      {/* Border/Line Color */}
                      <div className="color-picker-group" title="Border Color">
                        <span className="color-label">Line</span>
                        <button
                          className={`no-color-btn ${selectedClass.borderColor === 'none' ? 'active' : ''}`}
                          onClick={async () => {
                            const existingClasses = project.classes || [];
                            const classExists = existingClasses.some(cls => 
                              cls.id === selectedClass.id || cls.name === selectedClass.name
                            );
                            
                            let updatedClasses;
                            if (classExists) {
                              updatedClasses = existingClasses.map(cls => 
                                cls.id === selectedClass.id || cls.name === selectedClass.name 
                                  ? { ...cls, borderColor: 'none' } 
                                  : cls
                              );
                            } else {
                              updatedClasses = [
                                ...existingClasses,
                                {
                                  id: selectedClass.id || `class_${Date.now()}`,
                                  name: selectedClass.name,
                                  borderColor: 'none',
                                  shapeType: selectedClass.shapeType || 'rectangle',
                                  created: new Date().toISOString()
                                }
                              ];
                            }
                            
                            const updatedProject = { ...project, classes: updatedClasses };
                            setProject(updatedProject);
                            setSelectedClass({ ...selectedClass, borderColor: 'none' });
                            setClasses(extractClasses(updatedProject));
                            try {
                              await saveProject(updatedProject);
                            } catch (error) {
                              console.error('Error saving color:', error);
                            }
                          }}
                          title="No border (transparent)"
                        >
                          ∅
                        </button>
                        <input
                          type="color"
                          value={(() => {
                            if (selectedClass.borderColor && selectedClass.borderColor !== 'none') return selectedClass.borderColor;
                            if (selectedClass.color && selectedClass.color !== 'none') return selectedClass.color;
                            return '#3498db';
                          })()}
                          onChange={async (e) => {
                            const newBorderColor = e.target.value;
                            const existingClasses = project.classes || [];
                            
                            const classExists = existingClasses.some(cls => 
                              cls.id === selectedClass.id || cls.name === selectedClass.name
                            );
                            
                            let updatedClasses;
                            if (classExists) {
                              updatedClasses = existingClasses.map(cls => 
                                cls.id === selectedClass.id || cls.name === selectedClass.name 
                                  ? { ...cls, borderColor: newBorderColor } 
                                  : cls
                              );
                            } else {
                              updatedClasses = [
                                ...existingClasses,
                                {
                                  id: selectedClass.id || `class_${Date.now()}`,
                                  name: selectedClass.name,
                                  borderColor: newBorderColor,
                                  shapeType: selectedClass.shapeType || 'rectangle',
                                  created: new Date().toISOString()
                                }
                              ];
                            }
                            
                            const updatedProject = { ...project, classes: updatedClasses };
                            setProject(updatedProject);
                            setSelectedClass({ ...selectedClass, borderColor: newBorderColor });
                            setClasses(extractClasses(updatedProject));
                            try {
                              await saveProject(updatedProject);
                            } catch (error) {
                              console.error('Error saving border color:', error);
                            }
                          }}
                          className={`class-color-picker ${selectedClass.borderColor === 'none' ? 'inactive' : ''}`}
                          title="Border/line color"
                        />
                      </div>
                    </div>
                  </div>
                  <div className="header-buttons" style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                    <button 
                      className="toolbar-btn"
                      style={{ padding: '6px 12px', background: '#2a2a2a', border: '1px solid #444', borderRadius: '6px', color: '#fff', fontSize: '12px', fontWeight: 600, cursor: 'pointer' }}
                      onClick={refreshData}
                      title="Refresh data"
                    >
                      Refresh
                    </button>
                    <button 
                      className={`toolbar-btn ${showFindReplace ? 'active' : ''}`}
                      style={{ padding: '6px 12px', background: showFindReplace ? '#3498db' : '#2a2a2a', border: '1px solid #444', borderRadius: '6px', color: '#fff', fontSize: '12px', fontWeight: 600, cursor: 'pointer' }}
                      onClick={() => setShowFindReplace(!showFindReplace)}
                      title="Find and Replace"
                    >
                      Find & Replace
                    </button>
                    {!selectedClass.parentId && subclasses.length > 0 && (
                      <button 
                        className="toolbar-btn toolbar-btn-primary"
                        style={{ padding: '6px 12px', background: '#2a2a2a', border: '1px solid #444', borderRadius: '6px', color: '#fff', fontSize: '12px', fontWeight: 600, cursor: 'pointer' }}
                        onClick={() => setShowAddSubclassDialog(true)}
                        title="Add a subclass column"
                      >
                        + Subclass
                      </button>
                    )}
                    <button 
                      className="toolbar-btn toolbar-btn-primary"
                      style={{ padding: '6px 12px', background: '#2a2a2a', border: '1px solid #444', borderRadius: '6px', color: '#fff', fontSize: '12px', fontWeight: 600, cursor: 'pointer' }}
                      onClick={() => setShowAddColumnDialog(true)}
                    >
                      + Column
                    </button>
                    <button 
                      className="toolbar-btn"
                      style={{ padding: '6px 12px', background: '#2a2a2a', border: '1px solid #444', borderRadius: '6px', color: '#fff', fontSize: '12px', fontWeight: 600, cursor: 'pointer' }}
                      onClick={handleExportCSV}
                    >
                      Export
                    </button>
                    {classData.length > 0 && (
                      <button 
                        className="toolbar-btn toolbar-btn-danger"
                        style={{ padding: '6px 12px', background: 'transparent', border: '1px solid #e74c3c', borderRadius: '6px', color: '#e74c3c', fontSize: '12px', fontWeight: 600, cursor: 'pointer' }}
                        onClick={() => handleDeleteFilteredObjects(classData)}
                        title={Object.values(columnFilters).some(v => v && v.trim()) 
                          ? `Delete ${classData.length} filtered object(s)` 
                          : `Delete all ${classData.length} object(s) in this class`}
                      >
                        {Object.values(columnFilters).some(v => v && v.trim()) 
                          ? `Delete Filtered (${classData.length})` 
                          : `Delete All (${classData.length})`}
                      </button>
                    )}
                    <button 
                      className="delete-class-btn"
                      style={{ padding: '6px 12px', background: '#e74c3c', border: 'none', borderRadius: '6px', color: '#fff', fontSize: '12px', fontWeight: 600, cursor: 'pointer' }}
                      onClick={() => handleDeleteClass(selectedClass.name)}
                    >
                      Delete Class
                    </button>
                  </div>
                </div>
              </div>
              
              {/* Find and Replace Panel */}
              {showFindReplace && (
                <div className="find-replace-panel">
                  <div className="find-replace-row">
                    <label>Find</label>
                    <input
                      type="text"
                      value={findText}
                      onChange={(e) => setFindText(e.target.value)}
                      placeholder="Search text..."
                      autoFocus
                    />
                    <span className="field-label">in</span>
                    <select value={findField} onChange={(e) => setFindField(e.target.value)}>
                      {getSearchableFields().map(field => (
                        <option key={field.id} value={field.id}>{field.name}</option>
                      ))}
                    </select>
                    <label className="match-case-label">
                      <input
                        type="checkbox"
                        checked={matchCase}
                        onChange={(e) => setMatchCase(e.target.checked)}
                      />
                      Match case
                    </label>
                  </div>
                  <div className="find-replace-row">
                    <label>Replace</label>
                    <input
                      type="text"
                      value={replaceText}
                      onChange={(e) => setReplaceText(e.target.value)}
                      placeholder="Replace with..."
                    />
                    <span className="match-count">
                      {findText ? `${findMatches.length} match${findMatches.length !== 1 ? 'es' : ''}` : ''}
                    </span>
                    <button 
                      className="replace-all-btn"
                      onClick={handleReplaceAll}
                      disabled={!findText || findMatches.length === 0 || findField === 'filename'}
                    >
                      Replace All
                    </button>
                    <button 
                      className="close-find-btn"
                      onClick={() => { setShowFindReplace(false); setFindText(''); setReplaceText(''); }}
                    >
                      ×
                    </button>
                  </div>
                </div>
              )}
              
              {/* Table container - scrolls independently with virtualization */}
              <div 
                ref={tableRef} 
                style={{ flex: 1, overflow: 'auto', background: '#1e1e1e' }}
                onScroll={(e) => {
                  setTableScrollTop(e.target.scrollTop);
                  // Update table height if needed
                  if (e.target.clientHeight !== tableHeight) {
                    setTableHeight(e.target.clientHeight);
                  }
                }}
              >
                <table className="csv-table" style={{ borderCollapse: 'separate', borderSpacing: 0, background: '#1e1e1e', width: 'max-content' }}>
                  <colgroup>
                    <col style={{ width: '40px', minWidth: '40px' }} /> {/* Go column */}
                    <col style={{ width: '100px', minWidth: '100px' }} /> {/* Preview column */}
                    {columns.map(col => (
                      <col key={col.id} style={{ width: getColumnWidth(col.id), minWidth: getColumnWidth(col.id) }} />
                    ))}
                    <col style={{ width: '40px', minWidth: '40px' }} /> {/* Delete column */}
                  </colgroup>
                  <thead style={{ background: '#252525' }}>
                    <tr>
                      <th className="goto-column" style={{ width: '40px', minWidth: '40px', background: '#252525', color: '#fff', fontWeight: 700, borderBottom: '1px solid #333', textAlign: 'center', padding: '8px', position: 'sticky', top: 0, zIndex: 10 }}>
                        <span style={{ fontSize: '11px', textTransform: 'uppercase', letterSpacing: '0.5px' }}>Go</span>
                      </th>
                      <th className="preview-column" style={{ width: '100px', minWidth: '100px', background: '#252525', color: '#fff', fontWeight: 700, borderBottom: '1px solid #333', textAlign: 'center', padding: '8px 12px', position: 'sticky', top: 0, zIndex: 10 }}>
                        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '4px' }}>
                          <span style={{ fontSize: '11px', textTransform: 'uppercase', letterSpacing: '0.5px' }}>Preview</span>
                          <button 
                            className="show-all-images-btn"
                            style={{ padding: '3px 8px', background: '#3a3a3a', border: 'none', borderRadius: '4px', color: '#888', fontSize: '10px', cursor: 'pointer' }}
                            onClick={() => {
                              // Load thumbnails only for visible rows to avoid performance issues
                              visibleRows.forEach(obj => {
                                if (!thumbnails[obj.id] && !loadingThumbnails[obj.id]) {
                                  loadThumbnail(obj);
                                }
                              });
                            }}
                            title="Load visible images"
                          >
                            Load
                          </button>
                        </div>
                      </th>
                      {columns.map(col => (
                        <th 
                          key={col.id} 
                          style={{ 
                            width: getColumnWidth(col.id),
                            minWidth: getColumnWidth(col.id),
                            background: '#252525',
                            color: '#fff',
                            fontWeight: 700,
                            borderBottom: '1px solid #333',
                            fontSize: '11px',
                            textTransform: 'uppercase',
                            letterSpacing: '0.5px',
                            position: 'sticky',
                            top: 0,
                            textAlign: 'center',
                            padding: '8px 12px',
                            zIndex: 10
                          }}
                        >
                          <div className="th-content" style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '6px' }}>
                            <div className="th-header column-header" style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '4px' }}>
                              <span style={{ color: '#fff', fontWeight: 700 }}>{col.name}</span>
                              {col.deletable && (
                                <button 
                                  className="delete-column-btn"
                                  onClick={(e) => { e.stopPropagation(); handleDeleteColumn(col.id); }}
                                  title="Delete column"
                                  style={{ background: 'transparent', border: 'none', color: '#888', cursor: 'pointer', fontSize: '14px', padding: '2px', marginLeft: '4px' }}
                                >
                                  ×
                                </button>
                              )}
                            </div>
                            <div className="th-controls" style={{ display: 'flex', gap: '4px', alignItems: 'center', justifyContent: 'center' }}>
                              {col.filterable && (
                                <div className="th-filter" style={{ flex: 1, maxWidth: '120px' }}>
                                  <input
                                    type="text"
                                    placeholder="Filter..."
                                    title={
                                      (col.id === 'confidence' || col.id === 'ocr_confidence')
                                        ? "Use >0.5, >=0.8, <0.9 for comparisons"
                                        : "Type to filter"
                                    }
                                    value={columnFilters[col.id] || ''}
                                    onChange={(e) => handleFilterChange(col.id, e.target.value)}
                                    onClick={(e) => e.stopPropagation()}
                                    style={{ background: '#2a2a2a', border: '1px solid #444', borderRadius: '4px', padding: '4px 8px', color: '#fff', fontSize: '10px', width: '100%', textAlign: 'center' }}
                                  />
                                </div>
                              )}
                              <button
                                className="align-btn"
                                onClick={(e) => { e.stopPropagation(); toggleColumnAlignment(col.id); }}
                                title={`Align ${getColumnAlignment(col.id)} (click to change)`}
                                style={{ background: '#3a3a3a', border: 'none', color: '#888', cursor: 'pointer', padding: '4px', borderRadius: '4px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}
                              >
                                {getColumnAlignment(col.id) === 'left' && (
                                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                                    <line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="12" x2="15" y2="12"/><line x1="3" y1="18" x2="18" y2="18"/>
                                  </svg>
                                )}
                                {getColumnAlignment(col.id) === 'center' && (
                                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                                    <line x1="3" y1="6" x2="21" y2="6"/><line x1="6" y1="12" x2="18" y2="12"/><line x1="4" y1="18" x2="20" y2="18"/>
                                  </svg>
                                )}
                                {getColumnAlignment(col.id) === 'right' && (
                                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                                    <line x1="3" y1="6" x2="21" y2="6"/><line x1="9" y1="12" x2="21" y2="12"/><line x1="6" y1="18" x2="21" y2="18"/>
                                  </svg>
                                )}
                              </button>
                            </div>
                          </div>
                          <div 
                            className="column-resizer"
                            onMouseDown={(e) => handleResizeStart(e, col.id)}
                            style={{ 
                              position: 'absolute', 
                              right: 0, 
                              top: 0, 
                              bottom: 0, 
                              width: '4px', 
                              cursor: 'col-resize', 
                              background: 'transparent',
                              zIndex: 10
                            }}
                            onMouseEnter={(e) => e.currentTarget.style.background = '#3498db'}
                            onMouseLeave={(e) => e.currentTarget.style.background = 'transparent'}
                          />
                        </th>
                      ))}
                      <th className="delete-column" style={{ width: '40px', minWidth: '40px', background: '#252525', color: '#fff', fontWeight: 700, borderBottom: '1px solid #333', textAlign: 'center', padding: '8px', position: 'sticky', top: 0, zIndex: 10 }}>
                        <span style={{ fontSize: '11px', textTransform: 'uppercase', letterSpacing: '0.5px' }}>Del</span>
                      </th>
                    </tr>
                  </thead>
                  <tbody style={{ background: '#1e1e1e' }}>
                    {classData.length === 0 ? (
                      <tr>
                        <td colSpan={columns.length + 3} className="no-results-row" style={{ background: '#1e1e1e', color: '#fff', fontWeight: 600, textAlign: 'center', padding: '20px' }}>
                          No objects in this class
                        </td>
                      </tr>
                    ) : (
                      <>
                        {/* Spacer row for virtualization - pushes visible rows to correct position */}
                        {visibleStartIndex > 0 && (
                          <tr style={{ height: visibleStartIndex * ROW_HEIGHT, padding: 0, border: 'none' }}>
                            <td colSpan={columns.length + 3} style={{ padding: 0, border: 'none', background: '#1e1e1e' }} />
                          </tr>
                        )}
                        {/* Render only visible rows */}
                        {visibleRows.map((obj, localIndex) => {
                          const globalIndex = visibleStartIndex + localIndex;
                          const isOrphaned = obj.status === 'orphaned';
                          return (
                            <tr 
                              key={obj.id || globalIndex}
                              style={{ height: ROW_HEIGHT, background: '#1e1e1e' }}
                              className={`${findText && findMatches.some(m => m.id === obj.id) ? 'highlight-match' : ''} ${isOrphaned ? 'orphaned-row' : ''}`}
                            >
                              <td className="goto-cell" style={{ width: '40px', minWidth: '40px', background: '#1e1e1e', borderBottom: '1px solid #333', textAlign: 'center', padding: '4px' }}>
                                <button 
                                  className={`goto-btn ${isOrphaned ? 'disabled' : ''}`}
                                  onClick={() => !isOrphaned && handleFindObject(obj)}
                                  title={isOrphaned ? "Cannot find - file deleted" : "Go to object in document"}
                                  disabled={isOrphaned}
                                  style={{ background: 'transparent', border: 'none', color: isOrphaned ? '#555' : '#3498db', cursor: isOrphaned ? 'not-allowed' : 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center' }}
                                >
                                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                                    <path d="M19 12H5M12 19l-7-7 7-7"/>
                                  </svg>
                                </button>
                              </td>
                              <td className="preview-cell" style={{ width: '100px', minWidth: '100px', background: '#1e1e1e', borderBottom: '1px solid #333', textAlign: 'center', padding: '6px 8px' }}>
                                {isOrphaned ? (
                                  <span className="orphaned-thumbnail" title="File deleted">⚠️</span>
                                ) : thumbnails[obj.id] ? (
                                  <img 
                                    src={thumbnails[obj.id]} 
                                    alt="Object" 
                                    className="object-thumbnail"
                                    style={{ maxWidth: '80px', maxHeight: '50px', objectFit: 'contain', borderRadius: '4px', border: '1px solid #333' }}
                                  />
                                ) : loadingThumbnails[obj.id] ? (
                                  <span className="loading-thumbnail" style={{ color: '#888' }}>...</span>
                                ) : (
                                  <button 
                                    className="load-thumbnail-btn"
                                    onClick={() => loadThumbnail(obj)}
                                    title="Load preview"
                                    style={{ background: 'transparent', border: 'none', cursor: 'pointer' }}
                                  >
                                    📷
                                  </button>
                                )}
                              </td>
                              {columns.map(col => {
                                // Get current value for editing - handle subclass columns
                                const getCurrentValue = () => {
                                  if (col.isSubclass) {
                                    return (obj.subclassValues || {})[col.subclassName] || '';
                                  }
                                  return obj[col.id] || '';
                                };
                                
                                return (
                                  <td 
                                    key={col.id}
                                    className={col.editable ? 'editable' : ''}
                                    onClick={() => col.editable && startEditing(obj.id, col.id, getCurrentValue())}
                                    style={{ 
                                      width: getColumnWidth(col.id),
                                      minWidth: getColumnWidth(col.id),
                                      textAlign: getColumnAlignment(col.id),
                                      background: '#1e1e1e',
                                      color: '#fff',
                                      fontWeight: 600,
                                      borderBottom: '1px solid #333',
                                      overflow: 'hidden',
                                      textOverflow: 'ellipsis',
                                      whiteSpace: 'nowrap'
                                    }}
                                  >
                                    {editingCell?.rowId === obj.id && editingCell?.column === col.id ? (
                                      <input
                                        type="text"
                                        className="cell-edit-input"
                                        style={{ background: '#2a2a2a', color: '#fff', border: '1px solid #3498db', padding: '4px 8px', width: '100%', fontWeight: 600 }}
                                        value={editValue}
                                        onChange={(e) => setEditValue(e.target.value)}
                                        onKeyDown={handleEditKeyPress}
                                        onBlur={saveEdit}
                                        autoFocus
                                      />
                                    ) : col.id === 'filename' && isOrphaned ? (
                                      <span className="orphaned-filename" style={{ color: '#e74c3c' }}>
                                        <del>{obj.originalFilename?.replace('.pdf', '') || 'Deleted'}</del>
                                      </span>
                                    ) : (
                                      <span className={col.editable ? 'editable-text' : ''} style={{ color: '#fff', fontWeight: 600 }}>
                                        {getCellValue(obj, col)}
                                      </span>
                                    )}
                                  </td>
                                );
                              })}
                              <td className="delete-cell" style={{ width: '40px', minWidth: '40px', background: '#1e1e1e', borderBottom: '1px solid #333', textAlign: 'center', padding: '4px' }}>
                                <button 
                                  className="delete-object-btn"
                                  onClick={() => handleDeleteObject(obj.id)}
                                  title="Delete this object"
                                  style={{ background: 'transparent', border: 'none', color: '#888', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center' }}
                                >
                                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                                    <path d="M3 6h18M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2"/>
                                  </svg>
                                </button>
                              </td>
                            </tr>
                          );
                        })}
                        {/* Bottom spacer for virtualization */}
                        {visibleEndIndex < classData.length && (
                          <tr style={{ height: (classData.length - visibleEndIndex) * ROW_HEIGHT, padding: 0, border: 'none' }}>
                            <td colSpan={columns.length + 3} style={{ padding: 0, border: 'none', background: '#1e1e1e' }} />
                          </tr>
                        )}
                      </>
                    )}
                  </tbody>
                </table>
              </div>
            </>
          ) : null}
        </div>
      </div>

      {/* New Class Dialog */}
      {showNewClassDialog && (
        <div className="modal-overlay" onClick={() => { setShowNewClassDialog(false); setNewClassParentId(null); setPendingSubclasses([]); setNewSubclassInput(''); }}>
          <div className="modal new-class-modal" onClick={(e) => e.stopPropagation()} style={{ maxWidth: '450px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
              <h2 style={{ margin: 0, fontSize: '18px', fontWeight: 700, color: '#fff' }}>{newClassParentId ? 'Create Subclass' : 'Create New Class'}</h2>
              <button 
                onClick={() => { setShowNewClassDialog(false); setNewClassParentId(null); setPendingSubclasses([]); setNewSubclassInput(''); }}
                style={{ background: 'none', border: 'none', color: '#666', fontSize: '20px', cursor: 'pointer', padding: '4px', lineHeight: 1 }}
              >
                ×
              </button>
            </div>
            
            {/* Parent class info if creating subclass (only shows when Add Subclass clicked) */}
            {newClassParentId && (
              <div style={{ background: 'rgba(52, 152, 219, 0.1)', border: '1px solid rgba(52, 152, 219, 0.2)', borderRadius: '6px', padding: '10px 12px', marginBottom: '16px' }}>
                <span style={{ color: '#888', fontSize: '12px' }}>Parent: </span>
                <strong style={{ color: '#3498db', fontSize: '12px' }}>{getClassPath(allProjectClasses.find(c => c.id === newClassParentId))}</strong>
              </div>
            )}
            
            <div style={{ marginBottom: '16px' }}>
              <label style={{ display: 'block', color: '#fff', fontWeight: 600, fontSize: '13px', marginBottom: '8px' }}>
                {newClassParentId ? 'Subclass Name' : 'Class Name'}
              </label>
              <input
                type="text"
                placeholder={newClassParentId ? "e.g., FI, FT, PI" : "e.g., Valve, Pump, Instrument"}
                value={newClassName}
                onChange={(e) => setNewClassName(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && newClassName.trim() && handleCreateClass()}
                autoFocus
                style={{ 
                  width: '100%', 
                  padding: '10px 12px', 
                  border: '1px solid #444', 
                  borderRadius: '6px', 
                  background: '#1e1e1e', 
                  color: '#fff',
                  fontSize: '14px',
                  boxSizing: 'border-box'
                }}
              />
            </div>
            
            {/* Subclasses section - only show for new root classes */}
            {!newClassParentId && (
              <div style={{ marginBottom: '16px' }}>
                <label style={{ display: 'block', color: '#fff', fontWeight: 600, fontSize: '13px', marginBottom: '8px' }}>
                  Subclasses <span style={{ color: '#666', fontWeight: 400 }}>(optional)</span>
                </label>
                
                {pendingSubclasses.length > 0 && (
                  <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px', marginBottom: '10px' }}>
                    {pendingSubclasses.map((sub, idx) => (
                      <div key={idx} style={{ display: 'flex', alignItems: 'center', gap: '6px', background: '#2a2a2a', border: '1px solid #444', borderRadius: '4px', padding: '4px 8px', fontSize: '12px', color: '#fff' }}>
                        <span>{sub}</span>
                        <button 
                          onClick={() => setPendingSubclasses(prev => prev.filter((_, i) => i !== idx))}
                          style={{ background: 'none', border: 'none', color: '#888', cursor: 'pointer', padding: 0, fontSize: '14px', lineHeight: 1 }}
                        >
                          ×
                        </button>
                      </div>
                    ))}
                  </div>
                )}
                
                <div style={{ display: 'flex', gap: '8px' }}>
                  <input
                    type="text"
                    placeholder="Add subclass name..."
                    value={newSubclassInput || ''}
                    onChange={(e) => setNewSubclassInput(e.target.value)}
                    onKeyPress={(e) => {
                      if (e.key === 'Enter' && newSubclassInput?.trim()) {
                        const subName = newSubclassInput.trim();
                        if (pendingSubclasses.some(s => s.toLowerCase() === subName.toLowerCase())) {
                          alert(`Subclass "${subName}" is already added.`);
                          return;
                        }
                        setPendingSubclasses(prev => [...prev, subName]);
                        setNewSubclassInput('');
                        e.preventDefault();
                      }
                    }}
                    style={{ 
                      flex: 1, 
                      padding: '8px 12px', 
                      border: '1px solid #444', 
                      borderRadius: '6px', 
                      background: '#1e1e1e', 
                      color: '#fff',
                      fontSize: '13px'
                    }}
                  />
                  <button
                    type="button"
                    onClick={() => {
                      if (newSubclassInput?.trim()) {
                        const subName = newSubclassInput.trim();
                        if (pendingSubclasses.some(s => s.toLowerCase() === subName.toLowerCase())) {
                          alert(`Subclass "${subName}" is already added.`);
                          return;
                        }
                        setPendingSubclasses(prev => [...prev, subName]);
                        setNewSubclassInput('');
                      }
                    }}
                    disabled={!newSubclassInput?.trim()}
                    style={{ 
                      padding: '8px 12px', 
                      background: newSubclassInput?.trim() ? '#3498db' : '#333', 
                      border: 'none', 
                      borderRadius: '6px', 
                      color: newSubclassInput?.trim() ? '#fff' : '#666', 
                      fontSize: '13px', 
                      fontWeight: 600,
                      cursor: newSubclassInput?.trim() ? 'pointer' : 'not-allowed'
                    }}
                  >
                    + Add
                  </button>
                </div>
                
                <small style={{ display: 'block', color: '#666', fontSize: '11px', marginTop: '8px' }}>
                  Press Enter or click Add to add each subclass. You can add more later.
                </small>
              </div>
            )}
            
            <div className="modal-buttons" style={{ borderTop: '1px solid #333', paddingTop: '16px', marginTop: '0' }}>
              <button 
                onClick={() => { setShowNewClassDialog(false); setNewClassParentId(null); setPendingSubclasses([]); setNewSubclassInput(''); }}
                style={{ background: 'transparent', border: '1px solid #444', color: '#aaa', padding: '8px 16px', borderRadius: '6px', cursor: 'pointer' }}
              >
                Cancel
              </button>
              <button 
                className="primary-btn"
                onClick={handleCreateClass}
                disabled={!newClassName.trim()}
                style={{ background: newClassName.trim() ? '#3498db' : '#444', border: 'none', color: newClassName.trim() ? '#fff' : '#666', fontWeight: 600, padding: '8px 16px', borderRadius: '6px', cursor: newClassName.trim() ? 'pointer' : 'not-allowed' }}
              >
                {newClassParentId ? 'Create Subclass' : 'Create Class'}
                {!newClassParentId && pendingSubclasses.length > 0 && ` + ${pendingSubclasses.length} subclasses`}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add Column Dialog */}
      {showAddColumnDialog && (
        <div className="modal-overlay" onClick={() => { setShowAddColumnDialog(false); setNewColumnName(''); }}>
          <div className="modal" onClick={(e) => e.stopPropagation()} style={{ maxWidth: '400px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
              <h2 style={{ margin: 0, fontSize: '18px', fontWeight: 700, color: '#fff' }}>Add New Column</h2>
              <button 
                onClick={() => { setShowAddColumnDialog(false); setNewColumnName(''); }}
                style={{ background: 'none', border: 'none', color: '#666', fontSize: '20px', cursor: 'pointer', padding: '4px', lineHeight: 1 }}
              >
                ×
              </button>
            </div>
            <div style={{ marginBottom: '20px' }}>
              <label style={{ display: 'block', color: '#fff', fontWeight: 600, fontSize: '13px', marginBottom: '8px' }}>
                Column Name
              </label>
              <input
                type="text"
                placeholder="e.g., Status, Notes, Priority"
                value={newColumnName}
                onChange={(e) => setNewColumnName(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && newColumnName.trim() && handleAddColumn()}
                autoFocus
                style={{ 
                  width: '100%', 
                  padding: '10px 12px', 
                  border: '1px solid #444', 
                  borderRadius: '6px', 
                  background: '#1e1e1e', 
                  color: '#fff',
                  fontSize: '14px',
                  boxSizing: 'border-box'
                }}
              />
            </div>
            <div className="modal-buttons" style={{ borderTop: '1px solid #333', paddingTop: '16px', marginTop: '0' }}>
              <button 
                onClick={() => { setShowAddColumnDialog(false); setNewColumnName(''); }}
                style={{ background: 'transparent', border: '1px solid #444', color: '#aaa', padding: '8px 16px', borderRadius: '6px', cursor: 'pointer' }}
              >
                Cancel
              </button>
              <button 
                className="primary-btn"
                onClick={handleAddColumn}
                disabled={!newColumnName.trim()}
                style={{ background: newColumnName.trim() ? '#3498db' : '#444', border: 'none', color: newColumnName.trim() ? '#fff' : '#666', fontWeight: 600, padding: '8px 16px', borderRadius: '6px', cursor: newColumnName.trim() ? 'pointer' : 'not-allowed' }}
              >
                Add Column
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add Subclass Dialog */}
      {showAddSubclassDialog && (
        <div className="modal-overlay" onClick={() => { setShowAddSubclassDialog(false); setNewSubclassName(''); }}>
          <div className="modal" onClick={(e) => e.stopPropagation()} style={{ maxWidth: '400px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
              <h2 style={{ margin: 0, fontSize: '18px', fontWeight: 700, color: '#fff' }}>Add Subclass</h2>
              <button 
                onClick={() => { setShowAddSubclassDialog(false); setNewSubclassName(''); }}
                style={{ background: 'none', border: 'none', color: '#666', fontSize: '20px', cursor: 'pointer', padding: '4px', lineHeight: 1 }}
              >
                ×
              </button>
            </div>
            <p style={{ color: '#888', fontSize: '13px', margin: '0 0 20px' }}>Add a subclass column to "{selectedClass?.name}"</p>
            <div style={{ marginBottom: '20px' }}>
              <label style={{ display: 'block', color: '#fff', fontWeight: 600, fontSize: '13px', marginBottom: '8px' }}>
                Subclass Name
              </label>
              <input
                type="text"
                placeholder="e.g., Tag Number, Size, Type"
                value={newSubclassName}
                onChange={(e) => setNewSubclassName(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && newSubclassName.trim() && handleAddSubclass()}
                autoFocus
                style={{ 
                  width: '100%', 
                  padding: '10px 12px', 
                  border: '1px solid #444', 
                  borderRadius: '6px', 
                  background: '#1e1e1e', 
                  color: '#fff',
                  fontSize: '14px',
                  boxSizing: 'border-box'
                }}
              />
            </div>
            <div className="modal-buttons" style={{ borderTop: '1px solid #333', paddingTop: '16px', marginTop: '0' }}>
              <button 
                onClick={() => { setShowAddSubclassDialog(false); setNewSubclassName(''); }}
                style={{ background: 'transparent', border: '1px solid #444', color: '#aaa', padding: '8px 16px', borderRadius: '6px', cursor: 'pointer' }}
              >
                Cancel
              </button>
              <button 
                className="primary-btn"
                onClick={handleAddSubclass}
                disabled={!newSubclassName.trim()}
                style={{ background: newSubclassName.trim() ? '#3498db' : '#444', border: 'none', color: newSubclassName.trim() ? '#fff' : '#666', fontWeight: 600, padding: '8px 16px', borderRadius: '6px', cursor: newSubclassName.trim() ? 'pointer' : 'not-allowed' }}
              >
                Add Subclass
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Import Dialog */}
      {showImportDialog && (
        <div className="modal-overlay" onClick={() => { setShowImportDialog(false); setImportData(null); setImportError(null); }}>
          <div className="modal import-modal" onClick={(e) => e.stopPropagation()}>
            <h2>Import Objects</h2>
            
            {importError ? (
              <div className="import-error">
                <span className="error-icon">⚠️</span>
                <p>{importError}</p>
              </div>
            ) : importData ? (
              <>
                <div className="import-summary">
                  <p><strong>File:</strong> {importData.fileName}</p>
                  <p><strong>Format:</strong> {importData.format.toUpperCase()}</p>
                  <p><strong>Objects found:</strong> {importData.objects.length}</p>
                  
                  {/* Preview first few objects */}
                  <div className="import-preview">
                    <p className="preview-label">Preview (first 3 objects):</p>
                    <div className="preview-list">
                      {importData.objects.slice(0, 3).map((obj, i) => (
                        <div key={i} className="preview-item">
                          <span className="preview-class">{obj.label || obj.className || 'Unknown'}</span>
                          <span className="preview-file">{obj.filename || 'No file'}</span>
                        </div>
                      ))}
                      {importData.objects.length > 3 && (
                        <div className="preview-more">...and {importData.objects.length - 3} more</div>
                      )}
                    </div>
                  </div>
                </div>
                
                <div className="import-mode">
                  <p className="mode-label">Import Mode:</p>
                  <div className="mode-toggle">
                    <button 
                      className={`mode-btn ${importMode === 'merge' ? 'active' : ''}`}
                      onClick={() => setImportMode('merge')}
                    >
                      <span className="mode-title">Merge</span>
                      <span className="mode-desc">Add new, update existing</span>
                    </button>
                    <button 
                      className={`mode-btn ${importMode === 'replace' ? 'active' : ''}`}
                      onClick={() => setImportMode('replace')}
                    >
                      <span className="mode-title">Replace All</span>
                      <span className="mode-desc">Clear & import fresh</span>
                    </button>
                  </div>
                </div>
              </>
            ) : (
              <p>Processing file...</p>
            )}
            
            <div className="modal-buttons">
              <button onClick={() => { setShowImportDialog(false); setImportData(null); setImportError(null); }}>
                Cancel
              </button>
              {importData && !importError && (
                <button 
                  className="primary-btn"
                  onClick={handleImport}
                >
                  Import {importData.objects.length} Objects
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Reassign Orphaned Objects Dialog */}
      {showReassignDialog && (
        <div className="modal-overlay" onClick={() => { setShowReassignDialog(false); setReassignSourceFile(null); setReassignTargetFile(null); }}>
          <div className="modal reassign-modal" onClick={(e) => e.stopPropagation()}>
            <h2>Reassign Orphaned Objects</h2>
            
            <div className="form-group">
              <label>Source File (deleted)</label>
              <select
                value={reassignSourceFile || ''}
                onChange={(e) => {
                  setReassignSourceFile(e.target.value || null);
                  setReassignTargetFile(null);
                }}
              >
                <option value="">-- Select source file --</option>
                {orphanedObjectsInfo.fileNames.map(filename => (
                  <option key={filename} value={filename}>
                    {filename} ({orphanedObjectsInfo.byFile[filename]?.length} objects)
                  </option>
                ))}
              </select>
            </div>
            
            {reassignSourceFile && (
              <div className="form-group">
                <label>Target File (reassign to)</label>
                <select
                  value={reassignTargetFile?.id || ''}
                  onChange={(e) => {
                    const file = allProjectFiles.find(f => f.id === e.target.value);
                    setReassignTargetFile(file || null);
                  }}
                >
                  <option value="">-- Select target file --</option>
                  {allProjectFiles.map(file => (
                    <option key={file.id} value={file.id}>
                      {file.name}
                    </option>
                  ))}
                </select>
              </div>
            )}
            
            {reassignSourceFile && reassignTargetFile && (
              <div className="reassign-info-box">
                <div className="reassign-info-icon">📦</div>
                <div className="reassign-info-content">
                  <strong>Keep Existing Boxes</strong>
                  <p>Reassign all bounding boxes to the new file as-is. Best when the layout hasn't changed.</p>
                </div>
              </div>
            )}
            
            <div className="modal-buttons">
              <button onClick={() => { setShowReassignDialog(false); setReassignSourceFile(null); setReassignTargetFile(null); }}>
                Cancel
              </button>
              {reassignSourceFile && reassignTargetFile && (
                <button 
                  className="primary-btn"
                  onClick={handleReassignKeepBoxes}
                  disabled={isReassigning}
                >
                  {isReassigning ? 'Reassigning...' : 'Confirm'}
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Delete All Orphaned Dialog */}
      {showDeleteOrphanedDialog && (
        <div className="modal-overlay" onClick={() => setShowDeleteOrphanedDialog(false)}>
          <div className="modal delete-orphaned-modal" onClick={(e) => e.stopPropagation()}>
            <h2>Delete Orphaned Objects</h2>
            <p className="modal-description">
              You are about to delete {orphanedObjectsInfo.total} orphaned object{orphanedObjectsInfo.total !== 1 ? 's' : ''}. 
              What would you like to do?
            </p>
            
            <div className="delete-orphaned-options">
              <button 
                className="delete-option-btn redetect-option"
                onClick={deleteOrphanedAndRedetect}
              >
                <span className="option-icon">🔄</span>
                <span className="option-content">
                  <strong>Delete & Re-detect</strong>
                  <small>Delete all orphaned objects and open the Object Finder to run detection on your files.</small>
                </span>
              </button>
              
              <button 
                className="delete-option-btn delete-only-option"
                onClick={confirmDeleteAllOrphaned}
              >
                <span className="option-icon">🗑️</span>
                <span className="option-content">
                  <strong>Delete Only</strong>
                  <small>Permanently delete all orphaned objects without re-detecting.</small>
                </span>
              </button>
            </div>
            
            <div className="modal-buttons">
              <button onClick={() => setShowDeleteOrphanedDialog(false)}>
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
