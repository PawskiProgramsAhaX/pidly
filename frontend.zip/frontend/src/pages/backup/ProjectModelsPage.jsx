import { useState, useEffect, useRef, useCallback } from 'react';
import { useParams, useNavigate, useLocation } from 'react-router-dom';
import { getProject, getModels, deleteModel, getPdfFromBackend, trainDetector, saveModel, captureRegion, runDetection } from '../utils/storage';
import './ProjectModelsPage.css';

export default function ProjectModelsPage() {
  const { projectId } = useParams();
  const navigate = useNavigate();
  const location = useLocation();
  const returnToFile = location.state?.returnToFile || null;
  const [project, setProject] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [models, setModels] = useState([]);
  const [selectedItem, setSelectedItem] = useState('home'); // 'home' or model id
  const [searchQuery, setSearchQuery] = useState('');
  const [sidebarWidth, setSidebarWidth] = useState(() => {
    const saved = localStorage.getItem('models_sidebar_width');
    return saved ? parseInt(saved, 10) : 280;
  });
  const [isResizingSidebar, setIsResizingSidebar] = useState(false);
  const [modelsSectionHeight, setModelsSectionHeight] = useState(() => {
    const saved = localStorage.getItem('models_section_height');
    return saved ? parseInt(saved, 10) : 250;
  });
  const [isResizingModels, setIsResizingModels] = useState(false);
  
  // PDF upload state - now uses project files instead
  const [projectFiles, setProjectFiles] = useState([]); // All PDFs from project
  const [selectedPdf, setSelectedPdf] = useState(null);
  const [pdfSearchQuery, setPdfSearchQuery] = useState('');
  
  // PDF viewer state
  const canvasRef = useRef(null);
  const containerRef = useRef(null);
  const [pdfDoc, setPdfDoc] = useState(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [numPages, setNumPages] = useState(0);
  const [scale, setScale] = useState(1);
  const [canvasSize, setCanvasSize] = useState({ width: 0, height: 0 });
  const [isRendering, setIsRendering] = useState(false);
  
  // Pan/zoom state
  const [panOffset, setPanOffset] = useState({ x: 0, y: 0 });
  const [isPanning, setIsPanning] = useState(false);
  const [panStart, setPanStart] = useState({ x: 0, y: 0 });
  
  // Drawing state
  const [isDrawing, setIsDrawing] = useState(false);
  const [drawStart, setDrawStart] = useState(null);
  const [currentRect, setCurrentRect] = useState(null);
  const [trainingBoxes, setTrainingBoxes] = useState([]);
  
  // Shape type state
  const [drawingShapeType, setDrawingShapeType] = useState('rectangle'); // 'rectangle', 'circle'
  
  // Pending shape confirmation
  const [pendingShape, setPendingShape] = useState(null);
  const [activeResizeHandle, setActiveResizeHandle] = useState(null);
  
  // Subclass region state
  const [showSubclassDialog, setShowSubclassDialog] = useState(false);
  const [currentSubclassIndex, setCurrentSubclassIndex] = useState(0);
  const [subclassRegions, setSubclassRegions] = useState({});
  const [subclassDrawStart, setSubclassDrawStart] = useState(null);
  const [subclassCurrentRect, setSubclassCurrentRect] = useState(null);
  const [subclassImageData, setSubclassImageData] = useState(null);
  const [subclassDialogSize, setSubclassDialogSize] = useState({ width: 600, height: 650 });
  const [isResizingDialog, setIsResizingDialog] = useState(false);
  const [dialogResizeStart, setDialogResizeStart] = useState(null);
  const [subclassImageZoom, setSubclassImageZoom] = useState(1.0);
  const [isCapturingRegion, setIsCapturingRegion] = useState(false);
  
  // Training state
  const [modelName, setModelName] = useState('');
  const [isTraining, setIsTraining] = useState(false);
  const [selectedClass, setSelectedClass] = useState('');
  const [projectClasses, setProjectClasses] = useState([]);
  const [trainingMode, setTrainingMode] = useState('separate'); // 'separate' or 'combined'
  const [addToExistingModel, setAddToExistingModel] = useState(null); // model ID to add templates to
  const [multiOrientation, setMultiOrientation] = useState(false); // Detect all orientations (0°, 90°, 180°, 270°)
  const [includeInverted, setIncludeInverted] = useState(false); // Include horizontally flipped (mirrored) templates

  // Import/Export state
  const [showImportDialog, setShowImportDialog] = useState(false);
  const [importData, setImportData] = useState(null);
  const [importError, setImportError] = useState(null);
  const [importMode, setImportMode] = useState('merge');
  const modelFileInputRef = useRef(null);
  
  // Template viewing state
  const [showTemplates, setShowTemplates] = useState(false);
  const [templateImages, setTemplateImages] = useState([]);
  const [isLoadingTemplates, setIsLoadingTemplates] = useState(false);
  
  // Test model state
  const [showTestPanel, setShowTestPanel] = useState(false);
  const [testConfidence, setTestConfidence] = useState(0.7);
  const [testOcrFormat, setTestOcrFormat] = useState('');
  const [testResults, setTestResults] = useState([]);
  const [isTesting, setIsTesting] = useState(false);
  const [testModelId, setTestModelId] = useState(null);
  
  // Editable recommended settings state (for model details view)
  const [editConfidence, setEditConfidence] = useState(0.7);
  const [editOcrFormat, setEditOcrFormat] = useState('');

  // Helper function to recursively extract all files from folders
  const extractAllFiles = (folders, parentPath = '') => {
    let allFiles = [];
    (folders || []).forEach(folder => {
      const folderPath = parentPath ? `${parentPath} / ${folder.name}` : folder.name;
      (folder.files || []).forEach(file => {
        allFiles.push({
          id: file.id,
          name: file.name,
          backendFilename: file.backendFilename,
          folderId: folder.id,
          folderName: folderPath
        });
      });
      // Recursively get files from subfolders
      if (folder.subfolders && folder.subfolders.length > 0) {
        allFiles = [...allFiles, ...extractAllFiles(folder.subfolders, folderPath)];
      }
    });
    return allFiles;
  };

  // Get subclasses for a class
  const getSubclasses = (className) => {
    if (!project?.classes) return [];
    const parentClass = project.classes.find(c => c.name === className && !c.parentId);
    if (!parentClass) return [];
    return project.classes.filter(c => c.parentId === parentClass.id).map(c => c.name);
  };

  // Load project
  useEffect(() => {
    const loadProject = async () => {
      try {
        const loadedProject = await getProject(projectId);
        if (loadedProject) {
          setProject(loadedProject);
          // Extract root classes (no parentId)
          const classes = (loadedProject.classes || []).filter(c => !c.parentId);
          setProjectClasses(classes);
          
          // Extract all PDF files from project folders (including subfolders)
          const folderFiles = extractAllFiles(loadedProject.folders || []);
          
          // Get root-level files (files not in any folder)
          const rootFiles = (loadedProject.files || []).map(file => ({
            id: file.id,
            name: file.name,
            backendFilename: file.backendFilename,
            folderId: null,
            folderName: '(Root)'
          }));
          
          // Combine both
          setProjectFiles([...rootFiles, ...folderFiles]);
        } else {
          navigate('/');
        }
      } catch (error) {
        console.error('Error loading project:', error);
        navigate('/');
      } finally {
        setIsLoading(false);
      }
    };

    loadProject();
  }, [projectId, navigate]);

  // Initialize PDF.js
  useEffect(() => {
    if (!window.pdfjsLib) {
      const script = document.createElement('script');
      script.src = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js';
      script.onload = () => {
        window.pdfjsLib.GlobalWorkerOptions.workerSrc = 
          'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';
      };
      document.head.appendChild(script);
    }
  }, []);

  // Load PDF when selected
  useEffect(() => {
    const loadSelectedPdf = async () => {
      if (selectedPdf?.backendFilename && window.pdfjsLib) {
        try {
          const blobUrl = await getPdfFromBackend(selectedPdf.backendFilename);
          loadPdf(blobUrl);
        } catch (error) {
          console.error('Error loading PDF:', error);
          alert('Failed to load PDF');
        }
      }
    };
    loadSelectedPdf();
  }, [selectedPdf]);

  const loadPdf = async (url) => {
    try {
      const pdf = await window.pdfjsLib.getDocument(url).promise;
      setPdfDoc(pdf);
      setNumPages(pdf.numPages);
      setCurrentPage(1);
      setScale(1);
      setTrainingBoxes([]); // Clear boxes when loading new PDF
    } catch (error) {
      console.error('Error loading PDF:', error);
    }
  };

  // Render PDF page
  const renderPage = useCallback(async () => {
    if (!pdfDoc || !canvasRef.current || isRendering) return;

    setIsRendering(true);
    
    try {
      const page = await pdfDoc.getPage(currentPage);
      const baseScale = 2;
      const viewport = page.getViewport({ scale: baseScale });
      
      const canvas = canvasRef.current;
      const context = canvas.getContext('2d');
      
      canvas.width = viewport.width;
      canvas.height = viewport.height;
      
      const displayWidth = viewport.width / baseScale;
      const displayHeight = viewport.height / baseScale;
      setCanvasSize({ width: displayWidth, height: displayHeight });

      await page.render({
        canvasContext: context,
        viewport: viewport
      }).promise;
      
    } catch (error) {
      console.error('Render error:', error);
    } finally {
      setIsRendering(false);
    }
  }, [pdfDoc, currentPage]);

  useEffect(() => {
    if (pdfDoc) {
      renderPage();
    }
  }, [pdfDoc, currentPage, renderPage]);

  // Load models
  useEffect(() => {
    const loadModels = async () => {
      try {
        const loadedModels = await getModels(projectId);
        setModels(loadedModels || []);
      } catch (error) {
        console.error('Error loading models:', error);
        setModels([]);
      }
    };

    if (project) {
      loadModels();
    }
  }, [project, projectId]);

  // Sync edit state with selected model
  useEffect(() => {
    if (selectedItem && selectedItem !== 'home') {
      const model = models.find(m => m.id === selectedItem);
      if (model) {
        setEditConfidence(model.recommendedConfidence || 0.7);
        setEditOcrFormat(model.recommendedOcrFormat || '');
      }
    }
  }, [selectedItem, models]);

  // Sidebar resize handlers
  const handleSidebarMouseDown = (e) => {
    e.preventDefault();
    setIsResizingSidebar(true);
    document.body.style.userSelect = 'none';
  };

  // Handle models section resize
  const handleModelsSectionResizeStart = (e) => {
    e.preventDefault();
    setIsResizingModels(true);
    document.body.style.userSelect = 'none';
  };

  useEffect(() => {
    const handleMouseMove = (e) => {
      if (isResizingSidebar) {
        const newWidth = Math.max(200, Math.min(500, e.clientX));
        setSidebarWidth(newWidth);
      }
      if (isResizingModels) {
        // Get the sidebar element to calculate relative position
        const sidebar = document.querySelector('.models-sidebar');
        if (sidebar) {
          const sidebarRect = sidebar.getBoundingClientRect();
          const relativeY = e.clientY - sidebarRect.top - 100; // Account for header and home button
          const newHeight = Math.max(100, Math.min(500, relativeY));
          setModelsSectionHeight(newHeight);
        }
      }
    };

    const handleMouseUp = () => {
      setIsResizingSidebar(false);
      setIsResizingModels(false);
      document.body.style.userSelect = '';
    };

    if (isResizingSidebar || isResizingModels) {
      document.addEventListener('mousemove', handleMouseMove);
      document.addEventListener('mouseup', handleMouseUp);
    }

    return () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
    };
  }, [isResizingSidebar, isResizingModels]);

  // Save layout settings to localStorage when resize finishes
  useEffect(() => {
    if (!isResizingSidebar) {
      localStorage.setItem('models_sidebar_width', sidebarWidth.toString());
    }
  }, [isResizingSidebar, sidebarWidth]);

  useEffect(() => {
    if (!isResizingModels) {
      localStorage.setItem('models_section_height', modelsSectionHeight.toString());
    }
  }, [isResizingModels, modelsSectionHeight]);

  // Handle delete model
  const handleDeleteModel = async (modelId, modelName) => {
    if (!confirm(`Delete model "${modelName}"?\n\nThis cannot be undone.`)) {
      return;
    }

    try {
      await deleteModel(modelId);
      setModels(prev => prev.filter(m => m.id !== modelId));
      if (selectedItem === modelId) {
        setSelectedItem('home');
      }
    } catch (error) {
      console.error('Error deleting model:', error);
      alert('Failed to delete model');
    }
  };

  // Export all models as JSON
  const handleExportModels = async () => {
    if (models.length === 0) {
      alert('No models to export');
      return;
    }
    
    try {
      // Download zip file from Flask server
      const response = await fetch('http://localhost:5000/models/export');
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Export failed');
      }
      
      // Get the blob and trigger download
      const blob = await response.blob();
      const link = document.createElement('a');
      link.href = URL.createObjectURL(blob);
      
      // Get filename from Content-Disposition header or use default
      const contentDisposition = response.headers.get('Content-Disposition');
      let filename = `models_export_${new Date().toISOString().slice(0,10)}.zip`;
      if (contentDisposition) {
        const match = contentDisposition.match(/filename=(.+)/);
        if (match) filename = match[1];
      }
      
      link.download = filename;
      link.click();
      URL.revokeObjectURL(link.href);
    } catch (error) {
      console.error('Export failed:', error);
      alert('Export failed: ' + error.message + '\n\nMake sure detector_server.py is running.');
    }
  };

  // Handle file selection for import
  const handleModelFileSelect = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    // Accept both .zip and .json for backward compatibility
    if (file.name.endsWith('.zip')) {
      // New zip format - upload directly to Flask
      setImportData({ file, fileName: file.name, isZip: true });
      setImportError(null);
      setShowImportDialog(true);
    } else if (file.name.endsWith('.json')) {
      // Legacy JSON format
      const reader = new FileReader();
      reader.onload = (event) => {
        try {
          const data = JSON.parse(event.target.result);
          const modelsArray = data.models || data;
          
          if (!Array.isArray(modelsArray)) {
            throw new Error('Invalid format: expected models array');
          }
          
          const validModels = modelsArray.filter(m => m.id && m.className);
          if (validModels.length === 0) {
            throw new Error('No valid models found. Each model needs at least id and className.');
          }
          
          setImportData({ models: validModels, fileName: file.name, isZip: false });
          setImportError(null);
          setShowImportDialog(true);
        } catch (error) {
          setImportError(error.message);
          setImportData(null);
          setShowImportDialog(true);
        }
      };
      reader.readAsText(file);
    } else {
      alert('Please select a .zip file (exported models) or .json file (legacy format)');
    }
    e.target.value = ''; // Reset input
  };

  // Execute import
  const handleImportModels = async () => {
    if (!importData) return;
    
    try {
      if (importData.isZip) {
        // Upload zip to Flask server
        const formData = new FormData();
        formData.append('file', importData.file);
        
        const endpoint = importMode === 'replace' 
          ? 'http://localhost:5000/models/import-overwrite'
          : 'http://localhost:5000/models/import';
        
        const response = await fetch(endpoint, {
          method: 'POST',
          body: formData
        });
        
        const result = await response.json();
        
        if (!response.ok) {
          throw new Error(result.error || 'Import failed');
        }
        
        // Reload models from backend
        const loadedModels = await getModels(projectId);
        setModels(loadedModels || []);
        
        let message = `Successfully imported ${result.imported?.length || 0} model(s)`;
        if (result.skipped?.length > 0) {
          message += `\nSkipped ${result.skipped.length} existing model(s)`;
        }
        if (result.overwritten?.length > 0) {
          message += `\nOverwritten ${result.overwritten.length} existing model(s)`;
        }
        
        alert(message);
      } else {
        // Legacy JSON import (metadata only)
        let newModels;
        
        if (importMode === 'replace') {
          for (const model of models) {
            await deleteModel(model.id);
          }
          newModels = importData.models;
        } else {
          const existingById = new Map(models.map(m => [m.id, m]));
          importData.models.forEach(importModel => {
            existingById.set(importModel.id, { ...existingById.get(importModel.id), ...importModel });
          });
          newModels = Array.from(existingById.values());
        }
        
        for (const model of newModels) {
          await saveModel(model);
        }
        
        const loadedModels = await getModels(projectId);
        setModels(loadedModels || []);
        
        alert(`Imported ${importData.models.length} model settings (JSON only - detection requires .pkl files)`);
      }
      
      setShowImportDialog(false);
      setImportData(null);
      setImportError(null);
    } catch (error) {
      console.error('Import failed:', error);
      alert('Import failed: ' + error.message);
    }
  };

  // Handle selecting a project PDF for training
  const handleSelectPdf = (file) => {
    setSelectedPdf(file);
    setTrainingBoxes([]); // Clear boxes when switching PDFs
    setPendingShape(null);
    setPanOffset({ x: 0, y: 0 });
    setScale(1);
  };

  // Filter project files by search
  const filteredProjectFiles = projectFiles.filter(file =>
    file.name.toLowerCase().includes(pdfSearchQuery.toLowerCase()) ||
    file.folderName?.toLowerCase().includes(pdfSearchQuery.toLowerCase())
  );

  // Key handlers for escape and page navigation
  useEffect(() => {
    const handleKeyDown = (e) => {
      if (e.key === 'Escape') {
        // Cancel current drawing
        setIsDrawing(false);
        setCurrentRect(null);
        setDrawStart(null);
        // Cancel pending shape
        setPendingShape(null);
        setActiveResizeHandle(null);
        // Clear subclass data
        setSubclassRegions({});
        setSubclassImageData(null);
        // Deselect class (go back to home/pan mode)
        setSelectedClass('');
      }
      
      // Page navigation shortcuts (only when PDF is loaded and not in an input)
      if (pdfDoc && numPages > 1 && !e.target.matches('input, textarea, select')) {
        if (e.key === 'PageDown' || (e.key === 'ArrowRight' && e.altKey)) {
          e.preventDefault();
          setCurrentPage(p => Math.min(numPages, p + 1));
        } else if (e.key === 'PageUp' || (e.key === 'ArrowLeft' && e.altKey)) {
          e.preventDefault();
          setCurrentPage(p => Math.max(1, p - 1));
        }
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [pdfDoc, numPages]);

  // Wheel zoom handler - zoom towards cursor like single view
  useEffect(() => {
    const container = containerRef.current;
    if (!container || !pdfDoc) return;

    const handleWheel = (e) => {
      // Always zoom when scrolling on PDF area (no Ctrl required)
      e.preventDefault();
      e.stopPropagation();
      
      const oldScale = scale;
      // Multiplicative zoom - each tick multiplies/divides by factor
      const factor = 1.25;
      const newScale = e.deltaY > 0 
        ? Math.max(0.25, oldScale / factor)
        : Math.min(5, oldScale * factor);
      
      if (newScale === oldScale) return;
      
      // Get container rect for calculations
      const rect = container.getBoundingClientRect();
      
      // Mouse position relative to container
      const mouseX = e.clientX - rect.left;
      const mouseY = e.clientY - rect.top;
      
      // Calculate where the mouse is pointing on the PDF (in unscaled coordinates)
      // Account for pan offset
      const pdfX = (mouseX - panOffset.x) / oldScale;
      const pdfY = (mouseY - panOffset.y) / oldScale;
      
      // Calculate new pan offset to keep the same PDF point under cursor
      const newPanX = mouseX - pdfX * newScale;
      const newPanY = mouseY - pdfY * newScale;
      
      // Constrain pan to reasonable bounds
      const pdfWidth = canvasSize.width * newScale;
      const pdfHeight = canvasSize.height * newScale;
      const margin = 100;
      
      const minX = Math.min(0, rect.width - pdfWidth - margin);
      const maxX = margin;
      const minY = Math.min(0, rect.height - pdfHeight - margin);
      const maxY = margin;
      
      setPanOffset({
        x: Math.max(minX, Math.min(maxX, newPanX)),
        y: Math.max(minY, Math.min(maxY, newPanY))
      });
      setScale(newScale);
    };

    container.addEventListener('wheel', handleWheel, { passive: false });
    return () => container.removeEventListener('wheel', handleWheel);
  }, [pdfDoc, scale, panOffset, canvasSize]);

  // Pan handlers
  useEffect(() => {
    if (!isPanning) return;

    const handleMouseMove = (e) => {
      const container = containerRef.current;
      if (!container) return;
      
      const containerRect = container.getBoundingClientRect();
      const pdfWidth = canvasSize.width * scale;
      const pdfHeight = canvasSize.height * scale;
      
      // Allow some margin (100px) beyond edges
      const margin = 100;
      
      setPanOffset(prev => {
        let newX = prev.x + e.movementX;
        let newY = prev.y + e.movementY;
        
        // Constrain X: don't let PDF go too far right or left
        const minX = Math.min(0, containerRect.width - pdfWidth - margin);
        const maxX = margin;
        newX = Math.max(minX, Math.min(maxX, newX));
        
        // Constrain Y: don't let PDF go too far down or up
        const minY = Math.min(0, containerRect.height - pdfHeight - margin);
        const maxY = margin;
        newY = Math.max(minY, Math.min(maxY, newY));
        
        return { x: newX, y: newY };
      });
    };

    const handleMouseUp = () => {
      setIsPanning(false);
    };

    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseUp);

    return () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
    };
  }, [isPanning, canvasSize, scale]);

  // Dialog resize handler
  useEffect(() => {
    if (!isResizingDialog || !dialogResizeStart) return;
    
    const handleMouseMove = (e) => {
      const dx = e.clientX - dialogResizeStart.x;
      const dy = e.clientY - dialogResizeStart.y;
      
      let newWidth = dialogResizeStart.width;
      let newHeight = dialogResizeStart.height;
      
      if (dialogResizeStart.direction === 'e' || dialogResizeStart.direction === 'se') {
        newWidth = Math.max(400, Math.min(window.innerWidth * 0.95, dialogResizeStart.width + dx));
      }
      if (dialogResizeStart.direction === 's' || dialogResizeStart.direction === 'se') {
        newHeight = Math.max(400, Math.min(window.innerHeight * 0.95, dialogResizeStart.height + dy));
      }
      
      setSubclassDialogSize({ width: newWidth, height: newHeight });
    };
    
    const handleMouseUp = () => {
      setIsResizingDialog(false);
      setDialogResizeStart(null);
    };
    
    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseUp);
    
    return () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
    };
  }, [isResizingDialog, dialogResizeStart]);

  // Resize handle mouse move/up
  useEffect(() => {
    if (!activeResizeHandle || !pendingShape) return;
    
    const handleMouseMove = (e) => {
      const canvas = canvasRef.current;
      if (!canvas) return;
      
      const rect = canvas.getBoundingClientRect();
      // Account for pan offset when calculating mouse position
      const mouseX = (e.clientX - rect.left) / scale / canvasSize.width;
      const mouseY = (e.clientY - rect.top) / scale / canvasSize.height;
      
      // Clamp mouse coordinates to valid range
      const clampedX = Math.max(0, Math.min(1, mouseX));
      const clampedY = Math.max(0, Math.min(1, mouseY));
      
      let newShape = { ...pendingShape };
      const minSize = 0.01; // Minimum size (1% of canvas)
      
      if (activeResizeHandle.includes('e')) {
        const newWidth = clampedX - newShape.x;
        if (newWidth > minSize) {
          newShape.width = newWidth;
        }
      }
      if (activeResizeHandle.includes('w')) {
        const newX = clampedX;
        const newWidth = (newShape.x + newShape.width) - newX;
        if (newWidth > minSize && newX >= 0) {
          newShape.x = newX;
          newShape.width = newWidth;
        }
      }
      if (activeResizeHandle.includes('s')) {
        const newHeight = clampedY - newShape.y;
        if (newHeight > minSize) {
          newShape.height = newHeight;
        }
      }
      if (activeResizeHandle.includes('n')) {
        const newY = clampedY;
        const newHeight = (newShape.y + newShape.height) - newY;
        if (newHeight > minSize && newY >= 0) {
          newShape.y = newY;
          newShape.height = newHeight;
        }
      }
      
      setPendingShape(newShape);
    };
    
    const handleMouseUp = () => {
      setActiveResizeHandle(null);
    };
    
    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseUp);
    
    return () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
    };
  }, [activeResizeHandle, pendingShape, scale, canvasSize]);

  // Mouse handlers for drawing boxes
  const handleMouseDown = (e) => {
    // Middle mouse button always pans
    if (e.button === 1) {
      e.preventDefault();
      setIsPanning(true);
      setPanStart({ x: e.clientX - panOffset.x, y: e.clientY - panOffset.y });
      return;
    }
    
    // If no class selected or already have a pending shape, pan instead
    if (!selectedClass || pendingShape) {
      setIsPanning(true);
      setPanStart({ x: e.clientX - panOffset.x, y: e.clientY - panOffset.y });
      return;
    }
    
    if (!canvasRef.current) return;
    
    const canvas = canvasRef.current;
    const rect = canvas.getBoundingClientRect();
    const x = (e.clientX - rect.left) / scale;
    const y = (e.clientY - rect.top) / scale;
    
    // Rectangle / Circle mode
    setIsDrawing(true);
    setDrawStart({ x, y });
    setCurrentRect({ x, y, width: 0, height: 0 });
  };

  const handleMouseMove = (e) => {
    if (!isDrawing || !drawStart || !canvasRef.current) return;
    
    const canvas = canvasRef.current;
    const rect = canvas.getBoundingClientRect();
    const x = (e.clientX - rect.left) / scale;
    const y = (e.clientY - rect.top) / scale;
    
    const width = x - drawStart.x;
    const height = y - drawStart.y;
    
    setCurrentRect({
      x: width < 0 ? x : drawStart.x,
      y: height < 0 ? y : drawStart.y,
      width: Math.abs(width),
      height: Math.abs(height)
    });
  };

  const handleMouseUp = () => {
    if (!isDrawing || !currentRect || !selectedClass) {
      setIsDrawing(false);
      setCurrentRect(null);
      return;
    }
    
    // Only create pending shape if it has some size
    if (currentRect.width > 10 && currentRect.height > 10) {
      const newBox = {
        id: `box_${Date.now()}`,
        x: currentRect.x / canvasSize.width,
        y: currentRect.y / canvasSize.height,
        width: currentRect.width / canvasSize.width,
        height: currentRect.height / canvasSize.height,
        page: currentPage - 1,
        shapeType: drawingShapeType,
      };
      setPendingShape(newBox);
    }
    
    setIsDrawing(false);
    setDrawStart(null);
    setCurrentRect(null);
  };

  // Confirm pending shape - add to training boxes
  const handleConfirmShape = () => {
    if (!pendingShape || !selectedClass) return;
    
    const classData = projectClasses.find(c => c.name === selectedClass);
    const subclasses = getSubclasses(selectedClass);
    
    console.log('=== Confirming shape ===');
    console.log('Pending shape:', pendingShape);
    console.log('Subclass regions (relative to popup):', subclassRegions);
    
    // Convert subclass regions from popup-relative (0-1) to page-absolute (0-1)
    // This way detection can use these coords directly without any transformation
    const absoluteSubclassRegions = {};
    for (const [subName, region] of Object.entries(subclassRegions)) {
      absoluteSubclassRegions[subName] = {
        // Convert from % of popup to % of page
        x: pendingShape.x + (region.x * pendingShape.width),
        y: pendingShape.y + (region.y * pendingShape.height),
        width: region.width * pendingShape.width,
        height: region.height * pendingShape.height,
        // Also store relative coords for reference
        relativeX: region.x,
        relativeY: region.y,
        relativeWidth: region.width,
        relativeHeight: region.height,
      };
      console.log(`Subclass "${subName}" converted:`, {
        relative: region,
        absolute: absoluteSubclassRegions[subName]
      });
    }
    
    const newBox = {
      ...pendingShape,
      className: selectedClass,
      color: classData?.color || '#3498db',
      subclassRegions: absoluteSubclassRegions,
    };
    
    console.log('New training box:', newBox);
    
    setTrainingBoxes(prev => [...prev, newBox]);
    setPendingShape(null);
    setSubclassRegions({});
    setCurrentSubclassIndex(0);
    setSubclassImageData(null);
    setSubclassImageZoom(1.0);
  };

  // Cancel pending shape
  const handleCancelShape = () => {
    setPendingShape(null);
    setSubclassRegions({});
    setCurrentSubclassIndex(0);
    setSubclassImageData(null);
    setSubclassImageZoom(1.0);
  };

  // Capture image from canvas (no padding, high resolution)
  const captureObjectImage = (box, scaleFactor = 3) => {
    if (!canvasRef.current || !box) return null;
    
    const canvas = canvasRef.current;
    
    // Calculate pixel coordinates from normalized coords
    const x = Math.floor(box.x * canvas.width);
    const y = Math.floor(box.y * canvas.height);
    const width = Math.ceil(box.width * canvas.width);
    const height = Math.ceil(box.height * canvas.height);
    
    // Clamp to canvas bounds
    const px = Math.max(0, x);
    const py = Math.max(0, y);
    const pw = Math.min(canvas.width - px, width);
    const ph = Math.min(canvas.height - py, height);
    
    try {
      // Scale up the captured image for better visibility
      const tempCanvas = document.createElement('canvas');
      tempCanvas.width = pw * scaleFactor;
      tempCanvas.height = ph * scaleFactor;
      const tempCtx = tempCanvas.getContext('2d');
      
      // Use better image scaling
      tempCtx.imageSmoothingEnabled = true;
      tempCtx.imageSmoothingQuality = 'high';
      
      // Draw scaled up
      tempCtx.drawImage(canvas, px, py, pw, ph, 0, 0, pw * scaleFactor, ph * scaleFactor);
      
      return tempCanvas.toDataURL('image/png');
    } catch (e) {
      console.error('Error capturing object image:', e);
      return null;
    }
  };

  // Open subclass region dialog
  const handleDefineSubclassRegions = async () => {
    if (!pendingShape) return;
    if (isCapturingRegion) return; // Prevent multiple clicks while loading
    if (!selectedPdf?.backendFilename) {
      alert('No PDF selected');
      return;
    }
    
    console.log('=== Opening Subclass Dialog ===');
    console.log('Pending shape (normalized):', pendingShape);
    
    const bbox = {
      x: pendingShape.x,
      y: pendingShape.y,
      width: pendingShape.width,
      height: pendingShape.height
    };
    
    // Check if we need to re-capture (box changed or no image)
    const bboxKey = `${bbox.x.toFixed(6)}_${bbox.y.toFixed(6)}_${bbox.width.toFixed(6)}_${bbox.height.toFixed(6)}`;
    const needsCapture = !subclassImageData || subclassImageData.bboxKey !== bboxKey;
    
    if (needsCapture) {
      console.log('Capturing fresh region (box changed or first time)');
      setIsCapturingRegion(true);
      try {
        console.log('Capturing region at 300 DPI:', bbox);
        const result = await captureRegion(selectedPdf.backendFilename, currentPage - 1, bbox);
        
        console.log('Captured region:', {
          width: result.width,
          height: result.height,
          dpi: result.dpi,
          aspectRatio: (result.width / result.height).toFixed(3)
        });
        
        // Store image with its bbox key for cache validation
        setSubclassImageData({ image: result.image, bboxKey });
        // Clear regions since the box changed
        setSubclassRegions({});
      } catch (error) {
        console.error('Failed to capture region:', error);
        // Fallback to canvas capture
        const croppedImage = captureObjectImage(pendingShape);
        if (croppedImage) {
          console.log('Falling back to canvas capture');
          setSubclassImageData({ image: croppedImage, bboxKey });
          setSubclassRegions({});
        } else {
          alert('Failed to capture region image');
          setIsCapturingRegion(false);
          return;
        }
      }
      setIsCapturingRegion(false);
    } else {
      console.log('Using cached image (box unchanged)');
    }
    
    // Don't reset regions - preserve any existing ones
    setShowSubclassDialog(true);
    setCurrentSubclassIndex(0);
  };

  // Close subclass dialog (preserves regions)
  const handleCloseSubclassDialog = () => {
    setShowSubclassDialog(false);
  };

  // Remove a training box
  const handleRemoveBox = (boxId) => {
    setTrainingBoxes(prev => prev.filter(b => b.id !== boxId));
  };

  // Train model
  const handleTrain = async () => {
    if (trainingBoxes.length === 0) {
      alert('Please draw at least one training box');
      return;
    }
    
    const uniqueClasses = [...new Set(trainingBoxes.map(b => b.className))];
    
    // For combined mode, model name is required
    // For separate mode with single class, use modelName if provided, else use class name
    if (trainingMode === 'combined' && !modelName.trim()) {
      alert('Please enter a model name');
      return;
    }
    
    // Check for duplicate model names (only when creating new models, not adding to existing)
    if (!addToExistingModel) {
      const finalModelName = trainingMode === 'combined' 
        ? modelName.trim() 
        : (uniqueClasses.length === 1 && modelName.trim() ? modelName.trim() : null);
      
      if (finalModelName) {
        const existingModel = models.find(m => 
          m.className.toLowerCase() === finalModelName.toLowerCase()
        );
        if (existingModel) {
          alert(`A model named "${finalModelName}" already exists.\n\nPlease choose a different name or use "Add to Existing" to add templates to the existing model.`);
          return;
        }
      } else if (trainingMode === 'separate' && uniqueClasses.length > 1) {
        // Check each class name for duplicates
        const duplicates = uniqueClasses.filter(className => 
          models.some(m => m.className.toLowerCase() === className.toLowerCase())
        );
        if (duplicates.length > 0) {
          alert(`Models already exist for: ${duplicates.join(', ')}\n\nPlease use "Add to Existing" to add templates to existing models, or change the class names.`);
          return;
        }
      } else if (trainingMode === 'separate' && uniqueClasses.length === 1 && !modelName.trim()) {
        // Single class without custom name - check if class name exists
        const existingModel = models.find(m => 
          m.className.toLowerCase() === uniqueClasses[0].toLowerCase()
        );
        if (existingModel) {
          alert(`A model named "${uniqueClasses[0]}" already exists.\n\nPlease enter a different name or use "Add to Existing" to add templates to the existing model.`);
          return;
        }
      }
    }
    
    if (!selectedPdf?.backendFilename) {
      alert('No PDF selected');
      return;
    }

    setIsTraining(true);
    
    try {
      // For separate mode with single class and custom name, use that name
      // For separate mode with multiple classes, use original class names
      // For combined mode, use the model name for all boxes
      // For add to existing, use the existing model's class name
      const sanitizedBoxes = trainingBoxes.map(box => {
        let finalClassName;
        
        if (addToExistingModel) {
          // When adding to existing model, use the existing model's class name
          const existingModel = models.find(m => m.id === addToExistingModel);
          finalClassName = existingModel?.className || box.className;
        } else if (trainingMode === 'combined') {
          finalClassName = modelName.trim();
        } else if (uniqueClasses.length === 1 && modelName.trim()) {
          // Single class with custom name
          finalClassName = modelName.trim();
        } else {
          // Multiple classes - use original names
          finalClassName = box.className;
        }
        
        return {
          ...box,
          className: finalClassName.replace(/[<>:"/\\|?*]/g, '-'),
          originalClassName: box.className
        };
      });
      
      const result = await trainDetector(
        selectedPdf.backendFilename,
        sanitizedBoxes,
        multiOrientation, // multiOrientation - detect all orientations
        includeInverted, // includeInverted - include horizontally flipped templates
        addToExistingModel ? 'separate' : trainingMode, // mode - 'separate' or 'combined'
        'object', // modelType
        projectId,
        addToExistingModel || null // addToExistingModel - model ID to add to
      );
      
      console.log('Training result:', result);
      
      // Refresh models list
      const loadedModels = await getModels(projectId);
      setModels(loadedModels || []);
      
      // Clear training state
      setTrainingBoxes([]);
      setModelName('');
      setPendingShape(null);
      setAddToExistingModel(null);
      
      // Different success messages based on mode
      if (addToExistingModel) {
        const existingModel = models.find(m => m.id === addToExistingModel);
        alert(`Added ${trainingBoxes.length} template(s) to "${existingModel?.className || 'model'}"`);
      } else if (trainingMode === 'separate') {
        if (uniqueClasses.length === 1) {
          const name = modelName.trim() || uniqueClasses[0];
          alert(`Training complete! Model "${name}" created with ${trainingBoxes.length} example(s).`);
        } else {
          alert(`Training complete! Created ${uniqueClasses.length} model(s): ${uniqueClasses.join(', ')}`);
        }
      } else {
        alert(`Training complete! Model "${modelName}" created with ${trainingBoxes.length} example(s).`);
      }
    } catch (error) {
      console.error('Training error:', error);
      alert('Training failed: ' + error.message);
    } finally {
      setIsTraining(false);
    }
  };

  // Zoom controls
  const handleZoomIn = () => setScale(s => Math.min(s * 1.25, 5));
  const handleZoomOut = () => setScale(s => Math.max(s / 1.25, 0.25));

  // Load templates for a model
  const loadModelTemplates = async (model) => {
    if (!model) return;
    
    setIsLoadingTemplates(true);
    setTemplateImages([]);
    
    console.log('Loading examples for model:', model.id, model);
    
    // Try Flask server examples endpoint first (port 5000)
    try {
      const flaskResponse = await fetch(`http://localhost:5000/models/${model.id}/examples`);
      if (flaskResponse.ok) {
        const data = await flaskResponse.json();
        console.log('Flask examples response:', data);
        if (data.examples && data.examples.length > 0) {
          // Examples have bbox info - we need to generate thumbnails
          const examplesWithThumbnails = await Promise.all(
            data.examples.map(async (ex) => {
              try {
                // Get thumbnail from backend
                const thumbResponse = await fetch('http://localhost:3001/api/thumbnail', {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify({
                    filename: data.pdfFilename,
                    page: ex.page || 0,
                    bbox: ex.bbox
                  })
                });
                if (thumbResponse.ok) {
                  const thumbData = await thumbResponse.json();
                  return {
                    ...ex,
                    image: thumbData.thumbnail
                  };
                }
              } catch (e) {
                console.log('Failed to get thumbnail for example:', ex.id, e);
              }
              return ex;
            })
          );
          setTemplateImages(examplesWithThumbnails);
          setIsLoadingTemplates(false);
          return;
        }
      }
    } catch (error) {
      console.log('Flask examples fetch failed:', error.message);
    }
    
    // Try Node.js backend templates endpoint
    try {
      const response = await fetch(`http://localhost:3001/api/models/${model.id}/templates`);
      if (response.ok) {
        const data = await response.json();
        console.log('Template API response:', data);
        if (data.templates && data.templates.length > 0) {
          setTemplateImages(data.templates);
          setIsLoadingTemplates(false);
          return;
        }
      }
    } catch (error) {
      console.log('Backend template fetch failed:', error.message);
    }
    
    // Fallback: check various places templates might be stored in the model object
    console.log('Checking model object for templates:', model);
    
    // Check different possible template storage locations
    const templateSources = [
      model.templates,
      model.templateImages,
      model.templateData,
      model.trainingData?.templates,
      model.trainingImages,
    ].filter(Boolean);
    
    for (const source of templateSources) {
      if (Array.isArray(source) && source.length > 0) {
        console.log('Found templates in model object:', source.length);
        const processedTemplates = source.map((t, idx) => {
          if (typeof t === 'string') {
            return {
              image: t.startsWith('data:') || t.startsWith('http') ? t : `data:image/png;base64,${t}`,
              label: `Template ${idx + 1}`
            };
          }
          return t;
        });
        setTemplateImages(processedTemplates);
        setIsLoadingTemplates(false);
        return;
      }
    }
    
    // No templates found
    console.log('No templates found for model');
    setTemplateImages([]);
    setIsLoadingTemplates(false);
  };

  // Toggle template view
  const handleToggleTemplates = () => {
    if (!showTemplates && selectedModel) {
      loadModelTemplates(selectedModel);
    }
    setShowTemplates(!showTemplates);
  };

  // Test model detection
  const handleTestModel = async (modelId) => {
    if (!selectedPdf?.backendFilename) {
      alert('Please select a PDF first');
      return;
    }
    
    const model = models.find(m => m.id === modelId);
    if (!model) {
      alert('Model not found');
      return;
    }
    
    setIsTesting(true);
    setTestModelId(modelId);
    setTestResults([]);
    
    try {
      const enableOCR = testOcrFormat.length > 0;
      const result = await runDetection(selectedPdf.backendFilename, {
        confidence: testConfidence,
        selectedModels: [modelId],
        enableOCR: enableOCR,
        perClassSettings: {
          [modelId]: {
            confidence: testConfidence,
            enableOCR: enableOCR,
            ocrFormat: testOcrFormat || null,
            className: model.className
          }
        }
      });
      
      console.log('Test detection result:', result);
      
      if (result.detections && result.detections.length > 0) {
        // Filter detections for current page
        const pageDetections = result.detections.filter(det => 
          det.page === undefined || det.page === currentPage - 1
        );
        
        setTestResults(pageDetections.map((det, idx) => ({
          id: `test_${Date.now()}_${idx}`,
          x: det.bbox.x,
          y: det.bbox.y,
          width: det.bbox.width,
          height: det.bbox.height,
          confidence: det.confidence,
          className: det.class_name || model.className,
          ocrText: det.ocr_text || '',
          page: det.page || 0,
          shapeType: det.shapeType || 'rectangle'
        })));
      } else {
        setTestResults([]);
      }
    } catch (error) {
      console.error('Test detection error:', error);
      alert('Test detection failed: ' + error.message);
    } finally {
      setIsTesting(false);
    }
  };

  // Clear test results
  const clearTestResults = () => {
    setTestResults([]);
    setShowTestPanel(false);
    setTestModelId(null);
  };

  // Open test panel for a model
  const openTestPanel = (modelId) => {
    setTestModelId(modelId);
    setShowTestPanel(true);
    setTestResults([]);
  };

  // Filter models by search
  const filteredModels = models.filter(model =>
    model.className?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    model.id?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Get selected model
  const selectedModel = selectedItem !== 'home' 
    ? models.find(m => m.id === selectedItem) 
    : null;

  if (isLoading) {
    return <div className="loading">Loading...</div>;
  }

  return (
    <div className="project-models-page">
      <header className="models-header">
        <button 
          className="back-btn"
          onClick={() => navigate(`/project/${projectId}`, { state: { returnToFile } })}
        >
          ← Back to Project
        </button>
        <h1>{project?.name} - Models</h1>
        <h1 className="brand-title">pidly</h1>
      </header>

      <div className="models-body">
        {/* Sidebar */}
        <div 
          className="models-sidebar" 
          style={{ 
            width: sidebarWidth, 
            minWidth: 200, 
            maxWidth: 500,
            position: 'relative'
          }}
        >
          {/* Overview button */}
          <div 
            className={`sidebar-item home-item ${selectedItem === 'home' ? 'selected' : ''}`}
            onClick={() => { setSelectedItem('home'); setSelectedPdf(null); setPdfDoc(null); setPendingShape(null); setShowTemplates(false); setTemplateImages([]); }}
          >
            <span className="item-name">Overview</span>
          </div>

          <div className="sidebar-divider" />

          {/* Search */}
          <div className="models-search">
            <input
              type="text"
              placeholder="Search models..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>

          {/* Models section */}
          <div className="models-section" style={{ height: modelsSectionHeight, maxHeight: modelsSectionHeight }}>
            <div className="models-section-header">
              <span className="section-title">Models</span>
              <span className="model-count">{filteredModels.length}</span>
            </div>
            
            {/* Models list */}
            <div className="models-list">
            {filteredModels.length === 0 ? (
              <p className="no-models">
                {searchQuery ? 'No models found' : 'No models trained yet'}
              </p>
            ) : (
              filteredModels.map(model => (
                <div
                  key={model.id}
                  className={`model-list-item ${selectedItem === model.id ? 'selected' : ''}`}
                  onClick={() => { setSelectedItem(model.id); setSelectedPdf(null); setPdfDoc(null); setPendingShape(null); setShowTemplates(false); setTemplateImages([]); }}
                >
                  <div className="model-item-info">
                    <div className="model-item-name">{model.className}</div>
                    <div className="model-item-meta">{model.numTemplates} templates</div>
                  </div>
                  <div className="model-item-actions">
                    <button
                      className="model-action-btn"
                      title="Test model"
                      onClick={(e) => {
                        e.stopPropagation();
                        setTestModelId(model.id);
                        setShowTestPanel(true);
                        setTestResults([]);
                        if (model.recommendedConfidence) setTestConfidence(model.recommendedConfidence);
                        if (model.recommendedOcrFormat) setTestOcrFormat(model.recommendedOcrFormat);
                        else setTestOcrFormat('');
                        if (!selectedPdf && projectFiles.length > 0) {
                          handleSelectPdf(projectFiles[0]);
                        }
                      }}
                    >
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                        <circle cx="11" cy="11" r="8"/>
                        <path d="M21 21l-4.35-4.35"/>
                      </svg>
                    </button>
                    <button
                      className="model-action-btn"
                      title="Add examples"
                      onClick={(e) => {
                        e.stopPropagation();
                        setAddToExistingModel(model.id);
                        if (!selectedPdf && projectFiles.length > 0) {
                          handleSelectPdf(projectFiles[0]);
                        }
                      }}
                    >
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                        <path d="M12 5v14M5 12h14"/>
                      </svg>
                    </button>
                    <button
                      className="model-action-btn delete"
                      title="Delete model"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDeleteModel(model.id, model.className);
                      }}
                    >
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                        <path d="M3 6h18M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2"/>
                      </svg>
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
          </div>

          {/* Resizable divider between models and PDFs */}
          <div 
            className="section-resize-handle"
            onMouseDown={handleModelsSectionResizeStart}
            style={{
              height: '6px',
              background: isResizingModels ? '#3498db' : '#e1e4e8',
              cursor: 'ns-resize',
              margin: '0 16px',
              borderRadius: '3px',
              transition: 'background 0.15s',
            }}
            onMouseEnter={(e) => !isResizingModels && (e.currentTarget.style.background = '#ccc')}
            onMouseLeave={(e) => !isResizingModels && (e.currentTarget.style.background = '#e1e4e8')}
          />

          {/* Project PDFs section */}
          <div className="training-section">
            <div className="training-section-header">
              <span className="section-title">Project PDFs</span>
              <span className="pdf-count">{projectFiles.length}</span>
            </div>
            
            {/* Search bar */}
            <div className="pdf-search">
              <input
                type="text"
                placeholder="Search PDFs..."
                value={pdfSearchQuery}
                onChange={(e) => setPdfSearchQuery(e.target.value)}
              />
              {pdfSearchQuery && (
                <button 
                  className="clear-search-btn"
                  onClick={() => setPdfSearchQuery('')}
                >
                  ×
                </button>
              )}
            </div>

            <div className="training-pdf-list">
              {filteredProjectFiles.length === 0 ? (
                <p className="no-pdfs">
                  {pdfSearchQuery ? 'No matching PDFs' : 'No PDFs in project'}
                </p>
              ) : (
                filteredProjectFiles.map(file => (
                  <div
                    key={file.id}
                    className={`training-pdf-item ${selectedPdf?.id === file.id ? 'selected' : ''}`}
                    onClick={() => handleSelectPdf(file)}
                  >
                    <div className="pdf-info">
                      <span className="pdf-name" title={file.name}>{file.name}</span>
                      {file.folderName && (
                        <span className="pdf-folder">{file.folderName}</span>
                      )}
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Resize handle */}
          <div
            className="sidebar-resize-handle"
            style={{
              background: isResizingSidebar ? '#3498db' : 'transparent',
            }}
            onMouseDown={handleSidebarMouseDown}
            onMouseEnter={(e) => e.currentTarget.style.background = '#3498db'}
            onMouseLeave={(e) => !isResizingSidebar && (e.currentTarget.style.background = 'transparent')}
          />
        </div>

        {/* Main content */}
        <div className="models-main">
          {selectedPdf ? (
            <div className="pdf-training-area">
              <div className="pdf-training-header">
                <div className="header-left">
                  <h2>{selectedPdf.name}</h2>
                  {numPages > 1 ? (
                    <div className="page-navigation">
                      <button 
                        className="page-nav-btn"
                        onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                        disabled={currentPage <= 1}
                        title="Previous page"
                      >
                        ◀
                      </button>
                      <span className="page-info">Page {currentPage} of {numPages}</span>
                      <button 
                        className="page-nav-btn"
                        onClick={() => setCurrentPage(p => Math.min(numPages, p + 1))}
                        disabled={currentPage >= numPages}
                        title="Next page"
                      >
                        ▶
                      </button>
                    </div>
                  ) : (
                    <span className="page-info">Page {currentPage} of {numPages}</span>
                  )}
                </div>
                <div className="header-controls">
                  <button onClick={handleZoomOut}>−</button>
                  <span className="zoom-level">{Math.round(scale * 100)}%</span>
                  <button onClick={handleZoomIn}>+</button>
                  <button 
                    className="close-pdf-btn"
                    onClick={() => { setSelectedPdf(null); setPdfDoc(null); setTrainingBoxes([]); setCurrentPage(1); }}
                  >
                    ✕
                  </button>
                </div>
              </div>
              
              <div className="training-toolbar">
                <div className="toolbar-row">
                  <div className="class-selector">
                    <label>Class:</label>
                    <select 
                      value={selectedClass} 
                      onChange={(e) => setSelectedClass(e.target.value)}
                    >
                      <option value="">-- Select class --</option>
                      {projectClasses.map(cls => (
                        <option key={cls.id} value={cls.name}>{cls.name}</option>
                      ))}
                    </select>
                  </div>
                  
                  <div className="shape-selector">
                    <button 
                      className={`shape-btn ${drawingShapeType === 'rectangle' ? 'active' : ''}`}
                      onClick={() => setDrawingShapeType('rectangle')}
                      title="Rectangle"
                      style={{ width: '28px', height: '28px', fontSize: '14px', boxSizing: 'border-box', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 0 }}
                    >
                      ▢
                    </button>
                    <button 
                      className={`shape-btn ${drawingShapeType === 'circle' ? 'active' : ''}`}
                      onClick={() => setDrawingShapeType('circle')}
                      title="Circle"
                      style={{ width: '28px', height: '28px', fontSize: '14px', boxSizing: 'border-box', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 0 }}
                    >
                      ○
                    </button>
                  </div>
                  
                  <div className="toolbar-divider" />
                  
                  {(() => {
                    const uniqueClasses = [...new Set(trainingBoxes.map(b => b.className))];
                    const hasMultipleClasses = uniqueClasses.length > 1;
                    
                    return (
                      <>
                        <div className="training-mode-toggle">
                          <button
                            className={`toggle-btn ${trainingMode === 'separate' && !addToExistingModel ? 'active' : ''}`}
                            onClick={() => { setTrainingMode('separate'); setAddToExistingModel(null); }}
                            title="Create separate model for each class"
                          >
                            New
                          </button>
                          <button
                            className={`toggle-btn ${trainingMode === 'combined' && !addToExistingModel ? 'active' : ''}`}
                            onClick={() => { setTrainingMode('combined'); setAddToExistingModel(null); }}
                            disabled={!hasMultipleClasses}
                            title={hasMultipleClasses ? 'Combine all examples into one model' : 'Need multiple classes to combine'}
                          >
                            Combined
                          </button>
                          <button
                            className={`toggle-btn ${addToExistingModel ? 'active' : ''}`}
                            onClick={() => {
                              if (models.length > 0) {
                                // Try to find a matching model by class name
                                const matchingModel = models.find(m => uniqueClasses.includes(m.className));
                                setAddToExistingModel(matchingModel?.id || models[0]?.id);
                              }
                            }}
                            disabled={models.length === 0}
                            title={models.length > 0 ? 'Add templates to an existing model' : 'No models to add to'}
                          >
                            Add to Existing
                          </button>
                        </div>
                        
                        {addToExistingModel ? (
                          <select
                            className="model-select-inline"
                            value={addToExistingModel}
                            onChange={(e) => setAddToExistingModel(e.target.value)}
                          >
                            {models.map(m => (
                              <option key={m.id} value={m.id}>{m.className}</option>
                            ))}
                          </select>
                        ) : trainingMode === 'combined' ? (
                          <input
                            type="text"
                            className="model-name-inline"
                            value={modelName}
                            onChange={(e) => setModelName(e.target.value)}
                            placeholder="Combined model name..."
                          />
                        ) : (
                          <div className="separate-models-info">
                            {uniqueClasses.length === 0 ? (
                              <span className="models-preview">No boxes yet</span>
                            ) : uniqueClasses.length === 1 ? (
                              <input
                                type="text"
                                className="model-name-inline"
                                value={modelName || uniqueClasses[0]}
                                onChange={(e) => setModelName(e.target.value)}
                                placeholder={uniqueClasses[0]}
                              />
                            ) : (
                              <span className="models-preview">
                                {uniqueClasses.length} models: {uniqueClasses.join(', ')}
                              </span>
                            )}
                          </div>
                        )}
                        
                        <label className="orientation-toggle" title="Train model to detect objects at 0°, 90°, 180°, and 270° rotations">
                          <input
                            type="checkbox"
                            checked={multiOrientation}
                            onChange={(e) => setMultiOrientation(e.target.checked)}
                          />
                          <span>All orientations</span>
                        </label>
                        
                        <label className="orientation-toggle" title="Include horizontally flipped (mirrored) versions for arrows and asymmetric symbols">
                          <input
                            type="checkbox"
                            checked={includeInverted}
                            onChange={(e) => setIncludeInverted(e.target.checked)}
                          />
                          <span>Include inverted</span>
                        </label>
                        
                        <div className="toolbar-spacer" />
                        
                        <span className="box-count">
                          {numPages > 1 ? (
                            <>
                              {trainingBoxes.filter(b => b.page === currentPage - 1).length} on page • {trainingBoxes.length} total
                            </>
                          ) : (
                            <>{trainingBoxes.length} box{trainingBoxes.length !== 1 ? 'es' : ''}</>
                          )}
                        </span>
                        
                        <button 
                          className="clear-boxes-btn"
                          onClick={() => setTrainingBoxes([])}
                          disabled={trainingBoxes.length === 0}
                        >
                          Clear
                        </button>
                        
                        <button 
                          className="train-btn"
                          onClick={handleTrain}
                          disabled={isTraining || trainingBoxes.length === 0 || (trainingMode === 'combined' && !modelName.trim())}
                        >
                          {isTraining ? 'Training...' : (addToExistingModel ? '➕ Add Templates' : 'Train')}
                        </button>
                        
                        {models.length > 0 && (
                          <button 
                            className={`test-model-btn ${showTestPanel ? 'active' : ''} ${isTesting ? 'testing' : ''}`}
                            onClick={() => setShowTestPanel(!showTestPanel)}
                            disabled={isTesting}
                            title="Test a model on the current PDF"
                          >
                            {isTesting ? 'Testing...' : 'Test'}
                          </button>
                        )}
                      </>
                    );
                  })()}
                </div>
              </div>
              
              {/* Training Content Area - holds canvas and side panel */}
              <div className="training-content-area">
                {/* Left side - hints and canvas */}
                <div className="training-canvas-section">
                  {/* Shape drawing hint */}
                  {selectedClass && !pendingShape && (
                    <div className="shape-hint">
                      {drawingShapeType === 'rectangle' && '📐 Click and drag to draw • Ctrl+scroll to zoom • Drag to pan when not drawing'}
                      {drawingShapeType === 'circle' && '⭕ Click and drag to draw • Ctrl+scroll to zoom • Drag to pan when not drawing'}
                    </div>
                  )}
                  
                  {!selectedClass && (
                    <div className="models-class-hint">
                      ⚠️ Select a class above to start drawing training boxes • Drag to pan • Ctrl+scroll to zoom
                    </div>
                  )}
                  
                  <div 
                    className="models-pdf-canvas-container"
                    ref={containerRef}
                  >
                <div 
                  className="models-pdf-canvas-wrapper"
                  style={{
                    width: canvasSize.width * scale,
                    height: canvasSize.height * scale,
                    position: 'relative',
                    transform: `translate(${panOffset.x}px, ${panOffset.y}px)`,
                  }}
                  onMouseDown={handleMouseDown}
                  onMouseMove={handleMouseMove}
                  onMouseUp={handleMouseUp}
                  onMouseLeave={handleMouseUp}
                >
                  <canvas
                    ref={canvasRef}
                    style={{
                      width: canvasSize.width * scale,
                      height: canvasSize.height * scale,
                      cursor: isPanning ? 'grabbing' : 
                              (selectedClass && !pendingShape ? 'crosshair' : 'grab')
                    }}
                  />
                  
                  {/* Current drawing rectangle/circle */}
                  {currentRect && (
                    <div
                      className={`models-drawing-rect ${drawingShapeType === 'circle' ? 'circle' : ''}`}
                      style={{
                        left: currentRect.x * scale,
                        top: currentRect.y * scale,
                        width: currentRect.width * scale,
                        height: currentRect.height * scale,
                        borderColor: projectClasses.find(c => c.name === selectedClass)?.color || '#3498db',
                        borderRadius: drawingShapeType === 'circle' ? '50%' : '0',
                      }}
                    />
                  )}
                  
                  {/* Existing training boxes for current page */}
                  {trainingBoxes
                    .filter(box => box.page === currentPage - 1)
                    .map(box => {
                      const isCircle = box.shapeType === 'circle';
                      
                      return (
                        <div
                          key={box.id}
                          className={`models-training-box ${isCircle ? 'circle' : ''}`}
                          style={{
                            left: box.x * canvasSize.width * scale,
                            top: box.y * canvasSize.height * scale,
                            width: box.width * canvasSize.width * scale,
                            height: box.height * canvasSize.height * scale,
                            borderColor: box.color,
                            backgroundColor: `${box.color}20`,
                            borderRadius: isCircle ? '50%' : '0',
                          }}
                        >
                          <span className="box-label" style={{ backgroundColor: box.color }}>
                            {box.className}
                          </span>
                          <button 
                            className="remove-box-btn"
                            onClick={(e) => { e.stopPropagation(); handleRemoveBox(box.id); }}
                          >
                            ×
                          </button>
                        </div>
                      );
                    })}
                  
                  {/* Pending shape confirmation overlay */}
                  {pendingShape && pendingShape.page === currentPage - 1 && (
                    <div
                      className="pending-shape-overlay"
                      style={{
                        left: pendingShape.x * canvasSize.width * scale,
                        top: pendingShape.y * canvasSize.height * scale,
                        width: pendingShape.width * canvasSize.width * scale,
                        height: pendingShape.height * canvasSize.height * scale,
                      }}
                      onMouseDown={(e) => e.stopPropagation()}
                    >
                      {/* Shape outline */}
                      <div 
                        className={`pending-shape-border ${pendingShape.shapeType === 'circle' ? 'circle' : ''}`}
                        style={{
                          borderRadius: pendingShape.shapeType === 'circle' ? '50%' : '0',
                        }}
                      />
                      
                      {/* Resize handles */}
                      <div 
                        className="shape-handle handle-nw"
                        onMouseDown={(e) => { e.stopPropagation(); setActiveResizeHandle('nw'); }}
                      />
                      <div 
                        className="shape-handle handle-ne"
                        onMouseDown={(e) => { e.stopPropagation(); setActiveResizeHandle('ne'); }}
                      />
                      <div 
                        className="shape-handle handle-sw"
                        onMouseDown={(e) => { e.stopPropagation(); setActiveResizeHandle('sw'); }}
                      />
                      <div 
                        className="shape-handle handle-se"
                        onMouseDown={(e) => { e.stopPropagation(); setActiveResizeHandle('se'); }}
                      />
                      <div 
                        className="shape-handle handle-n"
                        onMouseDown={(e) => { e.stopPropagation(); setActiveResizeHandle('n'); }}
                      />
                      <div 
                        className="shape-handle handle-s"
                        onMouseDown={(e) => { e.stopPropagation(); setActiveResizeHandle('s'); }}
                      />
                      <div 
                        className="shape-handle handle-e"
                        onMouseDown={(e) => { e.stopPropagation(); setActiveResizeHandle('e'); }}
                      />
                      <div 
                        className="shape-handle handle-w"
                        onMouseDown={(e) => { e.stopPropagation(); setActiveResizeHandle('w'); }}
                      />
                      
                      {/* Confirmation buttons */}
                      <div className="pending-shape-actions" onMouseDown={(e) => e.stopPropagation()}>
                        {getSubclasses(selectedClass).length > 0 && (
                          <button 
                            className={`define-regions-btn ${Object.keys(subclassRegions).length > 0 ? 'has-regions' : ''} ${isCapturingRegion ? 'loading' : ''}`}
                            onClick={(e) => {
                              e.stopPropagation();
                              handleDefineSubclassRegions();
                            }}
                            onMouseDown={(e) => e.stopPropagation()}
                            title="Define OCR regions for subclasses"
                            disabled={isCapturingRegion}
                          >
                            {isCapturingRegion ? '⏳ Loading...' : (
                              <>📍 {Object.keys(subclassRegions).length > 0 
                                ? `Regions (${Object.keys(subclassRegions).length}/${getSubclasses(selectedClass).length})`
                                : 'Define Regions'}</>
                            )}
                          </button>
                        )}
                        <button 
                          className="confirm-shape-btn"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleConfirmShape();
                          }}
                          onMouseDown={(e) => e.stopPropagation()}
                          title="Confirm"
                        >
                          ✓
                        </button>
                        <button 
                          className="cancel-shape-btn"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleCancelShape();
                          }}
                          onMouseDown={(e) => e.stopPropagation()}
                          title="Cancel"
                        >
                          ✕
                        </button>
                      </div>
                    </div>
                  )}
                  
                  {/* Test detection results overlay */}
                  {testResults
                    .filter(result => result.page === currentPage - 1 || result.page === undefined)
                    .map(result => (
                      <div
                        key={result.id}
                        className={`test-result-box ${result.shapeType === 'circle' ? 'circle' : ''}`}
                        style={{
                          left: result.x * canvasSize.width * scale,
                          top: result.y * canvasSize.height * scale,
                          width: result.width * canvasSize.width * scale,
                          height: result.height * canvasSize.height * scale,
                          borderRadius: result.shapeType === 'circle' ? '50%' : '0',
                        }}
                      >
                        <span className="test-result-label">
                          {result.ocrText || result.className} ({Math.round(result.confidence * 100)}%)
                        </span>
                      </div>
                    ))}
                </div>
              </div>
                </div>
                
                {/* Test Model Panel - Right Sidebar */}
                {showTestPanel && (
                  <div className="test-panel-sidebar">
                    <div className="panel-header">
                      <h3>🔍 Test Model</h3>
                      <button className="close-panel" onClick={() => setShowTestPanel(false)}>×</button>
                    </div>
                    <div className="panel-content">
                      {/* Model Selection */}
                      <div className="panel-section">
                        <h4>Select Model</h4>
                        <select 
                          value={testModelId || ''} 
                          onChange={(e) => { 
                            setTestModelId(e.target.value); 
                            setTestResults([]); 
                            const model = models.find(m => m.id === e.target.value);
                            if (model) {
                              setTestConfidence(model.recommendedConfidence || 0.7);
                              setTestOcrFormat(model.recommendedOcrFormat || '');
                            } else {
                              setTestConfidence(0.7);
                              setTestOcrFormat('');
                            }
                          }}
                          className="panel-select"
                        >
                          <option value="">-- Select model --</option>
                          {models.map(m => (
                            <option key={m.id} value={m.id}>{m.className}</option>
                          ))}
                        </select>
                        
                        <button 
                          className="panel-action-btn"
                          onClick={() => handleTestModel(testModelId)}
                          disabled={!testModelId || isTesting}
                        >
                          {isTesting ? '⏳ Running...' : '▶ Run Detection'}
                        </button>
                        
                        {testResults.length > 0 && (
                          <div className="panel-results-badge">{testResults.length} found</div>
                        )}
                      </div>
                      
                      {/* Recommended Settings */}
                      {testModelId && (
                        <div className="panel-section">
                          <h4>📋 Recommended Settings</h4>
                          
                          <div className="panel-setting-row">
                            <label>Confidence</label>
                            <div className="panel-slider-control">
                              <input 
                                type="range" 
                                min="0.1" 
                                max="1" 
                                step="0.025"
                                value={testConfidence}
                                onChange={(e) => setTestConfidence(parseFloat(e.target.value))}
                              />
                              <span className="panel-value">{Math.round(testConfidence * 100)}%</span>
                            </div>
                          </div>
                          
                          <div className="panel-setting-row">
                            <label>Format</label>
                            <input 
                              type="text"
                              className="panel-input"
                              placeholder="e.g. FI-12345"
                              value={testOcrFormat}
                              onChange={(e) => setTestOcrFormat(e.target.value.toUpperCase())}
                            />
                            {testOcrFormat && (
                              <span className="panel-pattern">
                                Pattern: {testOcrFormat.replace(/[A-Z]/g, 'L').replace(/[0-9]/g, 'N')}
                              </span>
                            )}
                          </div>
                          
                          <button 
                            className="panel-save-btn"
                            onClick={async () => {
                              const model = models.find(m => m.id === testModelId);
                              if (model) {
                                const pattern = testOcrFormat ? testOcrFormat.replace(/[A-Z]/g, 'L').replace(/[0-9]/g, 'N') : null;
                                const updatedModel = { 
                                  ...model, 
                                  recommendedConfidence: testConfidence,
                                  recommendedOcrFormat: testOcrFormat || null,
                                  recommendedOcrPattern: pattern
                                };
                                await saveModel(updatedModel);
                                const loadedModels = await getModels(projectId);
                                setModels(loadedModels || []);
                                alert(`✓ Saved settings for "${model.className}"`);
                              }
                            }}
                          >
                            💾 Save Settings
                          </button>
                        </div>
                      )}
                      
                      {/* Results Actions */}
                      {testResults.length > 0 && (
                        <div className="panel-section">
                          <h4>Results</h4>
                          <div className="panel-guidance">
                            <span>⬇️ Missed similar? Lower confidence</span>
                            <span>⬆️ False positives? Raise confidence</span>
                          </div>
                          <button 
                            className="panel-clear-btn"
                            onClick={() => setTestResults([])}
                          >
                            Clear Results
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>
            </div>
          ) : selectedItem === 'home' ? (
            <div className="home-content">
              <div className="home-header-section">
                <div className="home-icon">
                  <svg width="48" height="48" viewBox="0 0 16 16" fill="none">
                    <circle cx="8" cy="4" r="2" stroke="#333" strokeWidth="1"/>
                    <circle cx="4" cy="12" r="2" stroke="#333" strokeWidth="1"/>
                    <circle cx="12" cy="12" r="2" stroke="#333" strokeWidth="1"/>
                    <path d="M8 6V8M6 10L8 8L10 10" stroke="#333" strokeWidth="1" strokeLinecap="round" strokeLinejoin="round"/>
                  </svg>
                </div>
                <h2>Models Overview</h2>
                <p className="home-subtitle">Train and manage object detection models</p>
              </div>
              
              <div className="home-stats-row">
                <div className="stat-card">
                  <div className="stat-number">{models.length}</div>
                  <div className="stat-label">Total Models</div>
                </div>
                <div className="stat-card">
                  <div className="stat-number">{models.reduce((acc, m) => acc + (m.numTemplates || 0), 0)}</div>
                  <div className="stat-label">Templates</div>
                </div>
                <div className="stat-card">
                  <div className="stat-number">{models.reduce((acc, m) => acc + (m.numExamples || 0), 0)}</div>
                  <div className="stat-label">Examples</div>
                </div>
              </div>

              <div className="home-actions-section">
                <h3>Quick Actions</h3>
                <div className="home-actions-grid">
                  <div className="action-card" onClick={() => {
                    // Find first PDF in project and start training
                    if (projectFiles.length > 0) {
                      handleSelectPdf(projectFiles[0]);
                    } else {
                      alert('Please add PDFs to your project first');
                    }
                  }}>
                    <div className="action-icon">
                      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#27ae60" strokeWidth="2">
                        <path d="M12 5v14M5 12h14"/>
                      </svg>
                    </div>
                    <div className="action-text">
                      <div className="action-title">Train New Model</div>
                      <div className="action-desc">Create a new detection model</div>
                    </div>
                  </div>
                  
                  <div className="action-card" onClick={handleExportModels}>
                    <div className="action-icon">
                      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#3498db" strokeWidth="2">
                        <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M17 8l-5-5-5 5M12 3v12"/>
                      </svg>
                    </div>
                    <div className="action-text">
                      <div className="action-title">Export Models</div>
                      <div className="action-desc">Download models as ZIP</div>
                    </div>
                  </div>
                  
                  <div className="action-card" onClick={() => modelFileInputRef.current?.click()}>
                    <div className="action-icon">
                      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#9b59b6" strokeWidth="2">
                        <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3"/>
                      </svg>
                    </div>
                    <div className="action-text">
                      <div className="action-title">Import Models</div>
                      <div className="action-desc">Load models from file</div>
                    </div>
                  </div>
                </div>
                <input
                  ref={modelFileInputRef}
                  type="file"
                  accept=".zip,.json"
                  onChange={handleModelFileSelect}
                  style={{ display: 'none' }}
                />
              </div>

              <div className="home-tips-section">
                <h3>Getting Started</h3>
                <div className="tips-list">
                  <div className="tip-item">
                    <span className="tip-number">1</span>
                    <span className="tip-text">Select a PDF from the training section</span>
                  </div>
                  <div className="tip-item">
                    <span className="tip-number">2</span>
                    <span className="tip-text">Draw bounding boxes around objects to detect</span>
                  </div>
                  <div className="tip-item">
                    <span className="tip-number">3</span>
                    <span className="tip-text">Assign a class name and click Train</span>
                  </div>
                  <div className="tip-item">
                    <span className="tip-number">4</span>
                    <span className="tip-text">Test your model and adjust confidence threshold</span>
                  </div>
                </div>
              </div>
            </div>
          ) : selectedModel ? (
            <div className="model-details">
              <div className="model-details-header">
                <h2>{selectedModel.className}</h2>
                <button 
                  className={`view-templates-btn ${showTemplates ? 'active' : ''}`}
                  onClick={handleToggleTemplates}
                  title="View template images used by this model"
                >
                  🖼️ {showTemplates ? 'Hide' : 'View'} Examples
                </button>
              </div>

              <div className="model-details-grid">
                <div className="detail-card">
                  <div className="detail-label">Templates</div>
                  <div className="detail-value">{selectedModel.numTemplates}</div>
                </div>
                <div className="detail-card">
                  <div className="detail-label">Examples</div>
                  <div className="detail-value">{selectedModel.numExamples || '-'}</div>
                </div>
                <div className="detail-card">
                  <div className="detail-label">Multi-class</div>
                  <div className="detail-value">{selectedModel.isMultiClass ? 'Yes' : 'No'}</div>
                </div>
                <div className="detail-card">
                  <div className="detail-label">Created</div>
                  <div className="detail-value">
                    {selectedModel.created 
                      ? new Date(selectedModel.created).toLocaleDateString() 
                      : '-'}
                  </div>
                </div>
              </div>
              
              {/* Editable Recommended Settings Section */}
              <div className="model-recommended-settings">
                <h3>Recommended Settings</h3>
                
                <div className="settings-row">
                  <div className="setting-group">
                    <label>Confidence Threshold</label>
                    <div className="setting-input-row">
                      <input 
                        type="range" 
                        min="0.1" 
                        max="1" 
                        step="0.025"
                        value={editConfidence}
                        onChange={(e) => setEditConfidence(parseFloat(e.target.value))}
                      />
                      <span className="confidence-display">
                        {(editConfidence * 100) % 1 === 0 ? Math.round(editConfidence * 100) : (editConfidence * 100).toFixed(1)}%
                      </span>
                    </div>
                  </div>
                  
                  <div className="setting-group">
                    <label>OCR Format Pattern</label>
                    <div className="setting-input-row">
                      <input 
                        type="text"
                        className="format-text-input"
                        placeholder="Enter example text"
                        value={editOcrFormat}
                        onChange={(e) => setEditOcrFormat(e.target.value.toUpperCase())}
                      />
                      {editOcrFormat && (
                        <span className="pattern-display">
                          {editOcrFormat.replace(/[A-Z]/g, 'L').replace(/[0-9]/g, 'N')}
                        </span>
                      )}
                    </div>
                  </div>
                  
                  <button 
                    className="save-settings-btn"
                    onClick={async () => {
                      const pattern = editOcrFormat ? editOcrFormat.replace(/[A-Z]/g, 'L').replace(/[0-9]/g, 'N') : null;
                      const updatedModel = { 
                        ...selectedModel, 
                        recommendedConfidence: editConfidence,
                        recommendedOcrFormat: editOcrFormat || null,
                        recommendedOcrPattern: pattern
                      };
                      await saveModel(updatedModel);
                      const loadedModels = await getModels(projectId);
                      setModels(loadedModels || []);
                      alert(`Settings saved for "${selectedModel.className}"`);
                    }}
                  >
                    Save
                  </button>
                </div>
              </div>

              {selectedModel.classes && selectedModel.classes.length > 0 && (
                <div className="model-classes-section">
                  <h3>Classes in this model</h3>
                  <div className="model-classes-list">
                    {selectedModel.classes.map((cls, idx) => (
                      <span key={idx} className="class-tag">{cls}</span>
                    ))}
                  </div>
                </div>
              )}

              {/* Templates View Section */}
              {showTemplates && (
                <div className="model-templates-section">
                  <h3>
                    Training Examples ({templateImages.length || selectedModel.numExamples || 0})
                    <span className="templates-help-text">Click ✕ to remove an example from the model</span>
                  </h3>
                  <div className="templates-container">
                    {isLoadingTemplates ? (
                      <div className="templates-loading">
                        <span>Loading examples...</span>
                      </div>
                    ) : templateImages.length > 0 ? (
                      <div className="templates-grid">
                        {templateImages.map((template, idx) => (
                          <div key={template.id || template.example_id || idx} className="template-item">
                            <img 
                              src={template.image || template} 
                              alt={`Example ${idx + 1}`}
                              title={template.label || `Example ${idx + 1}${template.className ? ` (${template.className})` : ''}`}
                            />
                            {template.label && (
                              <span className="template-label">{template.label}</span>
                            )}
                            {template.className && template.className !== template.label && (
                              <span className="template-class">{template.className}</span>
                            )}
                            {(template.id || template.example_id) && (
                              <button 
                                className="remove-example-btn"
                                title="Remove this example from the model"
                                onClick={async (e) => {
                                  e.stopPropagation();
                                  const exampleId = template.id || template.example_id;
                                  if (!confirm(`Remove this example from "${selectedModel.className}"?\n\nThis will regenerate the model without this training example.`)) {
                                    return;
                                  }
                                  try {
                                    // Use Flask server directly (port 5000)
                                    const response = await fetch(
                                      `http://localhost:5000/models/${selectedModel.id}/examples/${encodeURIComponent(exampleId)}`,
                                      { method: 'DELETE' }
                                    );
                                    const result = await response.json();
                                    
                                    if (result.modelDeleted) {
                                      alert('Model deleted (no examples remaining).');
                                      setSelectedItem('home');
                                      setShowTemplates(false);
                                      const loadedModels = await getModels(projectId);
                                      setModels(loadedModels || []);
                                    } else if (result.success) {
                                      alert(`Example removed and model retrained. ${result.remainingExamples} examples remaining.`);
                                      // Reload templates
                                      loadModelTemplates(selectedModel);
                                      // Reload model list to update counts
                                      const loadedModels = await getModels(projectId);
                                      setModels(loadedModels || []);
                                    } else {
                                      alert('Failed to remove example: ' + (result.error || 'Unknown error'));
                                    }
                                  } catch (error) {
                                    console.error('Error removing example:', error);
                                    alert('Failed to remove example: ' + error.message + '\n\nMake sure detector_server.py is running.');
                                  }
                                }}
                              >
                                ✕
                              </button>
                            )}
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="templates-empty">
                        <p>No example images available.</p>
                        <p className="templates-hint">
                          Examples are stored in the model file. Ensure detector_server.py is running for full access.
                        </p>
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div className="no-selection">
              <p>Model not found</p>
            </div>
          )}
        </div>
      </div>
      
      {/* Subclass Region Dialog */}
      {showSubclassDialog && pendingShape && (
        <div className="modal-overlay">
          <div 
            className="subclass-region-dialog" 
            onClick={(e) => e.stopPropagation()}
            style={{
              width: subclassDialogSize.width,
              height: subclassDialogSize.height,
            }}
          >
            {/* Resize handles */}
            <div 
              className="dialog-resize-handle resize-e"
              onMouseDown={(e) => {
                e.preventDefault();
                setIsResizingDialog(true);
                setDialogResizeStart({ x: e.clientX, y: e.clientY, width: subclassDialogSize.width, height: subclassDialogSize.height, direction: 'e' });
              }}
            />
            <div 
              className="dialog-resize-handle resize-s"
              onMouseDown={(e) => {
                e.preventDefault();
                setIsResizingDialog(true);
                setDialogResizeStart({ x: e.clientX, y: e.clientY, width: subclassDialogSize.width, height: subclassDialogSize.height, direction: 's' });
              }}
            />
            <div 
              className="dialog-resize-handle resize-se"
              onMouseDown={(e) => {
                e.preventDefault();
                setIsResizingDialog(true);
                setDialogResizeStart({ x: e.clientX, y: e.clientY, width: subclassDialogSize.width, height: subclassDialogSize.height, direction: 'se' });
              }}
            />
            
            <div className="dialog-header">
              <h3>📍 Define OCR Regions</h3>
              <button className="close-dialog-btn" onClick={handleCloseSubclassDialog}>✕</button>
            </div>
            
            {(() => {
              const subclasses = getSubclasses(selectedClass);
              const currentSubclass = subclasses[currentSubclassIndex];
              
              return (
                <>
                  <div className="subclass-tabs">
                    {subclasses.map((sub, idx) => (
                      <button
                        key={sub}
                        className={`subclass-tab ${idx === currentSubclassIndex ? 'active' : ''} ${subclassRegions[sub] ? 'completed' : ''}`}
                        onClick={() => {
                          setCurrentSubclassIndex(idx);
                          setSubclassCurrentRect(null);
                        }}
                      >
                        {subclassRegions[sub] && <span className="tab-check">✓</span>}
                        {sub}
                      </button>
                    ))}
                    {/* Debug: Download captured image */}
                    <button
                      style={{ marginLeft: 'auto', fontSize: '11px', padding: '4px 8px' }}
                      onClick={() => {
                        if (subclassImageData?.image) {
                          const a = document.createElement('a');
                          a.href = subclassImageData.image;
                          a.download = 'subclass_popup_image.png';
                          a.click();
                        }
                      }}
                    >
                      📥 Debug Image
                    </button>
                  </div>
                  
                  <p className="region-instruction">
                    Draw a box on the image where <strong>{currentSubclass}</strong> value appears.
                  </p>
                  
                  {/* Zoom controls */}
                  <div className="subclass-zoom-controls">
                    <button onClick={() => setSubclassImageZoom(z => Math.max(0.5, z - 0.25))}>−</button>
                    <span>{Math.round(subclassImageZoom * 100)}%</span>
                    <button onClick={() => setSubclassImageZoom(z => Math.min(4, z + 0.25))}>+</button>
                    <button onClick={() => setSubclassImageZoom(1)}>Reset</button>
                  </div>
                  
                  <div className="region-image-container">
                    {subclassImageData?.image && (
                      <div 
                        className="subclass-image-wrapper"
                        style={{ 
                          transform: `scale(${subclassImageZoom})`, 
                          transformOrigin: 'top left',
                          cursor: 'crosshair'
                        }}
                        onMouseDown={(e) => {
                          e.preventDefault(); // Prevent browser drag behavior
                          e.stopPropagation();
                          
                          const wrapper = e.currentTarget;
                          const img = wrapper.querySelector('img');
                          if (!img) return;
                          
                          // Use IMAGE rect for calculations (wrapper may be larger due to container sizing)
                          const imgRect = img.getBoundingClientRect();
                          
                          console.log('=== MouseDown ===');
                          console.log('Image rect:', { w: imgRect.width.toFixed(1), h: imgRect.height.toFixed(1) });
                          
                          // Calculate position relative to IMAGE
                          const clickX = e.clientX - imgRect.left;
                          const clickY = e.clientY - imgRect.top;
                          const x = clickX / imgRect.width;
                          const y = clickY / imgRect.height;
                          
                          console.log('Click relative to image:', { clickX: clickX.toFixed(1), clickY: clickY.toFixed(1) });
                          console.log('Normalized:', { x: x.toFixed(4), y: y.toFixed(4) });
                          
                          // Clamp to valid range
                          const clampedX = Math.max(0, Math.min(1, x));
                          const clampedY = Math.max(0, Math.min(1, y));
                          
                          setSubclassDrawStart({ x: clampedX, y: clampedY });
                          setSubclassCurrentRect({ x: clampedX, y: clampedY, width: 0, height: 0 });
                        }}
                        onMouseMove={(e) => {
                          if (!subclassDrawStart) return;
                          e.preventDefault();
                          
                          const wrapper = e.currentTarget;
                          const img = wrapper.querySelector('img');
                          if (!img) return;
                          
                          const imgRect = img.getBoundingClientRect();
                          const clickX = e.clientX - imgRect.left;
                          const clickY = e.clientY - imgRect.top;
                          const x = Math.max(0, Math.min(1, clickX / imgRect.width));
                          const y = Math.max(0, Math.min(1, clickY / imgRect.height));
                          
                          const width = x - subclassDrawStart.x;
                          const height = y - subclassDrawStart.y;
                          
                          setSubclassCurrentRect({
                            x: width < 0 ? x : subclassDrawStart.x,
                            y: height < 0 ? y : subclassDrawStart.y,
                            width: Math.abs(width),
                            height: Math.abs(height)
                          });
                        }}
                        onMouseUp={(e) => {
                          e.preventDefault();
                          if (subclassCurrentRect && subclassCurrentRect.width > 0.01 && subclassCurrentRect.height > 0.01) {
                            const img = document.querySelector('.subclass-image-wrapper img');
                            console.log('=== Saving Subclass Region ===');
                            console.log('Subclass:', currentSubclass);
                            console.log('Rect (normalized 0-1):', subclassCurrentRect);
                            if (img) {
                              const rect = img.getBoundingClientRect();
                              console.log('Image display size:', rect.width.toFixed(1), 'x', rect.height.toFixed(1));
                              console.log('Pixel region on image:', {
                                x: Math.round(subclassCurrentRect.x * rect.width),
                                y: Math.round(subclassCurrentRect.y * rect.height),
                                width: Math.round(subclassCurrentRect.width * rect.width),
                                height: Math.round(subclassCurrentRect.height * rect.height)
                              });
                            }
                            setSubclassRegions(prev => ({
                              ...prev,
                              [currentSubclass]: subclassCurrentRect
                            }));
                          }
                          setSubclassDrawStart(null);
                          setSubclassCurrentRect(null);
                        }}
                        onMouseLeave={() => {
                          if (subclassDrawStart) {
                            if (subclassCurrentRect && subclassCurrentRect.width > 0.01 && subclassCurrentRect.height > 0.01) {
                              setSubclassRegions(prev => ({
                                ...prev,
                                [currentSubclass]: subclassCurrentRect
                              }));
                            }
                            setSubclassDrawStart(null);
                            setSubclassCurrentRect(null);
                          }
                        }}
                      >
                        {/* Inner wrapper that exactly matches image size for overlay positioning */}
                        <div style={{ position: 'relative', display: 'inline-block' }}>
                          <img 
                            src={subclassImageData.image} 
                            alt="Region preview"
                            draggable={false}
                            onDragStart={(e) => e.preventDefault()}
                            onLoad={(e) => {
                              const img = e.target;
                              const imgRect = img.getBoundingClientRect();
                              console.log('=== Subclass Image Loaded ===');
                              console.log('Image natural size:', img.naturalWidth, 'x', img.naturalHeight);
                              console.log('Image display size:', imgRect.width.toFixed(1), 'x', imgRect.height.toFixed(1));
                            }}
                          />
                          
                          {/* Show all marked regions (hide current subclass if actively drawing) */}
                          {Object.entries(subclassRegions)
                            .filter(([subName]) => !(subName === currentSubclass && subclassDrawStart))
                            .map(([subName, region]) => (
                            <div 
                              key={subName}
                              className={`subclass-draw-rect ${subName === currentSubclass ? 'current' : 'other'}`}
                              style={{
                                left: `${region.x * 100}%`,
                                top: `${region.y * 100}%`,
                                width: `${region.width * 100}%`,
                                height: `${region.height * 100}%`,
                              }}
                            >
                              <span className="region-label">{subName}</span>
                            </div>
                          ))}
                          
                          {/* Current drawing rect - show while drawing even if region exists */}
                          {subclassCurrentRect && (
                            <div 
                              className="subclass-draw-rect current drawing"
                              style={{
                                left: `${subclassCurrentRect.x * 100}%`,
                                top: `${subclassCurrentRect.y * 100}%`,
                                width: `${subclassCurrentRect.width * 100}%`,
                                height: `${subclassCurrentRect.height * 100}%`,
                              }}
                            >
                              <span className="region-label">{currentSubclass}</span>
                            </div>
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                  
                  {/* Status */}
                  <div className="subclass-status">
                    {subclassRegions[currentSubclass] ? (
                      <span className="status-done">✅ Region marked for {currentSubclass}</span>
                    ) : (
                      <span className="status-pending">Draw a box to mark the region</span>
                    )}
                  </div>
                  
                  <div className="dialog-actions">
                    {currentSubclassIndex > 0 && (
                      <button 
                        className="prev-btn"
                        onClick={() => setCurrentSubclassIndex(prev => prev - 1)}
                      >
                        ← Previous
                      </button>
                    )}
                    
                    {subclassRegions[currentSubclass] && (
                      <button 
                        className="clear-region-btn"
                        onClick={() => setSubclassRegions(prev => {
                          const newRegions = { ...prev };
                          delete newRegions[currentSubclass];
                          return newRegions;
                        })}
                      >
                        Clear
                      </button>
                    )}
                    
                    <div className="dialog-spacer" />
                    
                    {currentSubclassIndex < subclasses.length - 1 ? (
                      <button 
                        className="next-btn"
                        onClick={() => setCurrentSubclassIndex(prev => prev + 1)}
                      >
                        Next →
                      </button>
                    ) : (
                      <button 
                        className="done-btn"
                        onClick={handleCloseSubclassDialog}
                      >
                        Done
                      </button>
                    )}
                  </div>
                </>
              );
            })()}
          </div>
        </div>
      )}

      {/* Import Dialog */}
      {showImportDialog && (
        <div className="modal-overlay" onClick={() => { setShowImportDialog(false); setImportData(null); setImportError(null); }}>
          <div className="modal import-modal" onClick={(e) => e.stopPropagation()}>
            <h2>Import Models</h2>
            
            {importError ? (
              <div className="import-error">
                <span className="error-icon">⚠️</span>
                <p>{importError}</p>
              </div>
            ) : importData ? (
              <>
                <div className="import-summary">
                  <p><strong>File:</strong> {importData.fileName}</p>
                  
                  {importData.isZip ? (
                    <>
                      <div className="import-info">
                        <span>📦</span>
                        <p>This zip file contains trained model files (.pkl) that will be fully functional after import.</p>
                      </div>
                    </>
                  ) : (
                    <>
                      <p><strong>Models found:</strong> {importData.models?.length || 0}</p>
                      <div className="import-warning">
                        <span>⚠️</span>
                        <p>This is a legacy JSON file. Only model metadata will be imported - models will need to be retrained to function.</p>
                      </div>
                      
                      <div className="import-preview">
                        <p className="preview-label">Preview (first 3 models):</p>
                        <div className="preview-list">
                          {importData.models?.slice(0, 3).map((model, i) => (
                            <div key={i} className="preview-item">
                              <span className="preview-class">{model.className || 'Unknown'}</span>
                              <span className="preview-type">{model.modelType || 'object'}</span>
                            </div>
                          ))}
                          {importData.models?.length > 3 && (
                            <div className="preview-more">...and {importData.models.length - 3} more</div>
                          )}
                        </div>
                      </div>
                    </>
                  )}
                </div>
                
                <div className="import-mode">
                  <p className="mode-label">Import Mode:</p>
                  <div className="mode-toggle">
                    <button 
                      className={`mode-btn ${importMode === 'merge' ? 'active' : ''}`}
                      onClick={() => setImportMode('merge')}
                    >
                      <span className="mode-title">Merge</span>
                      <span className="mode-desc">{importData.isZip ? 'Skip existing models' : 'Add new, update existing'}</span>
                    </button>
                    <button 
                      className={`mode-btn ${importMode === 'replace' ? 'active' : ''}`}
                      onClick={() => setImportMode('replace')}
                    >
                      <span className="mode-title">{importData.isZip ? 'Overwrite' : 'Replace All'}</span>
                      <span className="mode-desc">{importData.isZip ? 'Overwrite existing models' : 'Clear & import fresh'}</span>
                    </button>
                  </div>
                </div>
              </>
            ) : (
              <p>Processing file...</p>
            )}
            
            <div className="modal-buttons">
              <button onClick={() => { setShowImportDialog(false); setImportData(null); setImportError(null); }}>
                Cancel
              </button>
              {importData && !importError && (
                <button 
                  className="primary-btn"
                  onClick={handleImportModels}
                >
                  {importData.isZip ? 'Import Models' : `Import ${importData.models?.length || 0} Models`}
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
